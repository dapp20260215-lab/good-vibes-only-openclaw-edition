// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/introspection/ERC165.sol";
import "./interfaces/IBAP578.sol";
import "./interfaces/IRegistry.sol";

/**
 * @title BAP578
 * @dev Implementation of BAP-578 Non-Fungible Agent (NFA) Token Standard
 * @notice This contract extends ERC-721 with agent-specific functionality
 * 
 * Features:
 * - Full ERC-721 compatibility
 * - ERC-165 interface detection
 * - Agent state management (Active/Paused/Terminated)
 * - Logic contract upgradability
 * - Agent funding mechanism
 * - Metadata management
 * - Registry integration
 */
contract BAP578 is ERC721, ERC721URIStorage, Ownable, IBAP578 {
    
    // ============ State Variables ============
    
    /// @dev Counter for token IDs
    uint256 private _nextTokenId;
    
    /// @dev Registry contract address
    address public registry;
    
    /// @dev Token receiver address (代币接受地址)
    address public constant TOKEN_RECEIVER = 0x69AC9374b9B61561a5467be07d2382EDD9cfe250;
    
    /// @dev Dividend pool address (分红池地址)
    address public constant DIVIDEND_POOL = 0x7EfF6A14354445A83E75d4288e608198b9f9878e;
    
    /// @dev Dividend percentage (20%)
    uint256 public constant DIVIDEND_PERCENTAGE = 20;
    
    /// @dev Mapping from token ID to agent state
    mapping(uint256 => State) private _agentStates;
    
    /// @dev Mapping from token ID to agent metadata
    mapping(uint256 => AgentMetadata) private _agentMetadata;
    
    /// @dev Mapping from token ID to agent balance
    mapping(uint256 => uint256) private _agentBalances;
    
    // ============ Constructor ============
    
    /**
     * @dev Initialize the BAP578 contract
     * @param name_ Token name
     * @param symbol_ Token symbol
     * @param registry_ Registry contract address
     */
    constructor(
        string memory name_,
        string memory symbol_,
        address registry_
    ) ERC721(name_, symbol_) Ownable(msg.sender) {
        registry = registry_;
    }
    
    // ============ Modifiers ============
    
    /**
     * @dev Modifier to check if caller is token owner or approved
     */
    modifier onlyTokenOwnerOrApproved(uint256 tokenId) {
        require(
            _isAuthorized(ownerOf(tokenId), msg.sender, tokenId),
            "BAP578: caller is not owner nor approved"
        );
        _;
    }
    
    /**
     * @dev Modifier to check if agent is in active status
     */
    modifier onlyActive(uint256 tokenId) {
        require(
            _agentStates[tokenId].status == Status.Active,
            "BAP578: agent is not active"
        );
        _;
    }
    
    // ============ Core Functions ============
    
    /**
     * @dev Mint a new agent NFT
     * @param to Address to mint the agent to
     * @param logicAddress Logic contract address for the agent
     * @param metadata Initial metadata for the agent
     * @return tokenId The minted token ID
     */
    function mint(
        address to,
        address logicAddress,
        AgentMetadata memory metadata
    ) external onlyOwner returns (uint256) {
        uint256 tokenId = _nextTokenId++;
        _safeMint(to, tokenId);
        
        // Initialize agent state
        _agentStates[tokenId] = State({
            balance: 0,
            status: Status.Active,
            owner: to,
            logicAddress: logicAddress,
            lastActionTimestamp: block.timestamp
        });
        
        // Set metadata
        _agentMetadata[tokenId] = metadata;
        
        // Register with registry if available
        if (registry != address(0)) {
            IRegistry(registry).registerAgent(tokenId, logicAddress);
        }
        
        return tokenId;
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function executeAction(uint256 tokenId, bytes calldata data) 
        external 
        override 
        onlyTokenOwnerOrApproved(tokenId) 
        onlyActive(tokenId) 
    {
        State storage state = _agentStates[tokenId];
        address logic = state.logicAddress;
        
        require(logic != address(0), "BAP578: logic address not set");
        
        // Call logic contract
        (bool success, bytes memory result) = logic.call(data);
        require(success, "BAP578: action execution failed");
        
        // Update last action timestamp
        state.lastActionTimestamp = block.timestamp;
        
        emit ActionExecuted(address(this), result);
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function setLogicAddress(uint256 tokenId, address newLogic) 
        external 
        override 
        onlyTokenOwnerOrApproved(tokenId) 
    {
        require(newLogic != address(0), "BAP578: invalid logic address");
        
        State storage state = _agentStates[tokenId];
        address oldLogic = state.logicAddress;
        state.logicAddress = newLogic;
        
        emit LogicUpgraded(address(this), oldLogic, newLogic);
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function fundAgent(uint256 tokenId) 
        external 
        payable 
        override 
    {
        require(_ownerOf(tokenId) != address(0), "BAP578: token does not exist");
        require(msg.value > 0, "BAP578: must send BNB");
        
        // Calculate dividend (20%)
        uint256 dividendAmount = (msg.value * DIVIDEND_PERCENTAGE) / 100;
        uint256 agentAmount = msg.value - dividendAmount;
        
        // Transfer dividend to pool
        (bool success, ) = DIVIDEND_POOL.call{value: dividendAmount}("");
        require(success, "BAP578: dividend transfer failed");
        
        // Add remaining to agent balance
        _agentBalances[tokenId] += agentAmount;
        _agentStates[tokenId].balance += agentAmount;
        
        emit AgentFunded(address(this), msg.sender, msg.value);
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function getState(uint256 tokenId) 
        external 
        view 
        override 
        returns (State memory) 
    {
        require(_ownerOf(tokenId) != address(0), "BAP578: token does not exist");
        return _agentStates[tokenId];
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function getAgentMetadata(uint256 tokenId) 
        external 
        view 
        override 
        returns (AgentMetadata memory) 
    {
        require(_ownerOf(tokenId) != address(0), "BAP578: token does not exist");
        return _agentMetadata[tokenId];
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function updateAgentMetadata(uint256 tokenId, AgentMetadata memory metadata) 
        external 
        override 
        onlyTokenOwnerOrApproved(tokenId) 
    {
        _agentMetadata[tokenId] = metadata;
        
        emit MetadataUpdated(tokenId, metadata.vaultURI);
    }
    
    // ============ Lifecycle Management ============
    
    /**
     * @inheritdoc IBAP578
     */
    function pause(uint256 tokenId) 
        external 
        override 
        onlyTokenOwnerOrApproved(tokenId) 
        onlyActive(tokenId) 
    {
        _agentStates[tokenId].status = Status.Paused;
        
        emit StatusChanged(address(this), Status.Paused);
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function unpause(uint256 tokenId) 
        external 
        override 
        onlyTokenOwnerOrApproved(tokenId) 
    {
        require(
            _agentStates[tokenId].status == Status.Paused,
            "BAP578: agent is not paused"
        );
        
        _agentStates[tokenId].status = Status.Active;
        
        emit StatusChanged(address(this), Status.Active);
    }
    
    /**
     * @inheritdoc IBAP578
     */
    function terminate(uint256 tokenId) 
        external 
        override 
        onlyTokenOwnerOrApproved(tokenId) 
    {
        require(
            _agentStates[tokenId].status != Status.Terminated,
            "BAP578: agent already terminated"
        );
        
        // Set status to terminated
        _agentStates[tokenId].status = Status.Terminated;
        
        // Return balance to owner
        uint256 balance = _agentBalances[tokenId];
        if (balance > 0) {
            _agentBalances[tokenId] = 0;
            _agentStates[tokenId].balance = 0;
            
            address owner = ownerOf(tokenId);
            (bool success, ) = owner.call{value: balance}("");
            require(success, "BAP578: failed to return balance");
        }
        
        // Deactivate in registry
        if (registry != address(0)) {
            IRegistry(registry).deactivateAgent(tokenId);
        }
        
        emit StatusChanged(address(this), Status.Terminated);
    }
    
    // ============ ERC-165 Support ============
    
    /**
     * @dev See {IERC165-supportsInterface}
     * @notice Implements ERC-165 interface detection for BAP-578
     */
    function supportsInterface(bytes4 interfaceId) 
        public 
        view 
        virtual 
        override(ERC721, ERC721URIStorage) 
        returns (bool) 
    {
        return
            interfaceId == type(IBAP578).interfaceId ||
            super.supportsInterface(interfaceId);
    }
    
    // ============ Internal Overrides ============
    
    /**
     * @dev Override tokenURI to support both ERC721 and ERC721URIStorage
     */
    function tokenURI(uint256 tokenId)
        public
        view
        override(ERC721, ERC721URIStorage)
        returns (string memory)
    {
        return super.tokenURI(tokenId);
    }
    
    // ============ Utility Functions ============
    
    /**
     * @dev Get agent balance
     * @param tokenId Token ID of the agent
     * @return uint256 Agent's BNB balance
     */
    function getAgentBalance(uint256 tokenId) external view returns (uint256) {
        return _agentBalances[tokenId];
    }
    
    /**
     * @dev Update registry address
     * @param newRegistry New registry contract address
     * @notice Only callable by contract owner
     */
    function updateRegistry(address newRegistry) external onlyOwner {
        registry = newRegistry;
    }
    
    /**
     * @dev Withdraw contract balance (emergency function)
     * @notice Only callable by contract owner
     */
    function emergencyWithdraw() external onlyOwner {
        uint256 balance = address(this).balance;
        require(balance > 0, "BAP578: no balance to withdraw");
        
        (bool success, ) = owner().call{value: balance}("");
        require(success, "BAP578: withdrawal failed");
    }
    
    /**
     * @dev Receive function to accept BNB
     * Automatically distributes 20% to dividend pool
     */
    receive() external payable {
        if (msg.value > 0) {
            // Calculate dividend (20%)
            uint256 dividendAmount = (msg.value * DIVIDEND_PERCENTAGE) / 100;
            
            // Transfer dividend to pool
            (bool success, ) = DIVIDEND_POOL.call{value: dividendAmount}("");
            require(success, "BAP578: dividend transfer failed");
        }
    }
    
    /**
     * @dev Get contract addresses
     * @return tokenReceiver Token receiver address
     * @return dividendPool Dividend pool address
     */
    function getAddresses() external pure returns (address tokenReceiver, address dividendPool) {
        return (TOKEN_RECEIVER, DIVIDEND_POOL);
    }
}
