// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title IBAP578
 * @dev Interface for BAP-578 Non-Fungible Agent (NFA) Token Standard
 * @notice This interface extends ERC-721 with agent-specific functionality
 * 
 * BAP-578 defines standardized framework for Non-Fungible Agents (NFAs) -
 * intelligent, autonomous digital entities that combine ownership guarantees
 * of NFTs with adaptive capabilities of artificial intelligence.
 */
interface IBAP578 {
    
    /// @dev Agent operational status
    enum Status { 
        Active,      // Agent can execute actions normally
        Paused,      // Agent is temporarily suspended
        Terminated   // Agent is permanently disabled
    }
    
    /// @dev Agent state information
    struct State {
        uint256 balance;              // BNB balance for gas fees
        Status status;                // Current operational status
        address owner;                // Agent owner address
        address logicAddress;         // Logic contract address
        uint256 lastActionTimestamp;  // Last action execution time
    }

    /// @dev Agent metadata structure
    struct AgentMetadata {
        string persona;       // JSON-encoded character traits, style, tone
        string experience;    // Short summary of agent's role/purpose
        string voiceHash;     // Reference ID to stored audio profile
        string animationURI;  // URI to video or animation file
        string vaultURI;      // URI to agent's vault (extended data storage)
        bytes32 vaultHash;    // Hash of vault contents for verification
    }
    
    // ============ Events ============
    
    /**
     * @dev Emitted when an agent executes an action
     * @param agent Address of the agent token
     * @param result Execution result data
     */
    event ActionExecuted(address indexed agent, bytes result);
    
    /**
     * @dev Emitted when agent's logic contract is upgraded
     * @param agent Address of the agent token
     * @param oldLogic Previous logic contract address
     * @param newLogic New logic contract address
     */
    event LogicUpgraded(address indexed agent, address oldLogic, address newLogic);
    
    /**
     * @dev Emitted when agent receives funding
     * @param agent Address of the agent token
     * @param funder Address of the funder
     * @param amount Amount of BNB funded
     */
    event AgentFunded(address indexed agent, address indexed funder, uint256 amount);
    
    /**
     * @dev Emitted when agent status changes
     * @param agent Address of the agent token
     * @param newStatus New operational status
     */
    event StatusChanged(address indexed agent, Status newStatus);
    
    /**
     * @dev Emitted when agent metadata is updated
     * @param tokenId Token ID of the agent
     * @param metadataURI New metadata URI
     */
    event MetadataUpdated(uint256 indexed tokenId, string metadataURI);
    
    // ============ Core Functions ============
    
    /**
     * @dev Execute an action through the agent's logic contract
     * @param tokenId Token ID of the agent
     * @param data Encoded action data to pass to logic contract
     * @notice Only callable by agent owner or approved operator
     * @notice Agent must be in Active status
     */
    function executeAction(uint256 tokenId, bytes calldata data) external;
    
    /**
     * @dev Update the logic contract address for an agent
     * @param tokenId Token ID of the agent
     * @param newLogic New logic contract address
     * @notice Only callable by agent owner
     * @notice Emits LogicUpgraded event
     */
    function setLogicAddress(uint256 tokenId, address newLogic) external;
    
    /**
     * @dev Fund an agent with BNB for gas fees
     * @param tokenId Token ID of the agent to fund
     * @notice Anyone can fund an agent
     * @notice Emits AgentFunded event
     */
    function fundAgent(uint256 tokenId) external payable;
    
    /**
     * @dev Get current state of an agent
     * @param tokenId Token ID of the agent
     * @return State struct containing agent state information
     */
    function getState(uint256 tokenId) external view returns (State memory);
    
    /**
     * @dev Get metadata of an agent
     * @param tokenId Token ID of the agent
     * @return AgentMetadata struct containing agent metadata
     */
    function getAgentMetadata(uint256 tokenId) external view returns (AgentMetadata memory);
    
    /**
     * @dev Update agent metadata
     * @param tokenId Token ID of the agent
     * @param metadata New metadata to set
     * @notice Only callable by agent owner
     * @notice Emits MetadataUpdated event
     */
    function updateAgentMetadata(uint256 tokenId, AgentMetadata memory metadata) external;
    
    // ============ Lifecycle Management ============
    
    /**
     * @dev Pause an agent temporarily
     * @param tokenId Token ID of the agent
     * @notice Only callable by agent owner
     * @notice Agent must be in Active status
     * @notice Emits StatusChanged event
     */
    function pause(uint256 tokenId) external;
    
    /**
     * @dev Resume a paused agent
     * @param tokenId Token ID of the agent
     * @notice Only callable by agent owner
     * @notice Agent must be in Paused status
     * @notice Emits StatusChanged event
     */
    function unpause(uint256 tokenId) external;
    
    /**
     * @dev Terminate an agent permanently
     * @param tokenId Token ID of the agent
     * @notice Only callable by agent owner
     * @notice Returns agent's balance to owner
     * @notice Cannot be reversed
     * @notice Emits StatusChanged event
     */
    function terminate(uint256 tokenId) external;
}
