// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title IRegistry
 * @dev Interface for BAP-578 Agent Registry
 * @notice Registry contract for managing agent registration and activation on BNB Chain
 */
interface IRegistry {
    
    /// @dev Agent registration information
    struct AgentInfo {
        address tokenContract;    // BAP-578 token contract address
        uint256 tokenId;          // Token ID within the contract
        address logicAddress;     // Logic contract address
        bool isActive;            // Whether agent is active
        uint256 registrationTime; // Timestamp of registration
    }
    
    // ============ Events ============
    
    /**
     * @dev Emitted when an agent is registered
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @param logicAddress Logic contract address
     */
    event AgentRegistered(
        address indexed tokenContract,
        uint256 indexed tokenId,
        address logicAddress
    );
    
    /**
     * @dev Emitted when an agent is activated
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     */
    event AgentActivated(
        address indexed tokenContract,
        uint256 indexed tokenId
    );
    
    /**
     * @dev Emitted when an agent is deactivated
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     */
    event AgentDeactivated(
        address indexed tokenContract,
        uint256 indexed tokenId
    );
    
    // ============ Functions ============
    
    /**
     * @dev Register a new agent in the registry
     * @param tokenId Token ID of the agent
     * @param logicAddress Logic contract address for the agent
     * @notice Only callable by registered BAP-578 token contracts
     * @notice Emits AgentRegistered event
     */
    function registerAgent(uint256 tokenId, address logicAddress) external;
    
    /**
     * @dev Activate a registered agent
     * @param tokenId Token ID of the agent
     * @notice Only callable by the token contract owner
     * @notice Agent must be registered first
     * @notice Emits AgentActivated event
     */
    function activateAgent(uint256 tokenId) external;
    
    /**
     * @dev Deactivate an active agent
     * @param tokenId Token ID of the agent
     * @notice Only callable by the token contract owner
     * @notice Agent must be active
     * @notice Emits AgentDeactivated event
     */
    function deactivateAgent(uint256 tokenId) external;
    
    /**
     * @dev Get agent information from registry
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @return AgentInfo struct containing agent information
     */
    function getAgentInfo(address tokenContract, uint256 tokenId) 
        external 
        view 
        returns (AgentInfo memory);
    
    /**
     * @dev Check if an agent is registered
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @return bool True if agent is registered
     */
    function isRegistered(address tokenContract, uint256 tokenId) 
        external 
        view 
        returns (bool);
    
    /**
     * @dev Check if an agent is active
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @return bool True if agent is active
     */
    function isActive(address tokenContract, uint256 tokenId) 
        external 
        view 
        returns (bool);
}
