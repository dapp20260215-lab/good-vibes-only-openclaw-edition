import { expect } from "chai";
import { ethers } from "hardhat";
import { BAP578, Registry } from "../../typechain-types";
import { SignerWithAddress } from "@nomicfoundation/hardhat-ethers/signers";

describe("BAP578", function () {
  let bap578: BAP578;
  let registry: Registry;
  let owner: SignerWithAddress;
  let user1: SignerWithAddress;
  let user2: SignerWithAddress;
  let logicContract: SignerWithAddress;

  beforeEach(async function () {
    [owner, user1, user2, logicContract] = await ethers.getSigners();

    // Deploy Registry
    const Registry = await ethers.getContractFactory("Registry");
    registry = await Registry.deploy();
    await registry.waitForDeployment();

    // Deploy BAP578
    const BAP578 = await ethers.getContractFactory("BAP578");
    bap578 = await BAP578.deploy(
      "QinTianJian Agent",
      "QTJA",
      await registry.getAddress()
    );
    await bap578.waitForDeployment();

    // Whitelist BAP578 in Registry
    await registry.whitelistContract(await bap578.getAddress());
  });

  describe("Deployment", function () {
    it("Should set the correct name and symbol", async function () {
      expect(await bap578.name()).to.equal("QinTianJian Agent");
      expect(await bap578.symbol()).to.equal("QTJA");
    });

    it("Should set the correct registry address", async function () {
      expect(await bap578.registry()).to.equal(await registry.getAddress());
    });

    it("Should set the correct owner", async function () {
      expect(await bap578.owner()).to.equal(owner.address);
    });
  });

  describe("ERC-165 Interface Support", function () {
    it("Should support BAP-578 interface", async function () {
      // Calculate BAP-578 interface ID
      const bap578InterfaceId = "0x" + (
        BigInt(ethers.id("executeAction(uint256,bytes)").slice(0, 10)) ^
        BigInt(ethers.id("setLogicAddress(uint256,address)").slice(0, 10)) ^
        BigInt(ethers.id("fundAgent(uint256)").slice(0, 10)) ^
        BigInt(ethers.id("getState(uint256)").slice(0, 10)) ^
        BigInt(ethers.id("getAgentMetadata(uint256)").slice(0, 10)) ^
        BigInt(ethers.id("updateAgentMetadata(uint256,(string,string,string,string,string,bytes32))").slice(0, 10)) ^
        BigInt(ethers.id("pause(uint256)").slice(0, 10)) ^
        BigInt(ethers.id("unpause(uint256)").slice(0, 10)) ^
        BigInt(ethers.id("terminate(uint256)").slice(0, 10))
      ).toString(16).padStart(8, '0');

      expect(await bap578.supportsInterface(bap578InterfaceId)).to.be.true;
    });

    it("Should support ERC-721 interface", async function () {
      expect(await bap578.supportsInterface("0x80ac58cd")).to.be.true;
    });

    it("Should support ERC-165 interface", async function () {
      expect(await bap578.supportsInterface("0x01ffc9a7")).to.be.true;
    });
  });

  describe("Minting", function () {
    it("Should mint a new agent NFT", async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);

      expect(await bap578.ownerOf(0)).to.equal(user1.address);
    });

    it("Should initialize agent state correctly", async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);

      const state = await bap578.getState(0);
      expect(state.owner).to.equal(user1.address);
      expect(state.logicAddress).to.equal(logicContract.address);
      expect(state.status).to.equal(0); // Active
      expect(state.balance).to.equal(0);
    });

    it("Should only allow owner to mint", async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await expect(
        bap578.connect(user1).mint(user1.address, logicContract.address, metadata)
      ).to.be.revertedWithCustomError(bap578, "OwnableUnauthorizedAccount");
    });
  });

  describe("Agent Funding", function () {
    beforeEach(async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);
    });

    it("Should allow funding an agent", async function () {
      const fundAmount = ethers.parseEther("1.0");

      await expect(
        bap578.connect(user2).fundAgent(0, { value: fundAmount })
      ).to.emit(bap578, "AgentFunded")
        .withArgs(await bap578.getAddress(), user2.address, fundAmount);

      const balance = await bap578.getAgentBalance(0);
      expect(balance).to.equal(fundAmount);
    });

    it("Should update agent state balance", async function () {
      const fundAmount = ethers.parseEther("1.0");
      await bap578.connect(user2).fundAgent(0, { value: fundAmount });

      const state = await bap578.getState(0);
      expect(state.balance).to.equal(fundAmount);
    });

    it("Should revert if funding amount is zero", async function () {
      await expect(
        bap578.connect(user2).fundAgent(0, { value: 0 })
      ).to.be.revertedWith("BAP578: must send BNB");
    });
  });

  describe("Logic Address Management", function () {
    beforeEach(async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);
    });

    it("Should allow owner to update logic address", async function () {
      const newLogic = user2.address;

      await expect(
        bap578.connect(user1).setLogicAddress(0, newLogic)
      ).to.emit(bap578, "LogicUpgraded")
        .withArgs(await bap578.getAddress(), logicContract.address, newLogic);

      const state = await bap578.getState(0);
      expect(state.logicAddress).to.equal(newLogic);
    });

    it("Should not allow non-owner to update logic address", async function () {
      await expect(
        bap578.connect(user2).setLogicAddress(0, user2.address)
      ).to.be.revertedWith("BAP578: caller is not owner nor approved");
    });

    it("Should revert if new logic address is zero", async function () {
      await expect(
        bap578.connect(user1).setLogicAddress(0, ethers.ZeroAddress)
      ).to.be.revertedWith("BAP578: invalid logic address");
    });
  });

  describe("Lifecycle Management", function () {
    beforeEach(async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);
    });

    it("Should allow owner to pause agent", async function () {
      await expect(
        bap578.connect(user1).pause(0)
      ).to.emit(bap578, "StatusChanged")
        .withArgs(await bap578.getAddress(), 1); // Paused

      const state = await bap578.getState(0);
      expect(state.status).to.equal(1); // Paused
    });

    it("Should allow owner to unpause agent", async function () {
      await bap578.connect(user1).pause(0);

      await expect(
        bap578.connect(user1).unpause(0)
      ).to.emit(bap578, "StatusChanged")
        .withArgs(await bap578.getAddress(), 0); // Active

      const state = await bap578.getState(0);
      expect(state.status).to.equal(0); // Active
    });

    it("Should allow owner to terminate agent", async function () {
      // Fund agent first
      const fundAmount = ethers.parseEther("1.0");
      await bap578.connect(user2).fundAgent(0, { value: fundAmount });

      const balanceBefore = await ethers.provider.getBalance(user1.address);

      await expect(
        bap578.connect(user1).terminate(0)
      ).to.emit(bap578, "StatusChanged")
        .withArgs(await bap578.getAddress(), 2); // Terminated

      const state = await bap578.getState(0);
      expect(state.status).to.equal(2); // Terminated
      expect(state.balance).to.equal(0);

      const balanceAfter = await ethers.provider.getBalance(user1.address);
      expect(balanceAfter).to.be.gt(balanceBefore);
    });
  });

  describe("Metadata Management", function () {
    beforeEach(async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);
    });

    it("Should return correct metadata", async function () {
      const metadata = await bap578.getAgentMetadata(0);
      expect(metadata.persona).to.equal("Helpful AI assistant");
      expect(metadata.experience).to.equal("General purpose agent");
    });

    it("Should allow owner to update metadata", async function () {
      const newMetadata = {
        persona: "Updated persona",
        experience: "Updated experience",
        voiceHash: "newvoice",
        animationURI: "https://example.com/new-animation.mp4",
        vaultURI: "https://example.com/new-vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("new vault data"))
      };

      await expect(
        bap578.connect(user1).updateAgentMetadata(0, newMetadata)
      ).to.emit(bap578, "MetadataUpdated")
        .withArgs(0, newMetadata.vaultURI);

      const metadata = await bap578.getAgentMetadata(0);
      expect(metadata.persona).to.equal("Updated persona");
    });
  });

  describe("Registry Integration", function () {
    it("Should register agent in registry on mint", async function () {
      const metadata = {
        persona: "Helpful AI assistant",
        experience: "General purpose agent",
        voiceHash: "voice123",
        animationURI: "https://example.com/animation.mp4",
        vaultURI: "https://example.com/vault",
        vaultHash: ethers.keccak256(ethers.toUtf8Bytes("vault data"))
      };

      await bap578.mint(user1.address, logicContract.address, metadata);

      const isRegistered = await registry.isRegistered(await bap578.getAddress(), 0);
      expect(isRegistered).to.be.true;
    });
  });
});
