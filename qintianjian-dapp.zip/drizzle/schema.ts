import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// 卦象NFT表
export const divinations = mysqlTable("divinations", {
  id: int("id").autoincrement().primaryKey(),
  tokenId: varchar("tokenId", { length: 255 }).notNull().unique(),
  hexagram: varchar("hexagram", { length: 64 }).notNull(), // 64卦编号
  hexagramName: varchar("hexagramName", { length: 100 }).notNull(),
  interpretation: text("interpretation"), // 卦辞解释
  ownerAddress: varchar("ownerAddress", { length: 42 }).notNull(),
  transactionHash: varchar("transactionHash", { length: 66 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Divination = typeof divinations.$inferSelect;
export type InsertDivination = typeof divinations.$inferInsert;

// 预测市场表
export const predictions = mysqlTable("predictions", {
  id: int("id").autoincrement().primaryKey(),
  divinationId: int("divinationId").notNull(),
  question: text("question").notNull(),
  totalStakeYes: varchar("totalStakeYes", { length: 78 }).default("0").notNull(), // Wei格式
  totalStakeNo: varchar("totalStakeNo", { length: 78 }).default("0").notNull(),
  deadline: timestamp("deadline").notNull(),
  resolved: int("resolved").default(0).notNull(), // 0=未解决, 1=已解决
  outcome: int("outcome"), // null=未解决, 1=Yes, 0=No
  creatorAddress: varchar("creatorAddress", { length: 42 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;

// 预测市场下注记录表
export const predictionStakes = mysqlTable("predictionStakes", {
  id: int("id").autoincrement().primaryKey(),
  predictionId: int("predictionId").notNull(),
  stakerAddress: varchar("stakerAddress", { length: 42 }).notNull(),
  isYes: int("isYes").notNull(), // 1=Yes, 0=No
  amount: varchar("amount", { length: 78 }).notNull(), // Wei格式
  claimed: int("claimed").default(0).notNull(), // 0=未领取, 1=已领取
  transactionHash: varchar("transactionHash", { length: 66 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PredictionStake = typeof predictionStakes.$inferSelect;
export type InsertPredictionStake = typeof predictionStakes.$inferInsert;

// 质押记录表
export const stakes = mysqlTable("stakes", {
  id: int("id").autoincrement().primaryKey(),
  userAddress: varchar("userAddress", { length: 42 }).notNull().unique(),
  amount: varchar("amount", { length: 78 }).notNull(), // Wei格式
  startTime: timestamp("startTime").notNull(),
  lastClaimTime: timestamp("lastClaimTime"),
  totalRewards: varchar("totalRewards", { length: 78 }).default("0").notNull(),
  status: mysqlEnum("status", ["active", "unstaked"]).default("active").notNull(),
  transactionHash: varchar("transactionHash", { length: 66 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Stake = typeof stakes.$inferSelect;
export type InsertStake = typeof stakes.$inferInsert;

// AI问卜记录表
export const aiDivinations = mysqlTable("aiDivinations", {
  id: int("id").autoincrement().primaryKey(),
  userAddress: varchar("userAddress", { length: 42 }).notNull(),
  question: text("question").notNull(),
  hexagram: varchar("hexagram", { length: 64 }),
  interpretation: text("interpretation"),
  transactionHash: varchar("transactionHash", { length: 66 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AiDivination = typeof aiDivinations.$inferSelect;
export type InsertAiDivination = typeof aiDivinations.$inferInsert;

// 交易记录表
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  fromAddress: varchar("fromAddress", { length: 42 }).notNull(),
  toAddress: varchar("toAddress", { length: 42 }),
  amount: varchar("amount", { length: 78 }),
  tokenType: mysqlEnum("tokenType", ["QTJ", "BNB"]).notNull(),
  transactionType: mysqlEnum("transactionType", ["divination", "ai_divination", "prediction_stake", "stake", "unstake", "donation", "transfer"]).notNull(),
  transactionHash: varchar("transactionHash", { length: 66 }).notNull().unique(),
  status: mysqlEnum("status", ["pending", "confirmed", "failed"]).default("pending").notNull(),
  gasUsed: varchar("gasUsed", { length: 78 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

// 捐赠记录表
export const donations = mysqlTable("donations", {
  id: int("id").autoincrement().primaryKey(),
  donorAddress: varchar("donorAddress", { length: 42 }).notNull(),
  recipientAddress: varchar("recipientAddress", { length: 42 }).notNull(),
  amount: varchar("amount", { length: 78 }).notNull(),
  transactionHash: varchar("transactionHash", { length: 66 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Donation = typeof donations.$inferSelect;
export type InsertDonation = typeof donations.$inferInsert;