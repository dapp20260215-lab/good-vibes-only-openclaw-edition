CREATE TABLE `aiDivinations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userAddress` varchar(42) NOT NULL,
	`question` text NOT NULL,
	`hexagram` varchar(64),
	`interpretation` text,
	`transactionHash` varchar(66),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiDivinations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `divinations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tokenId` varchar(255) NOT NULL,
	`hexagram` varchar(64) NOT NULL,
	`hexagramName` varchar(100) NOT NULL,
	`interpretation` text,
	`ownerAddress` varchar(42) NOT NULL,
	`transactionHash` varchar(66),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `divinations_id` PRIMARY KEY(`id`),
	CONSTRAINT `divinations_tokenId_unique` UNIQUE(`tokenId`)
);
--> statement-breakpoint
CREATE TABLE `donations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`donorAddress` varchar(42) NOT NULL,
	`recipientAddress` varchar(42) NOT NULL,
	`amount` varchar(78) NOT NULL,
	`transactionHash` varchar(66),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `donations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `predictionStakes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`predictionId` int NOT NULL,
	`stakerAddress` varchar(42) NOT NULL,
	`isYes` int NOT NULL,
	`amount` varchar(78) NOT NULL,
	`claimed` int NOT NULL DEFAULT 0,
	`transactionHash` varchar(66),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `predictionStakes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `predictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`divinationId` int NOT NULL,
	`question` text NOT NULL,
	`totalStakeYes` varchar(78) NOT NULL DEFAULT '0',
	`totalStakeNo` varchar(78) NOT NULL DEFAULT '0',
	`deadline` timestamp NOT NULL,
	`resolved` int NOT NULL DEFAULT 0,
	`outcome` int,
	`creatorAddress` varchar(42) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `predictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stakes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userAddress` varchar(42) NOT NULL,
	`amount` varchar(78) NOT NULL,
	`startTime` timestamp NOT NULL,
	`lastClaimTime` timestamp,
	`totalRewards` varchar(78) NOT NULL DEFAULT '0',
	`status` enum('active','unstaked') NOT NULL DEFAULT 'active',
	`transactionHash` varchar(66),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stakes_id` PRIMARY KEY(`id`),
	CONSTRAINT `stakes_userAddress_unique` UNIQUE(`userAddress`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fromAddress` varchar(42) NOT NULL,
	`toAddress` varchar(42),
	`amount` varchar(78),
	`tokenType` enum('QTJ','BNB') NOT NULL,
	`transactionType` enum('divination','ai_divination','prediction_stake','stake','unstake','donation','transfer') NOT NULL,
	`transactionHash` varchar(66) NOT NULL,
	`status` enum('pending','confirmed','failed') NOT NULL DEFAULT 'pending',
	`gasUsed` varchar(78),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_transactionHash_unique` UNIQUE(`transactionHash`)
);
