import { z } from 'zod'
import { publicProcedure, router } from '../_core/trpc'
import { invokeLLM } from '../_core/llm'
import { HEXAGRAMS } from '../../client/src/lib/hexagrams'

export const aiRouter = router({
  // AI问卜
  divination: publicProcedure
    .input(
      z.object({
        question: z.string().min(1).max(500),
      })
    )
    .mutation(async ({ input }) => {
      // 生成卦象
      const hexagramResult = generateHexagramInternal()
      const hexagram = hexagramResult.hexagram
      const interpretation = getHexagramInterpretationInternal(hexagram)

      // 调用LLM进行深度解读
      const prompt = `你是一位精通易经的占卜大师。用户问了以下问题：

"${input.question}"

根据易经占卜，得到了【${hexagram.name}卦】，卦象为：${hexagram.symbol}

卦辞：${interpretation}

请你：
1. 结合用户的问题和卦象，给出深入的解读
2. 分析当前形势和未来趋势
3. 提供具体的建议和注意事项
4. 语言要专业但易懂，富有哲理

请用中文回答，字数控制在300-500字。`

      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: '你是一位精通易经的占卜大师，擅长结合易经智慧为用户解答人生疑惑。',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
      })

      const aiInterpretation = response.choices[0]?.message?.content || '抱歉，AI解读失败，请重试。'

      return {
        hexagram: hexagram.name,
        hexagramId: hexagram.id,
        symbol: hexagram.symbol,
        interpretation: aiInterpretation,
      }
    }),
})

// 辅助函数：生成卦象（使用64个卦轮流出现）
function generateHexagramInternal() {
  // 直接随机选择一个卦象，确保64个卦都有机会出现
  const randomIndex = Math.floor(Math.random() * HEXAGRAMS.length)
  const hexagram = HEXAGRAMS[randomIndex]
  
  // 根据卦象的binary生成lines
  const lines = hexagram.binary.split('').map(bit => {
    // 将binary转换为符合易经的算法：1->阳爷(9)，0->阴爷(6)
    return bit === '1' ? 9 : 6
  })
  
  return {
    hexagram,
    lines,
    binary: hexagram.binary,
  }
}

function getHexagramInterpretationInternal(hexagram: any) {
  return hexagram.description
}
