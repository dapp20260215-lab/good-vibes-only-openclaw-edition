import { z } from 'zod'
import { publicProcedure, protectedProcedure, router } from '../_core/trpc'
import { getDb } from '../db'
import { transactions, divinations, aiDivinations, stakes, predictions, predictionStakes } from '../../drizzle/schema'
import { eq, desc, or, and } from 'drizzle-orm'

export const historyRouter = router({
  // 获取用户的所有交易记录
  getUserTransactions: protectedProcedure
    .input(
      z.object({
        walletAddress: z.string(),
        type: z.enum(['all', 'divination', 'ai', 'staking', 'transfer', 'prediction']).optional(),
        limit: z.number().min(1).max(100).default(50),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const { walletAddress, type, limit } = input

      // 查询所有交易记录
      const txList = await db
        .select()
        .from(transactions)
        .where(
          or(
            eq(transactions.fromAddress, walletAddress),
            eq(transactions.toAddress, walletAddress)
          )
        )
        .orderBy(desc(transactions.createdAt))
        .limit(limit)

      // 如果指定了类型，过滤结果
      if (type && type !== 'all') {
        return txList.filter((tx) => tx.transactionType === type)
      }

      return txList
    }),

  // 获取用户的起卦历史
  getDivinationHistory: protectedProcedure
    .input(z.object({ walletAddress: z.string(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const history = await db
        .select()
        .from(divinations)
        .where(eq(divinations.ownerAddress, input.walletAddress))
        .orderBy(desc(divinations.createdAt))
        .limit(input.limit)

      return history
    }),

  // 获取用户的AI问卜历史
  getAIDivinationHistory: protectedProcedure
    .input(z.object({ walletAddress: z.string(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const history = await db
        .select()
        .from(aiDivinations)
        .where(eq(aiDivinations.userAddress, input.walletAddress))
        .orderBy(desc(aiDivinations.createdAt))
        .limit(input.limit)

      return history
    }),

  // 获取用户的质押历史
  getStakingHistory: protectedProcedure
    .input(z.object({ walletAddress: z.string(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const history = await db
        .select()
        .from(stakes)
        .where(eq(stakes.userAddress, input.walletAddress))
        .orderBy(desc(stakes.createdAt))
        .limit(input.limit)

      return history
    }),

  // 获取用户的预测下注历史
  getBettingHistory: protectedProcedure
    .input(z.object({ walletAddress: z.string(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const history = await db
        .select()
        .from(predictionStakes)
        .where(eq(predictionStakes.stakerAddress, input.walletAddress))
        .orderBy(desc(predictionStakes.createdAt))
        .limit(input.limit)

      return history
    }),

  // 获取聚合的活动历史（所有类型）
  getActivityHistory: protectedProcedure
    .input(z.object({ walletAddress: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const activities: Array<{
        id: number
        type: string
        title: string
        description: string
        amount?: string
        status: string
        txHash?: string
        createdAt: Date
      }> = []

      // 查询起卦记录
      const divinationList = await db
        .select()
        .from(divinations)
        .where(eq(divinations.ownerAddress, input.walletAddress))
        .orderBy(desc(divinations.createdAt))
        .limit(10)

      divinationList.forEach((d) => {
        activities.push({
          id: d.id,
          type: 'divination',
          title: '三铜钱起卦',
          description: `获得卦象: ${d.hexagramName}`,
          amount: '2000 钦天监',
          status: 'completed',
          txHash: d.transactionHash || undefined,
          createdAt: d.createdAt,
        })
      })

      // 查询AI问卜记录
      const aiList = await db
        .select()
        .from(aiDivinations)
        .where(eq(aiDivinations.userAddress, input.walletAddress))
        .orderBy(desc(aiDivinations.createdAt))
        .limit(10)

      aiList.forEach((ai) => {
        activities.push({
          id: ai.id,
          type: 'ai_divination',
          title: 'AI问卜',
          description: ai.question.substring(0, 50) + (ai.question.length > 50 ? '...' : ''),
          amount: '2000 钦天监',
          status: 'completed',
          txHash: ai.transactionHash || undefined,
          createdAt: ai.createdAt,
        })
      })

      // 查询质押记录
      const stakingList = await db
        .select()
        .from(stakes)
        .where(eq(stakes.userAddress, input.walletAddress))
        .orderBy(desc(stakes.createdAt))
        .limit(10)

      stakingList.forEach((s) => {
        const isActive = s.status === 'active'
        activities.push({
          id: s.id,
          type: 'staking',
          title: isActive ? '质押钦天监' : '赎回质押',
          description: `质押金额: ${s.amount} 钦天监`,
          amount: `${s.amount} 钦天监`,
          status: s.status,
          txHash: s.transactionHash || undefined,
          createdAt: s.createdAt,
        })
      })

      // 查询下注记录
      const betList = await db
        .select()
        .from(predictionStakes)
        .where(eq(predictionStakes.stakerAddress, input.walletAddress))
        .orderBy(desc(predictionStakes.createdAt))
        .limit(10)

      betList.forEach((b) => {
        activities.push({
          id: b.id,
          type: 'betting',
          title: '预测市场下注',
          description: `下注方向: ${b.isYes === 1 ? '看涨' : '看跌'}`,
          amount: `${b.amount} BNB`,
          status: b.claimed === 1 ? 'completed' : 'pending',
          txHash: b.transactionHash || undefined,
          createdAt: b.createdAt,
        })
      })

      // 查询交易记录
      const txList = await db
        .select()
        .from(transactions)
        .where(
          or(
            eq(transactions.fromAddress, input.walletAddress),
            eq(transactions.toAddress, input.walletAddress)
          )
        )
        .orderBy(desc(transactions.createdAt))
        .limit(10)

      txList.forEach((tx) => {
        const isReceive = tx.toAddress && tx.toAddress.toLowerCase() === input.walletAddress.toLowerCase()
        activities.push({
          id: tx.id,
          type: 'transfer',
          title: isReceive ? '接收代币' : '转账代币',
          description: isReceive
            ? `从 ${tx.fromAddress.substring(0, 6)}...${tx.fromAddress.substring(38)} 接收`
            : tx.toAddress
            ? `转给 ${tx.toAddress.substring(0, 6)}...${tx.toAddress.substring(38)}`
            : '转账',
          amount: `${tx.amount || '0'} ${tx.tokenType}`,
          status: tx.status,
          txHash: tx.transactionHash,
          createdAt: tx.createdAt,
        })
      })

      // 按时间倒序排序
      activities.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())

      return activities.slice(0, 50)
    }),
})
