import { z } from 'zod'
import { publicProcedure, protectedProcedure, router } from '../_core/trpc'
import { getDb } from '../db'
import { predictions, predictionStakes, divinations } from '../../drizzle/schema'
import { eq, and, desc } from 'drizzle-orm'
import { TRPCError } from '@trpc/server'

export const marketRouter = router({
  // 创建预测
  create: protectedProcedure
    .input(
      z.object({
        divinationId: z.number(),
        question: z.string().min(1).max(500),
        deadline: z.date(),
        creatorAddress: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb()
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: '数据库连接失败' })

      // 验证用户拥有该卦象NFT
      const divinationsList = await db
        .select()
        .from(divinations)
        .where(and(eq(divinations.id, input.divinationId), eq(divinations.ownerAddress, input.creatorAddress)))
        .limit(1)

      if (divinationsList.length === 0) {
        throw new TRPCError({ code: 'FORBIDDEN', message: '您不拥有该卦象NFT' })
      }

      // 创建预测
      const [prediction] = await db.insert(predictions).values({
        divinationId: input.divinationId,
        question: input.question,
        deadline: input.deadline,
        creatorAddress: input.creatorAddress,
        totalStakeYes: '0',
        totalStakeNo: '0',
        resolved: 0,
        outcome: null,
      })

      return { id: prediction.insertId, success: true }
    }),

  // 获取预测列表
  list: publicProcedure
    .input(
      z
        .object({
          resolved: z.number().optional(), // 0=未解决, 1=已解决
          limit: z.number().min(1).max(100).default(20),
          offset: z.number().min(0).default(0),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const { resolved, limit = 20, offset = 0 } = input || {}

      let query = db.select().from(predictions)

      if (resolved !== undefined) {
        query = query.where(eq(predictions.resolved, resolved)) as any
      }

      const results = await query.orderBy(desc(predictions.createdAt)).limit(limit).offset(offset)

      return results
    }),

  // 获取预测详情
  getById: publicProcedure.input(z.number()).query(async ({ input }) => {
    const db = await getDb()
    if (!db) return null

    const predictionsList = await db
      .select()
      .from(predictions)
      .where(eq(predictions.id, input))
      .limit(1)

    if (predictionsList.length === 0) return null

    return predictionsList[0]
  }),

  // 下注
  placeBet: protectedProcedure
    .input(
      z.object({
        predictionId: z.number(),
        isYes: z.number().min(0).max(1), // 1=Yes, 0=No
        amount: z.string(), // Wei格式的BNB数量
        stakerAddress: z.string(),
        txHash: z.string(), // BNB转账交易哈希
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb()
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: '数据库连接失败' })

      // 获取预测
      const predictionsList = await db
        .select()
        .from(predictions)
        .where(eq(predictions.id, input.predictionId))
        .limit(1)

      if (predictionsList.length === 0) {
        throw new TRPCError({ code: 'NOT_FOUND', message: '预测不存在' })
      }

      const prediction = predictionsList[0]

      if (prediction.resolved === 1) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: '该预测已结算' })
      }

      // 检查是否已经下注
      const existingStakeList = await db
        .select()
        .from(predictionStakes)
        .where(
          and(
            eq(predictionStakes.predictionId, input.predictionId),
            eq(predictionStakes.stakerAddress, input.stakerAddress)
          )
        )
        .limit(1)

      if (existingStakeList.length > 0) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: '您已经在该预测中下注' })
      }

      // 创建下注记录
      await db.insert(predictionStakes).values({
        predictionId: input.predictionId,
        stakerAddress: input.stakerAddress,
        isYes: input.isYes,
        amount: input.amount,
        transactionHash: input.txHash,
        claimed: 0,
      })

      // 更新预测池
      const amountBigInt = BigInt(input.amount)
      const totalStakeYes =
        input.isYes === 1
          ? (BigInt(prediction.totalStakeYes) + amountBigInt).toString()
          : prediction.totalStakeYes
      const totalStakeNo =
        input.isYes === 0
          ? (BigInt(prediction.totalStakeNo) + amountBigInt).toString()
          : prediction.totalStakeNo

      await db
        .update(predictions)
        .set({
          totalStakeYes,
          totalStakeNo,
        })
        .where(eq(predictions.id, input.predictionId))

      return { success: true }
    }),

  // 获取用户在某个预测中的下注
  getUserStake: protectedProcedure
    .input(
      z.object({
        predictionId: z.number(),
        stakerAddress: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return null

      const stakeList = await db
        .select()
        .from(predictionStakes)
        .where(
          and(
            eq(predictionStakes.predictionId, input.predictionId),
            eq(predictionStakes.stakerAddress, input.stakerAddress)
          )
        )
        .limit(1)

      return stakeList.length > 0 ? stakeList[0] : null
    }),

  // 结算预测
  settle: protectedProcedure
    .input(
      z.object({
        predictionId: z.number(),
        outcome: z.number().min(0).max(1), // 1=Yes, 0=No
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb()
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: '数据库连接失败' })

      // 获取预测
      const predictionsList = await db
        .select()
        .from(predictions)
        .where(eq(predictions.id, input.predictionId))
        .limit(1)

      if (predictionsList.length === 0) {
        throw new TRPCError({ code: 'NOT_FOUND', message: '预测不存在' })
      }

      const prediction = predictionsList[0]

      // 只有创建者可以结算
      if (prediction.creatorAddress.toLowerCase() !== ctx.user.openId.toLowerCase()) {
        throw new TRPCError({ code: 'FORBIDDEN', message: '只有创建者可以结算预测' })
      }

      if (prediction.resolved === 1) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: '该预测已结算' })
      }

      // 更新预测状态
      await db
        .update(predictions)
        .set({
          resolved: 1,
          outcome: input.outcome,
        })
        .where(eq(predictions.id, input.predictionId))

      return { success: true }
    }),

  // 获取用户的所有下注
  getUserStakes: protectedProcedure
    .input(z.object({ stakerAddress: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const userStakes = await db
        .select()
        .from(predictionStakes)
        .where(eq(predictionStakes.stakerAddress, input.stakerAddress))
        .orderBy(desc(predictionStakes.createdAt))

      return userStakes
    }),

  // 领取奖励
  claimReward: protectedProcedure
    .input(
      z.object({
        predictionId: z.number(),
        stakerAddress: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb()
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: '数据库连接失败' })

      // 获取预测
      const predictionsList = await db
        .select()
        .from(predictions)
        .where(eq(predictions.id, input.predictionId))
        .limit(1)

      if (predictionsList.length === 0) {
        throw new TRPCError({ code: 'NOT_FOUND', message: '预测不存在' })
      }

      const prediction = predictionsList[0]

      if (prediction.resolved === 0) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: '预测尚未结算' })
      }

      // 获取用户的下注
      const stakeList = await db
        .select()
        .from(predictionStakes)
        .where(
          and(
            eq(predictionStakes.predictionId, input.predictionId),
            eq(predictionStakes.stakerAddress, input.stakerAddress)
          )
        )
        .limit(1)

      if (stakeList.length === 0) {
        throw new TRPCError({ code: 'NOT_FOUND', message: '未找到下注记录' })
      }

      const stake = stakeList[0]

      if (stake.claimed === 1) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: '奖励已领取' })
      }

      // 检查是否获胜
      if (stake.isYes !== prediction.outcome) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: '您的预测未获胜' })
      }

      // 计算奖励
      const totalPool = BigInt(prediction.totalStakeYes) + BigInt(prediction.totalStakeNo)
      const winningPool = prediction.outcome === 1 ? BigInt(prediction.totalStakeYes) : BigInt(prediction.totalStakeNo)
      const userStake = BigInt(stake.amount)
      const reward = (userStake * totalPool) / winningPool

      // 标记为已领取
      await db
        .update(predictionStakes)
        .set({ claimed: 1 })
        .where(eq(predictionStakes.id, stake.id))

      return {
        success: true,
        reward: reward.toString(),
      }
    }),
})
