import { z } from 'zod'
import { publicProcedure, protectedProcedure, router } from '../_core/trpc'
import { getDb } from '../db'
import { divinations } from '../../drizzle/schema'
import { eq, desc } from 'drizzle-orm'
import { TRPCError } from '@trpc/server'

export const nftRouter = router({
  // 获取用户的所有NFT
  getUserNFTs: protectedProcedure
    .input(z.object({ ownerAddress: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      const nfts = await db
        .select()
        .from(divinations)
        .where(eq(divinations.ownerAddress, input.ownerAddress))
        .orderBy(desc(divinations.createdAt))

      return nfts
    }),

  // 获取NFT详情
  getNFTById: publicProcedure.input(z.number()).query(async ({ input }) => {
    const db = await getDb()
    if (!db) return null

    const nftList = await db
      .select()
      .from(divinations)
      .where(eq(divinations.id, input))
      .limit(1)

    return nftList.length > 0 ? nftList[0] : null
  }),

  // 转账NFT
  transferNFT: protectedProcedure
    .input(
      z.object({
        nftId: z.number(),
        fromAddress: z.string(),
        toAddress: z.string(),
        txHash: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb()
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: '数据库连接失败' })

      // 验证NFT所有权
      const nftList = await db
        .select()
        .from(divinations)
        .where(eq(divinations.id, input.nftId))
        .limit(1)

      if (nftList.length === 0) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'NFT不存在' })
      }

      const nft = nftList[0]
      if (nft.ownerAddress.toLowerCase() !== input.fromAddress.toLowerCase()) {
        throw new TRPCError({ code: 'FORBIDDEN', message: '您不是该NFT的所有者' })
      }

      // 更新所有者
      await db
        .update(divinations)
        .set({
          ownerAddress: input.toAddress,
          transactionHash: input.txHash,
        })
        .where(eq(divinations.id, input.nftId))

      return { success: true }
    }),

  // 获取NFT总数统计
  getNFTStats: publicProcedure.query(async () => {
    const db = await getDb()
    if (!db) return { total: 0 }

    const result = await db.select().from(divinations)

    return {
      total: result.length,
    }
  }),
})
