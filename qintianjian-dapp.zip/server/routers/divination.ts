import { z } from 'zod'
import { publicProcedure, router } from '../_core/trpc'
import { getDb } from '../db'
import { divinations } from '../../drizzle/schema'

export const divinationRouter = router({
  // 创建卦象NFT
  create: publicProcedure
    .input(
      z.object({
        hexagram: z.string(),
        hexagramId: z.string(),
        binary: z.string(),
        interpretation: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // 注意：实际应该验证用户已经支付了2000 QTJ代币
      // 这里简化处理，实际应该监听合约事件或验证交易
      
      const db = await getDb()
      if (!db) {
        throw new Error('Database not available')
      }

      // 生成唯一的tokenId
      const tokenId = `QTJ-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

      // 假设用户地址（实际应该从ctx.user或钱包签名获取）
      const ownerAddress = '0x0000000000000000000000000000000000000000'

      await db.insert(divinations).values({
        tokenId,
        hexagram: input.binary,
        hexagramName: input.hexagram,
        interpretation: input.interpretation,
        ownerAddress,
        transactionHash: null,
      })

      return {
        success: true,
        tokenId,
        hexagram: input.hexagram,
      }
    }),

  // 获取用户的所有卦象NFT
  list: publicProcedure
    .input(z.object({ address: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) {
        return []
      }

      // 这里简化处理，实际应该从合约读取NFT所有权
      return []
    }),

  // 获取单个卦象详情
  get: publicProcedure
    .input(z.object({ tokenId: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) {
        return null
      }

      // 查询数据库
      return null
    }),
})
