/**
 * 卦象SVG生成器
 * 为64卦生成独特的SVG图像
 */

// 卦爻类型
type YaoType = 'yang' | 'yin' // 阳爻（实线）或阴爻（虚线）

// 卦象配置
interface HexagramConfig {
  number: number
  name: string
  upperTrigram: YaoType[]
  lowerTrigram: YaoType[]
  colors: {
    primary: string
    secondary: string
    background: string
  }
}

// 八卦基础配置
const TRIGRAMS: Record<string, YaoType[]> = {
  乾: ['yang', 'yang', 'yang'], // ☰
  兑: ['yin', 'yang', 'yang'],  // ☱
  离: ['yang', 'yin', 'yang'],  // ☲
  震: ['yin', 'yin', 'yang'],   // ☳
  巽: ['yang', 'yang', 'yin'],  // ☴
  坎: ['yin', 'yang', 'yin'],   // ☵
  艮: ['yang', 'yin', 'yin'],   // ☶
  坤: ['yin', 'yin', 'yin'],    // ☷
}

// 64卦配色方案
const COLOR_SCHEMES = [
  { primary: '#FF6B6B', secondary: '#4ECDC4', background: '#1A1A2E' },
  { primary: '#95E1D3', secondary: '#F38181', background: '#0F3460' },
  { primary: '#FFD93D', secondary: '#6BCB77', background: '#4D96FF' },
  { primary: '#A8E6CF', secondary: '#FFD3B6', background: '#FF8B94' },
  { primary: '#667EEA', secondary: '#F093FB', background: '#4FACFE' },
  { primary: '#FA709A', secondary: '#FEE140', background: '#30CFD0' },
  { primary: '#A8EDEA', secondary: '#FED6E3', background: '#8E2DE2' },
  { primary: '#FEC163', secondary: '#DE4313', background: '#13547A' },
]

/**
 * 生成卦爻SVG路径
 */
function generateYaoPath(yaoType: YaoType, y: number, width: number): string {
  const height = 8
  const gap = 20
  
  if (yaoType === 'yang') {
    // 阳爻：实线
    return `<rect x="0" y="${y}" width="${width}" height="${height}" rx="4" fill="currentColor"/>`
  } else {
    // 阴爻：虚线（两段）
    const segmentWidth = (width - gap) / 2
    return `
      <rect x="0" y="${y}" width="${segmentWidth}" height="${height}" rx="4" fill="currentColor"/>
      <rect x="${segmentWidth + gap}" y="${y}" width="${segmentWidth}" height="${height}" rx="4" fill="currentColor"/>
    `
  }
}

/**
 * 生成卦象SVG
 */
export function generateHexagramSVG(hexagramNumber: number, hexagramName: string): string {
  // 根据卦象编号选择配色
  const colorScheme = COLOR_SCHEMES[(hexagramNumber - 1) % COLOR_SCHEMES.length]
  
  // 获取上下卦（这里简化处理，实际应该根据64卦表查询）
  // 为了演示，我们基于卦象编号生成伪随机的卦爻
  const upperTrigram = getTrigramByIndex(Math.floor((hexagramNumber - 1) / 8))
  const lowerTrigram = getTrigramByIndex((hexagramNumber - 1) % 8)
  
  const yaos = [...lowerTrigram, ...upperTrigram] // 从下往上
  
  const width = 200
  const height = 300
  const yaoWidth = 160
  const yaoSpacing = 30
  const startY = 50
  
  // 生成卦爻路径
  const yaoPaths = yaos.map((yao, index) => {
    const y = startY + index * yaoSpacing
    return generateYaoPath(yao, y, yaoWidth)
  }).join('\n')
  
  // 生成装饰性圆圈
  const circles = yaos.map((_, index) => {
    const y = startY + index * yaoSpacing + 4
    return `<circle cx="-15" cy="${y}" r="3" fill="${colorScheme.secondary}" opacity="0.6"/>`
  }).join('\n')
  
  return `
<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg-gradient-${hexagramNumber}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:${colorScheme.background};stop-opacity:1" />
      <stop offset="100%" style="stop-color:${darkenColor(colorScheme.background, 20)};stop-opacity:1" />
    </linearGradient>
    <filter id="glow-${hexagramNumber}">
      <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>
  
  <!-- 背景 -->
  <rect width="${width}" height="${height}" fill="url(#bg-gradient-${hexagramNumber})" rx="12"/>
  
  <!-- 装饰性边框 -->
  <rect x="2" y="2" width="${width - 4}" height="${height - 4}" fill="none" stroke="${colorScheme.primary}" stroke-width="2" rx="10" opacity="0.3"/>
  
  <!-- 卦象主体 -->
  <g transform="translate(20, 0)" color="${colorScheme.primary}" filter="url(#glow-${hexagramNumber})">
    ${yaoPaths}
  </g>
  
  <!-- 装饰性圆圈 -->
  <g transform="translate(20, 0)">
    ${circles}
  </g>
  
  <!-- 卦象名称 -->
  <text x="${width / 2}" y="${height - 30}" font-family="'Noto Serif SC', serif" font-size="24" font-weight="bold" fill="${colorScheme.primary}" text-anchor="middle" filter="url(#glow-${hexagramNumber})">
    ${hexagramName}
  </text>
  
  <!-- 卦象编号 -->
  <text x="${width / 2}" y="${height - 10}" font-family="'Noto Sans SC', sans-serif" font-size="12" fill="${colorScheme.secondary}" text-anchor="middle" opacity="0.8">
    第${hexagramNumber}卦
  </text>
</svg>
  `.trim()
}

/**
 * 根据索引获取三爻卦
 */
function getTrigramByIndex(index: number): YaoType[] {
  const trigrams = Object.values(TRIGRAMS)
  return trigrams[index % trigrams.length]
}

/**
 * 颜色加深函数
 */
function darkenColor(color: string, percent: number): string {
  const num = parseInt(color.replace('#', ''), 16)
  const amt = Math.round(2.55 * percent)
  const R = (num >> 16) - amt
  const G = (num >> 8 & 0x00FF) - amt
  const B = (num & 0x0000FF) - amt
  return '#' + (
    0x1000000 +
    (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
    (G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
    (B < 255 ? (B < 1 ? 0 : B) : 255)
  ).toString(16).slice(1)
}

/**
 * 将SVG转换为Data URL
 */
export function svgToDataURL(svg: string): string {
  const encoded = encodeURIComponent(svg)
    .replace(/'/g, '%27')
    .replace(/"/g, '%22')
  return `data:image/svg+xml,${encoded}`
}

/**
 * 生成卦象预览图（用于NFT卡片）
 */
export function generateHexagramPreview(hexagramNumber: number, hexagramName: string): string {
  const svg = generateHexagramSVG(hexagramNumber, hexagramName)
  return svgToDataURL(svg)
}
