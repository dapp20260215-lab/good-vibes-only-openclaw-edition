/**
 * BAP-578 Contract Configuration
 * Deployed on BSC Mainnet
 */

export const BAP578_CONFIG = {
  // Contract Addresses
  REGISTRY_ADDRESS: '0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0',
  BAP578_ADDRESS: '0x02aDF991D570512A812D109674Ba6A9B89e815b0',
  
  // System Addresses
  TOKEN_RECEIVER: '0x69AC9374b9B61561a5467be07d2382EDD9cfe250',
  DIVIDEND_POOL: '0x7EfF6A14354445A83E75d4288e608198b9f9878e',
  
  // Network Configuration
  CHAIN_ID: 56, // BSC Mainnet
  CHAIN_NAME: 'BSC Mainnet',
  RPC_URL: 'https://bsc-dataseed.binance.org/',
  BLOCK_EXPLORER: 'https://bscscan.com',
  
  // Contract Parameters
  DIVIDEND_PERCENTAGE: 20, // 20% auto dividend
  
  // BSCScan Links
  REGISTRY_BSCSCAN: 'https://bscscan.com/address/0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0',
  BAP578_BSCSCAN: 'https://bscscan.com/address/0x02aDF991D570512A812D109674Ba6A9B89e815b0',
} as const;

export type BAP578Config = typeof BAP578_CONFIG;
