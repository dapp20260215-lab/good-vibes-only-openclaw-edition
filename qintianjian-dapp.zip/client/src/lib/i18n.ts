import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

// 中文翻译
const zh = {
  translation: {
    // 通用
    common: {
      connect_wallet: '连接钱包',
      disconnect: '断开连接',
      back_home: '返回首页',
      loading: '加载中...',
      confirm: '确认',
      cancel: '取消',
      submit: '提交',
      reset: '重置',
    },
    // 导航
    nav: {
      divination: '起卦',
      market: '预测市场',
      ai_divination: 'AI问卜',
      staking: '质押分红',
      transfer: '转账',
      my_nfts: '我的NFT',
    },
    // 首页
    home: {
      title: '钦天监',
      subtitle: '基于区块链的去中心化易经占卜预测平台',
      description: '结合千年易经智慧与现代AI技术，在BSC链上实现可验证的占卜预测与预测市场',
      divination_card: {
        title: '铜钱起卦',
        description: '消耗1000 QTJ代币，生成传统易经卦象',
        button: '开始起卦',
      },
      market_card: {
        title: '预测市场',
        description: '使用卦象NFT创建预测，下注0.01 BNB赢取奖池',
        button: '探索市场',
      },
      ai_card: {
        title: 'AI问卜',
        description: 'AI解读卦象，提供深度预测分析',
        button: 'AI问卜',
      },
      staking_card: {
        title: '质押分红',
        description: '质押QTJ代币，获得20%交易税分红',
        button: '开始质押',
      },
      nft_card: {
        title: '我的NFT',
        description: '查看、转账和赠送您的卦象NFT',
        button: '查看NFT',
      },
      transfer_card: {
        title: '代币转账',
        description: '转账QTJ代币或BNB，支持定向捐赠',
        button: '转账',
      },
      stats: {
        total_divinations: '累计起卦',
        active_predictions: '活跃预测',
        total_staked: '质押总量',
        total_burned: '累计接受',
      },
    },
    // 起卦页面
    divination: {
      title: '铜钱起卦',
      subtitle: '消耗1000 QTJ代币，生成传统易经卦象',
      throw_coins: '投掷铜钱',
      throwing: '投掷中...',
      start: '开始起卦',
      completed: '已完成',
      result: '卦象解读',
      waiting: '等待起卦',
      mint_nft: '铸造NFT',
      cost: '铸造NFT需要消耗',
    },
    // AI问卜
    ai_divination: {
      title: 'AI问卜',
      subtitle: '消耗2000 QTJ代币，AI为您解读卦象，提供深度预测分析',
      question_placeholder: '例如：我最近的事业运势如何？',
      ask: '开始问卜',
      result: 'AI解读',
      waiting: '输入问题后查看AI解读',
    },
    // 质押
    staking: {
      title: '质押分红',
      subtitle: '质押QTJ代币，获得20%交易税分红',
      stake: '质押QTJ',
      amount: '质押数量',
      available: '可用余额',
      lock_period: '锁定期',
      reward_rate: '分红比例',
      my_staking: '我的质押',
      staked_amount: '质押数量',
      days_staked: '已质押天数',
      total_rewards: '累计分红',
      remaining_lock: '剩余锁定',
      claim_rewards: '领取分红',
      unstake: '赎回质押',
      locked: '锁定中',
    },
    // 转账
    transfer: {
      title: '代币转账',
      subtitle: '转账QTJ代币或BNB到任意地址',
      token_type: '代币类型',
      recipient: '接收地址',
      amount: '转账数量',
      estimated_gas: '预估Gas费',
      send: '发送',
      donation: '定向捐赠',
      donation_desc: '向指定地址捐赠QTJ代币',
    },
  },
}

// 英文翻译
const en = {
  translation: {
    common: {
      connect_wallet: 'Connect Wallet',
      disconnect: 'Disconnect',
      back_home: 'Back to Home',
      loading: 'Loading...',
      confirm: 'Confirm',
      cancel: 'Cancel',
      submit: 'Submit',
      reset: 'Reset',
    },
    nav: {
      divination: 'Divination',
      market: 'Prediction Market',
      ai_divination: 'AI Divination',
      staking: 'Staking',
      transfer: 'Transfer',
      my_nfts: 'My NFTs',
    },
    home: {
      title: 'QinTianJian',
      subtitle: 'Decentralized I Ching Divination & Prediction Platform on Blockchain',
      description: 'Combining ancient I Ching wisdom with modern AI technology, enabling verifiable divination and prediction markets on BSC',
      divination_card: {
        title: 'Three Coins Divination',
        description: 'Burn 2000 QTJ tokens to generate unique hexagram NFT',
        button: 'Start Divination',
      },
      market_card: {
        title: 'Prediction Market',
        description: 'Create predictions with hexagram NFTs, stake 0.01 BNB to win pool',
        button: 'Explore Market',
      },
      ai_card: {
        title: 'AI Divination',
        description: 'AI interprets hexagrams and provides deep analysis',
        button: 'Ask AI',
      },
      staking_card: {
        title: 'Staking Rewards',
        description: 'Stake QTJ tokens to earn 20% trading tax rewards',
        button: 'Start Staking',
      },
      nft_card: {
        title: 'My NFTs',
        description: 'View, transfer and gift your hexagram NFTs',
        button: 'View NFTs',
      },
      transfer_card: {
        title: 'Token Transfer',
        description: 'Transfer QTJ tokens or BNB, support targeted donations',
        button: 'Transfer',
      },
      stats: {
        total_divinations: 'Total Divinations',
        active_predictions: 'Active Predictions',
        total_staked: 'Total Staked',
        total_burned: 'Total Received',
      },
    },
    divination: {
      title: 'Three Coins Divination',
      subtitle: 'Burn 2000 QTJ tokens to generate unique hexagram NFT',
      throw_coins: 'Throw Coins',
      throwing: 'Throwing...',
      start: 'Start Divination',
      completed: 'Completed',
      result: 'Hexagram Interpretation',
      waiting: 'Waiting for divination',
      mint_nft: 'Mint NFT',
      cost: 'Minting NFT costs',
    },
    ai_divination: {
      title: 'AI Divination',
      subtitle: 'Burn 2000 QTJ tokens, AI interprets hexagrams for you',
      question_placeholder: 'e.g.: How is my career fortune recently?',
      ask: 'Ask AI',
      result: 'AI Interpretation',
      waiting: 'Enter question to view AI interpretation',
    },
    staking: {
      title: 'Staking Rewards',
      subtitle: 'Stake QTJ tokens to earn 20% trading tax rewards',
      stake: 'Stake QTJ',
      amount: 'Stake Amount',
      available: 'Available Balance',
      lock_period: 'Lock Period',
      reward_rate: 'Reward Rate',
      my_staking: 'My Staking',
      staked_amount: 'Staked Amount',
      days_staked: 'Days Staked',
      total_rewards: 'Total Rewards',
      remaining_lock: 'Remaining Lock',
      claim_rewards: 'Claim Rewards',
      unstake: 'Unstake',
      locked: 'Locked',
    },
    transfer: {
      title: 'Token Transfer',
      subtitle: 'Transfer QTJ tokens or BNB to any address',
      token_type: 'Token Type',
      recipient: 'Recipient Address',
      amount: 'Transfer Amount',
      estimated_gas: 'Estimated Gas',
      send: 'Send',
      donation: 'Targeted Donation',
      donation_desc: 'Donate QTJ tokens to specified addresses',
    },
  },
}

i18n
  .use(initReactI18next)
  .init({
    resources: {
      zh,
      en,
    },
    lng: 'zh', // 默认语言
    fallbackLng: 'zh',
    interpolation: {
      escapeValue: false,
    },
  })

export default i18n
