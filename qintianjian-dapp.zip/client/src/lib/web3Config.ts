import { http, createConfig } from 'wagmi'
import { bsc, bscTestnet } from 'wagmi/chains'
import { injected } from 'wagmi/connectors'

// BSC链配置
export const chains = [bsc, bscTestnet] as const

export const config = createConfig({
  chains,
  connectors: [
    // MetaMask连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        // 只在检测到MetaMask且不是OKX时返回
        if (w.ethereum?.isMetaMask && !w.ethereum?.isOKExWallet && !w.okxwallet) {
          return {
            id: 'metaMask',
            name: 'MetaMask',
            provider: w.ethereum,
          }
        }
        return undefined
      },
    }),
    
    // TokenPocket连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        if (w.ethereum?.isTokenPocket) {
          return {
            id: 'tokenPocket',
            name: 'TokenPocket',
            provider: w.ethereum,
          }
        }
        return undefined
      },
    }),
    
    // OKX钱包连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        // 优先使用window.okxwallet
        if (w.okxwallet) {
          return {
            id: 'okx',
            name: 'OKX Wallet',
            provider: w.okxwallet,
          }
        }
        // 备选：使用window.ethereum（如果是OKX）
        if (w.ethereum?.isOKExWallet) {
          return {
            id: 'okx',
            name: 'OKX Wallet',
            provider: w.ethereum,
          }
        }
        return undefined
      },
    }),
    
    // Binance Web3钱包连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        if (w.BinanceChain) {
          return {
            id: 'binance',
            name: 'Binance Web3 Wallet',
            provider: w.BinanceChain,
          }
        }
        return undefined
      },
    }),
    
    // Trust Wallet连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        if (w.ethereum?.isTrust) {
          return {
            id: 'trust',
            name: 'Trust Wallet',
            provider: w.ethereum,
          }
        }
        return undefined
      },
    }),
    
    // ImToken连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        if (w.ethereum?.isImToken) {
          return {
            id: 'imToken',
            name: 'ImToken',
            provider: w.ethereum,
          }
        }
        return undefined
      },
    }),
    
    // 通用fallback连接器
    injected({
      shimDisconnect: true,
      target() {
        const w = window as any
        if (w.ethereum) {
          return {
            id: 'injected',
            name: 'Browser Wallet',
            provider: w.ethereum,
          }
        }
        return undefined
      },
    }),
  ],
  transports: {
    [bsc.id]: http(),
    [bscTestnet.id]: http(),
  },
})

// 合约地址配置
export const CONTRACTS = {
  // 钦天监代币合约地址
  QTJ_TOKEN: '0x97d48e4c13264560646159199db0da5c450f7777',
  
  // 钦天监主合约地址 (部署后填入)
  QINTIANJIAN: '0x0000000000000000000000000000000000000000',
  
  // 特殊地址
  BURN_ADDRESS: '0x69ac9374b9b61561a5467be07d2382edd9cfe250',
  TAX_WALLET: '0x69ac9374b9b61561a5467be07d2382edd9cfe250',
  DONATION_ADDRESS_1: '0x28816c4c4792467390c90e5b426f198570e29307',
  DONATION_ADDRESS_2: '0x01db37579e55ce13f4504019025e36047bdad845',
} as const

// 费用配置
export const FEES = {
  DIVINATION_COST: '1000000000000000000000', // 1000 钦天监 (18 decimals)
  AI_DIVINATION_COST: '2000000000000000000000', // 2000 钦天监
  PREDICTION_STAKE: '10000000000000000', // 0.01 BNB (18 decimals)
  STAKE_LOCK_PERIOD: 10 * 24 * 60 * 60, // 10天(秒)
  REWARD_RATE: 20, // 20%
} as const

// ERC20 ABI (标准代币接口)
export const ERC20_ABI = [
  {
    constant: true,
    inputs: [{ name: '_owner', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ name: 'balance', type: 'uint256' }],
    type: 'function',
  },
  {
    constant: false,
    inputs: [
      { name: '_to', type: 'address' },
      { name: '_value', type: 'uint256' },
    ],
    name: 'transfer',
    outputs: [{ name: '', type: 'bool' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [
      { name: '_owner', type: 'address' },
      { name: '_spender', type: 'address' },
    ],
    name: 'allowance',
    outputs: [{ name: '', type: 'uint256' }],
    type: 'function',
  },
  {
    constant: false,
    inputs: [
      { name: '_spender', type: 'address' },
      { name: '_value', type: 'uint256' },
    ],
    name: 'approve',
    outputs: [{ name: '', type: 'bool' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'decimals',
    outputs: [{ name: '', type: 'uint8' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'symbol',
    outputs: [{ name: '', type: 'string' }],
    type: 'function',
  },
] as const
