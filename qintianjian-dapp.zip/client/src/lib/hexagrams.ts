// 64卦数据
export const HEXAGRAMS = [
  { id: 1, name: '乾', symbol: '☰', binary: '111111', description: '乾为天，刚健中正' },
  { id: 2, name: '坤', symbol: '☷', binary: '000000', description: '坤为地，厚德载物' },
  { id: 3, name: '屯', symbol: '☵☳', binary: '010001', description: '水雷屯，万物始生' },
  { id: 4, name: '蒙', symbol: '☶☵', binary: '100010', description: '山水蒙，启蒙教育' },
  { id: 5, name: '需', symbol: '☵☰', binary: '010111', description: '水天需，等待时机' },
  { id: 6, name: '讼', symbol: '☰☵', binary: '111010', description: '天水讼，争讼之象' },
  { id: 7, name: '师', symbol: '☷☵', binary: '000010', description: '地水师，众人之师' },
  { id: 8, name: '比', symbol: '☵☷', binary: '010000', description: '水地比，亲比辅佐' },
  { id: 9, name: '小畜', symbol: '☴☰', binary: '110111', description: '风天小畜，小有积蓄' },
  { id: 10, name: '履', symbol: '☰☱', binary: '111011', description: '天泽履，履险如夷' },
  { id: 11, name: '泰', symbol: '☷☰', binary: '000111', description: '地天泰，天地交泰' },
  { id: 12, name: '否', symbol: '☰☷', binary: '111000', description: '天地否，闭塞不通' },
  { id: 13, name: '同人', symbol: '☰☲', binary: '111101', description: '天火同人，志同道合' },
  { id: 14, name: '大有', symbol: '☲☰', binary: '101111', description: '火天大有，大有收获' },
  { id: 15, name: '谦', symbol: '☷☶', binary: '000100', description: '地山谦，谦虚受益' },
  { id: 16, name: '豫', symbol: '☳☷', binary: '001000', description: '雷地豫，安乐和豫' },
  { id: 17, name: '随', symbol: '☱☳', binary: '011001', description: '泽雷随，随时而动' },
  { id: 18, name: '蛊', symbol: '☶☴', binary: '100110', description: '山风蛊，整治腐败' },
  { id: 19, name: '临', symbol: '☷☱', binary: '000011', description: '地泽临，君临天下' },
  { id: 20, name: '观', symbol: '☴☷', binary: '110000', description: '风地观，观察审视' },
  { id: 21, name: '噬嗑', symbol: '☲☳', binary: '101001', description: '火雷噬嗑，刑罚明断' },
  { id: 22, name: '贲', symbol: '☶☲', binary: '100101', description: '山火贲，文饰之美' },
  { id: 23, name: '剥', symbol: '☶☷', binary: '100000', description: '山地剥，剥落衰败' },
  { id: 24, name: '复', symbol: '☷☳', binary: '000001', description: '地雷复，复归正道' },
  { id: 25, name: '无妄', symbol: '☰☳', binary: '111001', description: '天雷无妄，无妄之灾' },
  { id: 26, name: '大畜', symbol: '☶☰', binary: '100111', description: '山天大畜，大有积蓄' },
  { id: 27, name: '颐', symbol: '☶☳', binary: '100001', description: '山雷颐，颐养之道' },
  { id: 28, name: '大过', symbol: '☱☴', binary: '011110', description: '泽风大过，大过之象' },
  { id: 29, name: '坎', symbol: '☵☵', binary: '010010', description: '坎为水，险陷之象' },
  { id: 30, name: '离', symbol: '☲☲', binary: '101101', description: '离为火，光明附丽' },
  { id: 31, name: '咸', symbol: '☱☶', binary: '011100', description: '泽山咸，感应交流' },
  { id: 32, name: '恒', symbol: '☳☴', binary: '001110', description: '雷风恒，恒久不变' },
  { id: 33, name: '遁', symbol: '☰☶', binary: '111100', description: '天山遁，隐退避世' },
  { id: 34, name: '大壮', symbol: '☳☰', binary: '001111', description: '雷天大壮，阳刚壮盛' },
  { id: 35, name: '晋', symbol: '☲☷', binary: '101000', description: '火地晋，晋升进取' },
  { id: 36, name: '明夷', symbol: '☷☲', binary: '000101', description: '地火明夷，光明受伤' },
  { id: 37, name: '家人', symbol: '☴☲', binary: '110101', description: '风火家人，家庭和睦' },
  { id: 38, name: '睽', symbol: '☲☱', binary: '101011', description: '火泽睽，背离乖违' },
  { id: 39, name: '蹇', symbol: '☵☶', binary: '010100', description: '水山蹇，艰难险阻' },
  { id: 40, name: '解', symbol: '☳☵', binary: '001010', description: '雷水解，解除困难' },
  { id: 41, name: '损', symbol: '☶☱', binary: '100011', description: '山泽损，损己益人' },
  { id: 42, name: '益', symbol: '☴☳', binary: '110001', description: '风雷益，增益助长' },
  { id: 43, name: '夬', symbol: '☱☰', binary: '011111', description: '泽天夬，决断果断' },
  { id: 44, name: '姤', symbol: '☰☴', binary: '111110', description: '天风姤，不期而遇' },
  { id: 45, name: '萃', symbol: '☱☷', binary: '011000', description: '泽地萃，聚集汇合' },
  { id: 46, name: '升', symbol: '☷☴', binary: '000110', description: '地风升，上升提升' },
  { id: 47, name: '困', symbol: '☱☵', binary: '011010', description: '泽水困，困顿穷迫' },
  { id: 48, name: '井', symbol: '☵☴', binary: '010110', description: '水风井，井养不穷' },
  { id: 49, name: '革', symbol: '☱☲', binary: '011101', description: '泽火革，变革改革' },
  { id: 50, name: '鼎', symbol: '☲☴', binary: '101110', description: '火风鼎，鼎新革故' },
  { id: 51, name: '震', symbol: '☳☳', binary: '001001', description: '震为雷，震动奋起' },
  { id: 52, name: '艮', symbol: '☶☶', binary: '100100', description: '艮为山，止静安定' },
  { id: 53, name: '渐', symbol: '☴☶', binary: '110100', description: '风山渐，循序渐进' },
  { id: 54, name: '归妹', symbol: '☳☱', binary: '001011', description: '雷泽归妹，少女出嫁' },
  { id: 55, name: '丰', symbol: '☳☲', binary: '001101', description: '雷火丰，丰盛繁荣' },
  { id: 56, name: '旅', symbol: '☲☶', binary: '101100', description: '火山旅，旅途行旅' },
  { id: 57, name: '巽', symbol: '☴☴', binary: '110110', description: '巽为风，柔顺谦逊' },
  { id: 58, name: '兑', symbol: '☱☱', binary: '011011', description: '兑为泽，喜悦欢乐' },
  { id: 59, name: '涣', symbol: '☴☵', binary: '110010', description: '风水涣，涣散离散' },
  { id: 60, name: '节', symbol: '☵☱', binary: '010011', description: '水泽节，节制有度' },
  { id: 61, name: '中孚', symbol: '☴☱', binary: '110011', description: '风泽中孚，诚信为本' },
  { id: 62, name: '小过', symbol: '☳☶', binary: '001100', description: '雷山小过，小有过越' },
  { id: 63, name: '既济', symbol: '☵☲', binary: '010101', description: '水火既济，功德圆满' },
  { id: 64, name: '未济', symbol: '☲☵', binary: '101010', description: '火水未济，事未完成' },
]

/**
 * 三铜钱起卦算法
 * 投掷6次，每次3个铜钱
 * 正面(阳)记3，反面(阴)记2
 * 6=老阴(变爻)，7=少阳，8=少阴，9=老阳(变爻)
 */
export function throwCoins(): number {
  // 模拟投掷3个铜钱
  let sum = 0
  for (let i = 0; i < 3; i++) {
    // 随机生成正面(3)或反面(2)
    sum += Math.random() > 0.5 ? 3 : 2
  }
  return sum
}

/**
 * 生成完整卦象
 * 从下往上投掷6次
 * @param providedLines 可选的爻数组，如果提供则使用该数组，否则自动投掷
 */
export function generateHexagram(providedLines?: number[]) {
  const lines: number[] = providedLines || []
  if (!providedLines) {
    for (let i = 0; i < 6; i++) {
      lines.push(throwCoins())
    }
  }
  
  // 转换为二进制表示 (7,9为阳爻1, 6,8为阴爻0)
  const binary = lines
    .map(n => (n === 7 || n === 9) ? '1' : '0')
    .join('')
  
  // 查找对应的卦象
  const hexagram = HEXAGRAMS.find(h => h.binary === binary) || HEXAGRAMS[0]
  
  // 检查是否有变爻
  const changingLines = lines.map((n, i) => (n === 6 || n === 9) ? i : -1).filter(i => i >= 0)
  
  return {
    hexagram,
    lines,
    changingLines,
    binary,
  }
}

/**
 * 获取卦象详细解释
 */
export function getHexagramInterpretation(hexagram: typeof HEXAGRAMS[0]) {
  const interpretations: Record<number, string> = {
    1: '乾卦象征天，具有刚健、积极、进取的特性。此卦大吉，预示着事业顺利，贵人相助。宜积极进取，把握机遇。',
    2: '坤卦象征地，具有柔顺、包容、承载的特性。此卦吉利，预示着顺应自然，厚德载物。宜以柔克刚，顺势而为。',
    3: '屯卦象征万物初生，困难重重但充满生机。此卦提示创业维艰，需要坚持不懈。宜稳扎稳打，不可急躁。',
    4: '蒙卦象征启蒙教育，处于蒙昧状态需要指导。此卦提示需要学习成长，虚心求教。宜保持谦逊，接受指导。',
    5: '需卦象征等待，时机未到需要耐心。此卦提示不可强求，应等待时机成熟。宜养精蓄锐，静待良机。',
    6: '讼卦象征争讼，存在矛盾和冲突。此卦提示应避免争执，寻求和解。宜退让三分，以和为贵。',
    7: '师卦象征军队，需要纪律和统帅。此卦提示需要组织和领导能力。宜严明纪律，统一行动。',
    8: '比卦象征亲近辅佐，团结合作。此卦吉利，预示着得到帮助和支持。宜团结协作，互相扶持。',
    // ... 可以继续添加其他卦象的解释
  }
  
  return interpretations[hexagram.id] || hexagram.description
}

/**
 * 生成卦象图像(SVG)
 */
export function generateHexagramSVG(binary: string): string {
  const lines = binary.split('').reverse() // 从下往上
  const lineHeight = 20
  const lineWidth = 100
  const gap = 10
  
  let svg = `<svg width="120" height="150" xmlns="http://www.w3.org/2000/svg">`
  
  lines.forEach((bit, index) => {
    const y = 130 - (index * (lineHeight + gap))
    if (bit === '1') {
      // 阳爻 (实线)
      svg += `<rect x="10" y="${y}" width="${lineWidth}" height="${lineHeight}" fill="currentColor" rx="2"/>`
    } else {
      // 阴爻 (断线)
      svg += `<rect x="10" y="${y}" width="${lineWidth / 2 - 5}" height="${lineHeight}" fill="currentColor" rx="2"/>`
      svg += `<rect x="${10 + lineWidth / 2 + 5}" y="${y}" width="${lineWidth / 2 - 5}" height="${lineHeight}" fill="currentColor" rx="2"/>`
    }
  })
  
  svg += `</svg>`
  return svg
}
