interface GoldenCoinProps {
  isFlipping?: boolean
  size?: 'sm' | 'md' | 'lg'
}

export function GoldenCoin({ isFlipping = false, size = 'md' }: GoldenCoinProps) {
  const sizeClasses = {
    sm: 'w-12 h-12 text-[6px]',
    md: 'w-16 h-16 text-[8px]',
    lg: 'w-20 h-20 text-[10px]'
  }

  return (
    <div 
      className={`${sizeClasses[size]} relative ${isFlipping ? 'animate-bounce' : ''}`}
      style={{
        perspective: '1000px'
      }}
    >
      {/* 铜钱主体 */}
      <div className="w-full h-full rounded-full bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 shadow-2xl shadow-yellow-500/50 flex items-center justify-center relative">
        {/* 外圈装饰 */}
        <div className="absolute inset-0 rounded-full border-4 border-yellow-300/30"></div>
        
        {/* 中间方孔 */}
        <div className="w-1/3 h-1/3 bg-black/80 rounded-sm flex items-center justify-center">
          {/* 方孔内阴影 */}
          <div className="w-full h-full bg-gradient-to-br from-black to-gray-900 rounded-sm"></div>
        </div>
        
        {/* 乾隆通宝文字 - 上 */}
        <div className="absolute top-[15%] left-1/2 -translate-x-1/2 font-bold text-yellow-900" style={{ fontFamily: "'Noto Sans SC', serif", writingMode: 'vertical-rl' }}>
          乾
        </div>
        
        {/* 乾隆通宝文字 - 下 */}
        <div className="absolute bottom-[15%] left-1/2 -translate-x-1/2 font-bold text-yellow-900" style={{ fontFamily: "'Noto Sans SC', serif", writingMode: 'vertical-rl' }}>
          隆
        </div>
        
        {/* 乾隆通宝文字 - 左 */}
        <div className="absolute left-[15%] top-1/2 -translate-y-1/2 font-bold text-yellow-900" style={{ fontFamily: "'Noto Sans SC', serif" }}>
          通
        </div>
        
        {/* 乾隆通宝文字 - 右 */}
        <div className="absolute right-[15%] top-1/2 -translate-y-1/2 font-bold text-yellow-900" style={{ fontFamily: "'Noto Sans SC', serif" }}>
          宝
        </div>
        
        {/* 金属光泽效果 */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-yellow-200/30 to-transparent"></div>
      </div>
    </div>
  )
}
