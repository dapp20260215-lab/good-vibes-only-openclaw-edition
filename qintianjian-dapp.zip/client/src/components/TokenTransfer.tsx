import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useTransferQTJ, useTransactionStatus, getBSCScanLink, useGasEstimate } from '@/hooks/useWeb3'
import { ExternalLink, Loader2, Send } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { isAddress, type Address } from 'viem'

export function TokenTransfer() {
  const [recipient, setRecipient] = useState('')
  const [amount, setAmount] = useState('')
  // 只支持钦天监代币
  
  const { transfer, hash, isPending, isError, error } = useTransferQTJ()
  const { isSuccess, isLoading } = useTransactionStatus(hash)
  const { estimateGas } = useGasEstimate()

  const handleTransfer = async () => {
    if (!recipient || !amount) {
      toast.error('请填写完整信息')
      return
    }

    if (!isAddress(recipient)) {
      toast.error('无效的钱包地址')
      return
    }

    try {
      await transfer(recipient as Address, amount)
      toast.success('交易已提交')
    } catch (err) {
      console.error(err)
      toast.error('交易失败')
    }
  }

  const estimatedGas = estimateGas()

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Send className="h-5 w-5" />
          代币转账
        </CardTitle>
        <CardDescription>
          向其他地址转账钦天监代币
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>接收地址</Label>
          <Input
            placeholder="0x..."
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label>转账数量</Label>
          <Input
            type="number"
            placeholder="0.0"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        <div className="bg-muted/50 p-3 rounded-lg space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">预估Gas费:</span>
            <span className="font-medium">{parseFloat(estimatedGas).toFixed(6)} BNB</span>
          </div>
        </div>

        <Button
          className="w-full"
          onClick={handleTransfer}
          disabled={isPending || isLoading || !recipient || !amount}
        >
          {(isPending || isLoading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isPending ? '确认交易...' : isLoading ? '处理中...' : '发送'}
        </Button>

        {hash && (
          <div className="bg-muted/50 p-3 rounded-lg space-y-2">
            <div className="text-sm font-medium">交易哈希:</div>
            <div className="flex items-center gap-2">
              <code className="text-xs bg-background px-2 py-1 rounded flex-1 overflow-hidden text-ellipsis">
                {hash}
              </code>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => window.open(getBSCScanLink(hash), '_blank')}
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
            {isSuccess && (
              <div className="text-sm text-green-600 dark:text-green-400">
                ✓ 交易成功
              </div>
            )}
            {isError && (
              <div className="text-sm text-destructive">
                ✗ 交易失败
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
