import { Home, Compass, Sparkles, Gamepad2, User } from 'lucide-react'
import { Link, useLocation } from 'wouter'
import { useState } from 'react'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'

export function MobileBottomNav() {
  const [location] = useLocation()
  const [playMenuOpen, setPlayMenuOpen] = useState(false)
  const [myMenuOpen, setMyMenuOpen] = useState(false)

  const navItems = [
    { icon: Home, label: '官网', href: 'https://qintianjian.fun/', external: true },
    { icon: Compass, label: '起卦', href: '/divination' },
    { icon: Sparkles, label: '问卜', href: '/ai-divination' },
    { icon: Gamepad2, label: '玩法', action: () => setPlayMenuOpen(true) },
    { icon: User, label: '我的', action: () => setMyMenuOpen(true) },
  ]

  return (
    <>
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-black border-t border-white/10 z-50">
        <div className="flex items-center justify-around py-2">
          {navItems.map((item, index) => {
            const Icon = item.icon
            const isActive = item.href && location === item.href
            
            if (item.external) {
              return (
                <a
                  key={index}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex flex-col items-center gap-1 px-3 py-2 transition-colors"
                >
                  <Icon className={`h-5 w-5 ${isActive ? 'text-yellow-400' : 'text-white/70'}`} />
                  <span className={`text-xs ${isActive ? 'text-yellow-400' : 'text-white/70'}`}>{item.label}</span>
                </a>
              )
            }
            
            if (item.action) {
              return (
                <button
                  key={index}
                  onClick={item.action}
                  className="flex flex-col items-center gap-1 px-3 py-2 transition-colors"
                >
                  <Icon className="h-5 w-5 text-white/70" />
                  <span className="text-xs text-white/70">{item.label}</span>
                </button>
              )
            }
            
            return (
              <Link key={index} href={item.href!}>
                <button className="flex flex-col items-center gap-1 px-3 py-2 transition-colors">
                  <Icon className={`h-5 w-5 ${isActive ? 'text-yellow-400' : 'text-white/70'}`} />
                  <span className={`text-xs ${isActive ? 'text-yellow-400' : 'text-white/70'}`}>{item.label}</span>
                </button>
              </Link>
            )
          })}
        </div>
      </nav>

      {/* 玩法菜单 */}
      <Sheet open={playMenuOpen} onOpenChange={setPlayMenuOpen}>
        <SheetContent side="bottom" className="bg-black border-white/10">
          <SheetHeader>
            <SheetTitle className="text-white">玩法</SheetTitle>
          </SheetHeader>
          <div className="mt-6 space-y-3">
            <Link href="/staking">
              <button
                onClick={() => setPlayMenuOpen(false)}
                className="w-full text-left px-4 py-3 bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition-colors"
              >
                <div className="text-white font-medium">质押分红</div>
                <div className="text-sm text-white/60 mt-1">质押钦天监代币，获得20%交易税分红</div>
              </button>
            </Link>
          </div>
        </SheetContent>
      </Sheet>

      {/* 我的菜单 */}
      <Sheet open={myMenuOpen} onOpenChange={setMyMenuOpen}>
        <SheetContent side="bottom" className="bg-black border-white/10">
          <SheetHeader>
            <SheetTitle className="text-white">我的</SheetTitle>
          </SheetHeader>
          <div className="mt-6 space-y-3">
            <Link href="/transfer">
              <button
                onClick={() => setMyMenuOpen(false)}
                className="w-full text-left px-4 py-3 bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition-colors"
              >
                <div className="text-white font-medium">代币转账</div>
                <div className="text-sm text-white/60 mt-1">转账钦天监代币给其他地址</div>
              </button>
            </Link>
            <Link href="/history">
              <button
                onClick={() => setMyMenuOpen(false)}
                className="w-full text-left px-4 py-3 bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition-colors"
              >
                <div className="text-white font-medium">交易历史</div>
                <div className="text-sm text-white/60 mt-1">查看所有交易记录和历史</div>
              </button>
            </Link>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
