export function CompassSVG({ className = "w-64 h-64" }: { className?: string }) {
  // 八卦符号（乾、坤、震、巽、坎、离、艮、兑）
  const bagua = [
    { name: '乾', lines: [1, 1, 1] }, // ☰
    { name: '兑', lines: [0, 1, 1] }, // ☱
    { name: '离', lines: [1, 0, 1] }, // ☲
    { name: '震', lines: [0, 0, 1] }, // ☳
    { name: '巽', lines: [1, 1, 0] }, // ☴
    { name: '坎', lines: [0, 1, 0] }, // ☵
    { name: '艮', lines: [1, 0, 0] }, // ☶
    { name: '坤', lines: [0, 0, 0] }, // ☷
  ]

  return (
    <svg
      className={className}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* 外圈 - 固定不动 */}
      <circle
        cx="100"
        cy="100"
        r="95"
        stroke="#ffffff"
        strokeWidth="2"
        fill="none"
      />
      <circle
        cx="100"
        cy="100"
        r="85"
        stroke="#888888"
        strokeWidth="1"
        fill="none"
        opacity="0.5"
      />

      {/* 八卦圈 - 逆时针旋转 */}
      <g id="bagua-ring">
        {/* 八卦符号圈 */}
        <circle
          cx="100"
          cy="100"
          r="75"
          stroke="#cccccc"
          strokeWidth="1.5"
          fill="none"
        />

        {/* 八卦符号 */}
        {bagua.map((gua, i) => {
          const angle = (i * 45 - 90) * (Math.PI / 180) // 从顶部开始
          const x = 100 + 75 * Math.cos(angle)
          const y = 100 + 75 * Math.sin(angle)
          
          return (
            <g key={i} transform={`translate(${x}, ${y})`}>
              {/* 三个爻 */}
              {gua.lines.map((line, j) => {
                const yOffset = (j - 1) * 3
                return line === 1 ? (
                  // 阳爻（实线）
                  <rect
                    key={j}
                    x="-6"
                    y={yOffset - 0.5}
                    width="12"
                    height="1"
                    fill="#ffffff"
                  />
                ) : (
                  // 阴爻（断线）
                  <g key={j}>
                    <rect
                      x="-6"
                      y={yOffset - 0.5}
                      width="5"
                      height="1"
                      fill="#ffffff"
                    />
                    <rect
                      x="1"
                      y={yOffset - 0.5}
                      width="5"
                      height="1"
                      fill="#ffffff"
                    />
                  </g>
                )
              })}
            </g>
          )
        })}

        {/* 八卦方位标记 */}
        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => {
          const rad = (angle * Math.PI) / 180
          const x1 = 100 + 60 * Math.cos(rad)
          const y1 = 100 + 60 * Math.sin(rad)
          const x2 = 100 + 70 * Math.cos(rad)
          const y2 = 100 + 70 * Math.sin(rad)
          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#ffffff"
              strokeWidth="1.5"
              opacity="0.6"
            />
          )
        })}

        {/* 八卦圈动画 - 逆时针旋转 */}
        <animateTransform
          attributeName="transform"
          attributeType="XML"
          type="rotate"
          from="0 100 100"
          to="-360 100 100"
          dur="120s"
          repeatCount="indefinite"
        />
      </g>

      {/* 中心圆背景 */}
      <circle
        cx="100"
        cy="100"
        r="55"
        fill="#000000"
        opacity="0.8"
      />
      <circle
        cx="100"
        cy="100"
        r="50"
        stroke="#ffffff"
        strokeWidth="2"
        fill="none"
      />

      {/* 太极图 - 顺时针旋转 */}
      <g id="taiji" transform="translate(100, 100)">
        {/* 阴阳鱼 */}
        <path
          d="M 0,-40 A 40,40 0 0,1 0,40 A 20,20 0 0,1 0,0 A 20,20 0 0,0 0,-40 Z"
          fill="#ffffff"
        />
        <path
          d="M 0,-40 A 40,40 0 0,0 0,40 A 20,20 0 0,0 0,0 A 20,20 0 0,1 0,-40 Z"
          fill="#000000"
        />
        {/* 鱼眼 */}
        <circle cx="0" cy="-20" r="5" fill="#000000" />
        <circle cx="0" cy="20" r="5" fill="#ffffff" />

        {/* 太极图动画 - 顺时针旋转 */}
        <animateTransform
          attributeName="transform"
          attributeType="XML"
          type="rotate"
          from="0 0 0"
          to="360 0 0"
          dur="60s"
          repeatCount="indefinite"
        />
      </g>

      {/* 刻度线 - 固定不动 */}
      {Array.from({ length: 24 }).map((_, i) => {
        const angle = (i * 15 * Math.PI) / 180
        const x1 = 100 + 85 * Math.cos(angle)
        const y1 = 100 + 85 * Math.sin(angle)
        const x2 = 100 + 90 * Math.cos(angle)
        const y2 = 100 + 90 * Math.sin(angle)
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="#666666"
            strokeWidth="1"
            opacity="0.5"
          />
        )
      })}
    </svg>
  )
}
