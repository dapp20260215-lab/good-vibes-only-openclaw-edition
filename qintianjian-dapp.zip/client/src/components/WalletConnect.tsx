import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { useWallet, useTokenBalance, formatAddress, getBSCScanLink } from '@/hooks/useWeb3'
import { Wallet, LogOut, ExternalLink, Copy } from 'lucide-react'
import { toast } from 'sonner'
import { useState, useEffect } from 'react'

export function WalletConnect() {
  const { address, isConnected, connect, disconnect, connectors, isPending, isBSC } = useWallet()
  const { bnbBalance, qtjBalance } = useTokenBalance(address)
  const [open, setOpen] = useState(false)
  const [walletCheckKey, setWalletCheckKey] = useState(0)
  
  // 当对话框打开时，延迟检测钱包以确保插件已注入
  useEffect(() => {
    if (open) {
      // 等待300ms让钱包插件完成注入（TP钱包需要更长时间）
      const timer = setTimeout(() => {
        setWalletCheckKey(prev => prev + 1) // 触发重新检测
      }, 300)
      return () => clearTimeout(timer)
    }
  }, [open])

  const handleConnect = (connectorId: string) => {
    const connector = connectors.find(c => c.id === connectorId)
    if (connector) {
      connect({ connector })
      setOpen(false)
    }
  }

  const handleCopyAddress = () => {
    if (address) {
      navigator.clipboard.writeText(address)
      toast.success('地址已复制到剪贴板')
    }
  }

  if (isConnected && address) {
    return (
      <div className="flex items-center gap-2">
        {/* 桌面版显示完整信息 */}
        <div className="hidden md:flex items-center gap-2">
          <div className="flex items-center gap-2 bg-black/50 border border-white/20 rounded-lg px-3 py-2">
            <Wallet className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-white">{formatAddress(address)}</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 bg-black/50 border border-white/20 hover:bg-white/10"
            onClick={handleCopyAddress}
          >
            <Copy className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 bg-black/50 border border-white/20 hover:bg-white/10"
            onClick={() => window.open(getBSCScanLink(address, 'address'), '_blank')}
          >
            <ExternalLink className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 bg-black/50 border border-white/20 hover:bg-white/10"
            onClick={() => disconnect()}
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
        {/* 手机版只显示截断的钱包地址 */}
        <div className="md:hidden flex items-center gap-2 bg-black/50 border border-white/20 rounded-lg px-3 py-2">
          <Wallet className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-white">{formatAddress(address)}</span>
        </div>
      </div>
    )
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-blue-600 hover:bg-blue-700 text-white" disabled={isPending}>
          <Wallet className="h-4 w-4" />
          {isPending ? '连接中...' : '连接钱包'}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>连接钱包</DialogTitle>
        <DialogDescription>
          选择一个钱包连接到钦天监平台，支持浏览器插件和移动端钱包
        </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3" key={walletCheckKey}>
          {(() => {
            // 检测当前浏览器中可用的钱包
            const w = window as any
            const availableWallets: Array<{id: string, name: string, icon: React.ReactNode, installed: boolean}> = []
            
            // 调试日志：输出window.ethereum对象信息
            console.log('[Wallet Detection] window.ethereum:', w.ethereum)
            console.log('[Wallet Detection] ethereum.isMetaMask:', w.ethereum?.isMetaMask)
            console.log('[Wallet Detection] ethereum.isTokenPocket:', w.ethereum?.isTokenPocket)
            console.log('[Wallet Detection] ethereum.isOKExWallet:', w.ethereum?.isOKExWallet)
            console.log('[Wallet Detection] window.okxwallet:', w.okxwallet)
            console.log('[Wallet Detection] window.BinanceChain:', w.BinanceChain)
            
            // 始终显示MetaMask和TokenPocket（主流钱包）
            // 注意：MetaMask不再排除OKX，因为用户可能同时安装两个钱包
            const hasMetaMask = w.ethereum?.isMetaMask === true
            const hasTokenPocket = w.ethereum?.isTokenPocket === true
            
            console.log('[Wallet Detection] hasMetaMask:', hasMetaMask)
            console.log('[Wallet Detection] hasTokenPocket:', hasTokenPocket)
            
            availableWallets.push({ 
              id: 'metaMask', 
              name: 'MetaMask', 
              icon: '🦊',
              installed: hasMetaMask
            })
            
            availableWallets.push({ 
              id: 'tokenPocket', 
              name: 'TokenPocket', 
              icon: '👛',
              installed: hasTokenPocket
            })
            
            // 按优先级检测其他钱包（只在安装时显示）
            if (w.BinanceChain) {
              availableWallets.push({ id: 'binance', name: 'Binance Web3 Wallet', icon: '🟡', installed: true })
            }
            if (w.ethereum?.isTrust) {
              availableWallets.push({ id: 'trust', name: 'Trust Wallet', icon: '🔵', installed: true })
            }
            if (w.ethereum?.isImToken) {
              availableWallets.push({ id: 'imToken', name: 'ImToken', icon: '💎', installed: true })
            }
            // OKX钱包：只检测一次
            if (w.okxwallet || w.ethereum?.isOKExWallet) {
              availableWallets.push({ 
                id: 'okx', 
                name: 'OKX Wallet', 
                icon: <img src="/okx-wallet.jpg" alt="OKX" className="w-8 h-8 rounded-full" />,
                installed: true
              })
            }
            
            return availableWallets.map((wallet) => {
              // 根据钱包ID查找对应的connector
              const connector = connectors.find(c => c.id === wallet.id) || connectors[0]
              
              const handleWalletClick = () => {
                if (!wallet.installed) {
                  // 未安装插件，提示用户
                  const downloadUrls: Record<string, string> = {
                    metaMask: 'https://metamask.io/download/',
                    tokenPocket: 'https://www.tokenpocket.pro/en/download/app',
                  }
                  const url = downloadUrls[wallet.id]
                  if (url) {
                    alert(`请先安装 ${wallet.name} 浏览器插件\n\n下载地址：${url}`)
                    window.open(url, '_blank')
                  }
                } else {
                  console.log(`[Wallet Connect] Connecting to ${wallet.name} using connector:`, connector.id)
                  handleConnect(connector.id)
                }
              }
              
              return (
                <Button
                  key={wallet.id}
                  variant="outline"
                  className="h-16 flex items-center justify-start gap-3 px-4 hover:bg-primary/10 hover:border-primary relative"
                  onClick={handleWalletClick}
                  disabled={isPending}
                >
                  <span className="text-2xl flex items-center justify-center">{wallet.icon}</span>
                  <span className="text-sm font-medium">{wallet.name}</span>
                  {!wallet.installed && (
                    <span className="ml-auto text-xs text-muted-foreground">未安装</span>
                  )}
                </Button>
              )
            })
          })()}
        </div>
        <div className="bg-muted/50 p-3 rounded-lg text-xs text-muted-foreground">
          <p className="font-medium mb-1">支持的钱包：</p>
          <ul className="list-disc list-inside space-y-0.5">
            <li>MetaMask - 浏览器插件钱包</li>
            <li>TokenPocket (TP) - 浏览器插件/移动端钱包</li>
            <li>OKX Wallet - 浏览器插件/移动端钱包</li>
            <li>Trust Wallet - 移动端钱包</li>
            <li>ImToken - 移动端钱包</li>
            <li>币安Web3钱包 - 无私钥钱包</li>
          </ul>
        </div>
        <div className="text-xs text-muted-foreground text-center">
          连接钱包即表示您同意我们的服务条款
        </div>
      </DialogContent>
    </Dialog>
  )
}
