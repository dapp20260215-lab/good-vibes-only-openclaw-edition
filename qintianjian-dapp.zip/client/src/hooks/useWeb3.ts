import { useAccount, useConnect, useDisconnect, useBalance, useWriteContract, useReadContract, useWaitForTransactionReceipt } from 'wagmi'
import { formatEther, parseEther, type Address } from 'viem'
import { CONTRACTS, FEES, ERC20_ABI } from '@/lib/web3Config'
import { bsc } from 'wagmi/chains'

/**
 * 钱包连接Hook
 */
export function useWallet() {
  const { address, isConnected, chain } = useAccount()
  const { connect, connectors, isPending } = useConnect()
  const { disconnect } = useDisconnect()

  return {
    address,
    isConnected,
    chain,
    connect,
    connectors,
    disconnect,
    isPending,
    isBSC: chain?.id === bsc.id,
  }
}

/**
 * 余额查询Hook
 */
export function useTokenBalance(address?: Address) {
  // BNB余额
  const { data: bnbBalance, refetch: refetchBNB } = useBalance({
    address,
  })

  // 钦天监代币余额
  const { data: qtjBalance, refetch: refetchQTJ } = useReadContract({
    address: CONTRACTS.QTJ_TOKEN as Address,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
  })

  return {
    bnbBalance: bnbBalance ? formatEther(bnbBalance.value) : '0',
    qtjBalance: qtjBalance ? formatEther(qtjBalance as bigint) : '0',
    refetchBNB,
    refetchQTJ,
  }
}

/**
 * 钦天监代币转账Hook
 */
export function useTransferQTJ() {
  const { writeContract, data: hash, isPending, isError, error } = useWriteContract()

  const transfer = async (to: Address, amount: string) => {
    return writeContract({
      address: CONTRACTS.QTJ_TOKEN as Address,
      abi: ERC20_ABI,
      functionName: 'transfer',
      args: [to, parseEther(amount)],
    })
  }

  return {
    transfer,
    hash,
    isPending,
    isError,
    error,
  }
}

/**
 * 钦天监代币授权Hook
 */
export function useApproveQTJ() {
  const { writeContract, data: hash, isPending } = useWriteContract()

  const approve = async (spender: Address, amount: string) => {
    return writeContract({
      address: CONTRACTS.QTJ_TOKEN as Address,
      abi: ERC20_ABI,
      functionName: 'approve',
      args: [spender, parseEther(amount)],
    })
  }

  return {
    approve,
    hash,
    isPending,
  }
}

/**
 * 检查钦天监代币授权额度
 */
export function useQTJAllowance(owner?: Address, spender?: Address) {
  const { data: allowance, refetch } = useReadContract({
    address: CONTRACTS.QTJ_TOKEN as Address,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: owner && spender ? [owner, spender] : undefined,
  })

  return {
    allowance: allowance ? formatEther(allowance as bigint) : '0',
    refetch,
  }
}

/**
 * 交易状态监听Hook
 */
export function useTransactionStatus(hash?: `0x${string}`) {
  const { data, isLoading, isSuccess, isError } = useWaitForTransactionReceipt({
    hash,
  })

  return {
    receipt: data,
    isLoading,
    isSuccess,
    isError,
  }
}

/**
 * Gas费估算Hook
 */
export function useGasEstimate() {
  // 简化的gas费估算，实际应该调用eth_estimateGas
  const estimateGas = (gasLimit: bigint = BigInt(21000)) => {
    // 假设gas price为5 gwei
    const gasPrice = BigInt(5000000000)
    const gasCost = gasLimit * gasPrice
    return formatEther(gasCost)
  }

  return {
    estimateGas,
  }
}

/**
 * 格式化地址显示
 */
export function formatAddress(address?: string) {
  if (!address) return ''
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

/**
 * 获取BSCScan链接
 */
export function getBSCScanLink(hash: string, type: 'tx' | 'address' = 'tx') {
  return `https://bscscan.com/${type}/${hash}`
}
