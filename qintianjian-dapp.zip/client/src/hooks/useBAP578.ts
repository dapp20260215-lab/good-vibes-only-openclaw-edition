import { useWriteContract, useReadContract, useWaitForTransactionReceipt } from 'wagmi';
import { type Address, parseEther, formatEther } from 'viem';
import { useWallet } from './useWeb3';
import { BAP578_CONFIG } from '../lib/bap578Config';
import BAP578ABI from '../contracts/BAP578.json';

export function useBAP578() {
  const { address } = useWallet();
  const { writeContract, data: hash, isPending, isError, error: writeError } = useWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  // Mint new Agent NFT
  const mintAgent = async (metadataURI: string) => {
    if (!address) throw new Error('Wallet not connected');
    
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'mint',
      args: [address, metadataURI],
    });
  };

  // Fund Agent (20% auto dividend)
  const fundAgent = async (tokenId: bigint, amount: string) => {
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'fundAgent',
      args: [tokenId],
      value: parseEther(amount),
    });
  };

  // Execute Agent action
  const executeAction = async (tokenId: bigint, actionData: `0x${string}`) => {
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'executeAction',
      args: [tokenId, actionData],
    });
  };

  // Update Agent metadata
  const updateAgentMetadata = async (
    tokenId: bigint,
    metadata: {
      persona: string;
      experience: string;
      voiceHash: string;
      animationURI: string;
      vaultURI: string;
      vaultHash: `0x${string}`;
    }
  ) => {
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'updateAgentMetadata',
      args: [tokenId, metadata],
    });
  };

  // Pause Agent
  const pauseAgent = async (tokenId: bigint) => {
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'pause',
      args: [tokenId],
    });
  };

  // Unpause Agent
  const unpauseAgent = async (tokenId: bigint) => {
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'unpause',
      args: [tokenId],
    });
  };

  // Terminate Agent
  const terminateAgent = async (tokenId: bigint) => {
    return writeContract({
      address: BAP578_CONFIG.BAP578_ADDRESS as Address,
      abi: BAP578ABI.abi,
      functionName: 'terminate',
      args: [tokenId],
    });
  };

  return {
    mintAgent,
    fundAgent,
    executeAction,
    updateAgentMetadata,
    pauseAgent,
    unpauseAgent,
    terminateAgent,
    hash,
    isPending,
    isConfirming,
    isSuccess,
    isError,
    error: writeError?.message || null,
  };
}

// Read-only hooks for querying Agent state
export function useAgentState(tokenId?: bigint) {
  const { data, refetch } = useReadContract({
    address: BAP578_CONFIG.BAP578_ADDRESS as Address,
    abi: BAP578ABI.abi,
    functionName: 'getState',
    args: tokenId !== undefined ? [tokenId] : undefined,
  });

  if (!data) return null;

  const state = data as any;
  return {
    logicAddress: state.logicAddress as Address,
    balance: formatEther(state.balance),
    status: Number(state.status), // 0: Active, 1: Paused, 2: Terminated
    refetch,
  };
}

export function useAgentMetadata(tokenId?: bigint) {
  const { data, refetch } = useReadContract({
    address: BAP578_CONFIG.BAP578_ADDRESS as Address,
    abi: BAP578ABI.abi,
    functionName: 'getAgentMetadata',
    args: tokenId !== undefined ? [tokenId] : undefined,
  });

  if (!data) return null;

  const metadata = data as any;
  return {
    persona: metadata.persona as string,
    experience: metadata.experience as string,
    voiceHash: metadata.voiceHash as string,
    animationURI: metadata.animationURI as string,
    vaultURI: metadata.vaultURI as string,
    vaultHash: metadata.vaultHash as `0x${string}`,
    refetch,
  };
}
