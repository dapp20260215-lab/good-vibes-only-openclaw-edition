import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Transfer from "@/pages/Transfer";
import Divination from "@/pages/Divination";
import AIDivination from "@/pages/AIDivination";
import Staking from "@/pages/Staking";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { Web3Provider } from "./contexts/Web3Context";
import Home from "./pages/Home";
import Market from "./pages/Market";
import MyNFTs from "./pages/MyNFTs";
import History from "./pages/History";
import Profile from "./pages/Profile";
import CreateAgent from "./pages/CreateAgent";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/market"} component={Market} />
      <Route path={"/my-nfts"} component={MyNFTs} />
      <Route path="/history" component={History} />
      <Route path="/profile" component={Profile} />
      <Route path={"/transfer"} component={Transfer} />
      <Route path={"/divination"} component={Divination} />
      <Route path={"/ai-divination"} component={AIDivination} />
      <Route path={"/staking"} component={Staking} />
      <Route path={"/create-agent"} component={CreateAgent} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <Web3Provider>
        <ThemeProvider
          defaultTheme="dark"
          // switchable
        >
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </Web3Provider>
    </ErrorBoundary>
  );
}

export default App;
