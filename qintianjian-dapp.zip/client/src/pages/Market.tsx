import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useWallet } from '@/hooks/useWeb3'
import { ArrowLeft, TrendingUp, Loader2, Plus, Clock, Users } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'
import { formatEther, parseEther } from 'viem'

export default function Market() {
  const { address, isConnected } = useWallet()
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedPrediction, setSelectedPrediction] = useState<number | null>(null)
  const [betOption, setBetOption] = useState<number>(1)

  // 查询预测列表
  const { data: predictions = [], refetch } = trpc.market.list.useQuery({ resolved: 0 })

  // 创建预测
  const [createForm, setCreateForm] = useState({
    divinationId: '',
    question: '',
    deadline: '',
  })

  const createMutation = trpc.market.create.useMutation({
    onSuccess: () => {
      toast.success('预测创建成功')
      setIsCreateDialogOpen(false)
      setCreateForm({ divinationId: '', question: '', deadline: '' })
      refetch()
    },
    onError: (error) => {
      toast.error(error.message)
    },
  })

  const handleCreatePrediction = () => {
    if (!address) {
      toast.error('请先连接钱包')
      return
    }

    if (!createForm.divinationId || !createForm.question || !createForm.deadline) {
      toast.error('请填写完整信息')
      return
    }

    createMutation.mutate({
      divinationId: parseInt(createForm.divinationId),
      question: createForm.question,
      deadline: new Date(createForm.deadline),
      creatorAddress: address,
    })
  }

  // 下注
  const placeBetMutation = trpc.market.placeBet.useMutation({
    onSuccess: () => {
      toast.success('下注成功')
      setSelectedPrediction(null)
      refetch()
    },
    onError: (error) => {
      toast.error(error.message)
    },
  })

  const handlePlaceBet = async (predictionId: number, isYes: number) => {
    if (!address) {
      toast.error('请先连接钱包')
      return
    }

    // 这里应该调用Web3发送BNB，获取交易哈希
    // 简化处理：假设交易成功
    const txHash = '0x' + Math.random().toString(16).slice(2)
    const amount = parseEther('0.01').toString()

    placeBetMutation.mutate({
      predictionId,
      isYes,
      amount,
      stakerAddress: address,
      txHash,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="text-center space-y-2">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
                预测市场
              </h1>
              <p className="text-muted-foreground">使用卦象NFT创建预测，下注0.01 BNB赢取奖池</p>
            </div>

            {isConnected && (
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    创建预测
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>创建预测</DialogTitle>
                    <DialogDescription>使用您的卦象NFT创建一个新的预测市场</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>卦象NFT ID</Label>
                      <Input
                        type="number"
                        placeholder="输入您拥有的卦象NFT ID"
                        value={createForm.divinationId}
                        onChange={(e) =>
                          setCreateForm({ ...createForm, divinationId: e.target.value })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>预测问题</Label>
                      <Textarea
                        placeholder="例如：比特币价格会在2026年3月突破10万美元吗？"
                        value={createForm.question}
                        onChange={(e) => setCreateForm({ ...createForm, question: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>截止时间</Label>
                      <Input
                        type="datetime-local"
                        value={createForm.deadline}
                        onChange={(e) => setCreateForm({ ...createForm, deadline: e.target.value })}
                      />
                    </div>

                    <Button
                      className="w-full"
                      onClick={handleCreatePrediction}
                      disabled={createMutation.isPending}
                    >
                      {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      创建预测
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>

          {!isConnected ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">请先连接钱包</p>
                <WalletConnect />
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {predictions.length === 0 ? (
                <Card className="col-span-full">
                  <CardContent className="pt-6 text-center">
                    <TrendingUp className="h-12 w-12 mx-auto mb-4 opacity-50 text-muted-foreground" />
                    <p className="text-muted-foreground">暂无活跃的预测市场</p>
                  </CardContent>
                </Card>
              ) : (
                predictions.map((prediction) => {
                  const totalPool =
                    BigInt(prediction.totalStakeYes) + BigInt(prediction.totalStakeNo)
                  const yesPercentage =
                    totalPool > BigInt(0)
                      ? Number((BigInt(prediction.totalStakeYes) * BigInt(100)) / totalPool)
                      : 50
                  const noPercentage = 100 - yesPercentage

                  return (
                    <Card
                      key={prediction.id}
                      className="bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all"
                    >
                      <CardHeader>
                        <CardTitle className="text-lg line-clamp-2">{prediction.question}</CardTitle>
                        <CardDescription className="flex items-center gap-4 text-xs">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {new Date(prediction.deadline).toLocaleDateString('zh-CN')}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            奖池: {formatEther(totalPool)} BNB
                          </span>
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-green-500">看涨 {yesPercentage}%</span>
                            <span className="text-red-500">看跌 {noPercentage}%</span>
                          </div>
                          <div className="h-2 bg-muted rounded-full overflow-hidden flex">
                            <div
                              className="bg-green-500"
                              style={{ width: `${yesPercentage}%` }}
                            />
                            <div className="bg-red-500" style={{ width: `${noPercentage}%` }} />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <Button
                            variant="outline"
                            className="border-green-500/50 hover:bg-green-500/10"
                            onClick={() => handlePlaceBet(prediction.id, 1)}
                            disabled={placeBetMutation.isPending}
                          >
                            看涨
                          </Button>
                          <Button
                            variant="outline"
                            className="border-red-500/50 hover:bg-red-500/10"
                            onClick={() => handlePlaceBet(prediction.id, 0)}
                            disabled={placeBetMutation.isPending}
                          >
                            看跌
                          </Button>
                        </div>

                        <div className="text-xs text-muted-foreground text-center">
                          下注金额: 0.01 BNB
                        </div>
                      </CardContent>
                    </Card>
                  )
                })
              )}
            </div>
          )}

          {/* 说明 */}
          <Card className="bg-card/30 backdrop-blur-sm border-border/30">
            <CardHeader>
              <CardTitle className="text-lg">预测市场说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>1. 使用您的卦象NFT创建预测问题，设置截止时间</p>
              <p>2. 其他用户可以选择"看涨"或"看跌"进行下注，每次固定0.01 BNB</p>
              <p>3. 所有下注的BNB进入奖池，由创建者在截止时间后公布结果</p>
              <p>4. 预测正确的一方按下注比例分配奖池中的所有BNB</p>
              <p>5. 每个用户在同一个预测中只能下注一次</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
