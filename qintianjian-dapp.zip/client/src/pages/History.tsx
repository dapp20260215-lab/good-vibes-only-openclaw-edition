import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useWallet } from '@/hooks/useWeb3'
import { ArrowLeft, ExternalLink, Loader2, History as HistoryIcon } from 'lucide-react'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'

const BSC_EXPLORER = 'https://bscscan.com/tx/'

const getActivityIcon = (type: string) => {
  switch (type) {
    case 'divination':
      return '🪙'
    case 'ai_divination':
      return '🤖'
    case 'staking':
      return '💎'
    case 'betting':
      return '🎯'
    case 'transfer':
      return '💸'
    default:
      return '📝'
  }
}

const getStatusBadge = (status: string) => {
  switch (status) {
    case 'completed':
    case 'confirmed':
      return <Badge variant="default" className="bg-green-500/20 text-green-400 border-green-500/50">已完成</Badge>
    case 'pending':
      return <Badge variant="default" className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50">进行中</Badge>
    case 'failed':
      return <Badge variant="default" className="bg-red-500/20 text-red-400 border-red-500/50">失败</Badge>
    case 'active':
      return <Badge variant="default" className="bg-blue-500/20 text-blue-400 border-blue-500/50">活跃</Badge>
    case 'unstaked':
      return <Badge variant="default" className="bg-gray-500/20 text-gray-400 border-gray-500/50">已赎回</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export default function History() {
  const { address, isConnected } = useWallet()

  // 查询活动历史
  const { data: activities = [], isLoading } = trpc.history.getActivityHistory.useQuery(
    { walletAddress: address || '' },
    { enabled: !!address }
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
              交易历史
            </h1>
            <p className="text-muted-foreground">查看您的所有链上操作记录</p>
          </div>

          {!isConnected ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">请先连接钱包</p>
                <WalletConnect />
              </CardContent>
            </Card>
          ) : isLoading ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <Loader2 className="h-8 w-8 mx-auto mb-4 animate-spin text-primary" />
                <p className="text-muted-foreground">加载中...</p>
              </CardContent>
            </Card>
          ) : activities.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <HistoryIcon className="h-12 w-12 mx-auto mb-4 opacity-50 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">暂无交易记录</p>
                <Link href="/">
                  <Button>开始使用</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {activities.map((activity, index) => (
                <Card
                  key={`${activity.type}-${activity.id}-${index}`}
                  className="bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="text-3xl">{getActivityIcon(activity.type)}</div>
                        <div>
                          <CardTitle className="text-lg">{activity.title}</CardTitle>
                          <CardDescription className="text-sm mt-1">
                            {activity.description}
                          </CardDescription>
                        </div>
                      </div>
                      {getStatusBadge(activity.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      {activity.amount && (
                        <div>
                          <div className="text-muted-foreground mb-1">金额</div>
                          <div className="font-medium">{activity.amount}</div>
                        </div>
                      )}
                      <div>
                        <div className="text-muted-foreground mb-1">时间</div>
                        <div className="font-medium">
                          {new Date(activity.createdAt).toLocaleString('zh-CN')}
                        </div>
                      </div>
                      {activity.txHash && (
                        <div>
                          <div className="text-muted-foreground mb-1">交易哈希</div>
                          <a
                            href={`${BSC_EXPLORER}${activity.txHash}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-primary hover:underline font-mono text-xs"
                          >
                            {activity.txHash.substring(0, 10)}...{activity.txHash.substring(58)}
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* 说明 */}
          <Card className="bg-card/30 backdrop-blur-sm border-border/30">
            <CardHeader>
              <CardTitle className="text-lg">交易记录说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>1. 所有交易记录都会永久保存在区块链上</p>
              <p>2. 点击交易哈希可以在BSCScan浏览器上查看详细信息</p>
              <p>3. 交易状态包括：已完成、进行中、失败、活跃、已赎回</p>
              <p>4. 历史记录包括起卦、AI问卜、质押、预测下注、转账等所有操作</p>
              <p>5. 记录按时间倒序排列，最新的交易显示在最上方</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
