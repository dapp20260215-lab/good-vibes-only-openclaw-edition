import { WalletConnect } from '@/components/WalletConnect'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useWallet, useTokenBalance } from '@/hooks/useWeb3'
import { Coins, Sparkles, Wallet, Zap, Copy } from 'lucide-react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { useTranslation } from 'react-i18next'
import { StarryBackground } from '@/components/StarryBackground'
import { MobileBottomNav } from '@/components/MobileBottomNav'

export default function Home() {
  const { address, isConnected } = useWallet()
  const { bnbBalance, qtjBalance } = useTokenBalance(address)
  const { t } = useTranslation()

  return (
    <div className="bg-black relative pb-20 md:pb-0" style={{ minHeight: '100vh' }}>
      <StarryBackground />
      {/* 导航栏 */}
      <nav className="border-b border-white/10 bg-black sticky top-0 z-50">
        <div className={`container mx-auto px-6 transition-all ${isConnected ? 'py-3' : 'py-4'}`}>
          <div className="flex items-center justify-between">
            <Link href="/" className="hover:opacity-80 transition-all duration-300 ml-4">
              <img 
                src="/logo-text.jpg" 
                alt="钦天监" 
                className="h-12 md:h-14 w-auto object-contain"
              />
            </Link>

            <div className="hidden md:flex items-center gap-6">
              <a href="https://qintianjian.fun/" target="_blank" rel="noopener noreferrer" className="text-base font-medium text-white/80 hover:text-white hover:scale-105 transition-all duration-200">
                官网
              </a>
              <Link href="/divination" className="text-base font-medium text-white/80 hover:text-white hover:scale-105 transition-all duration-200">
                铜钱起卦
              </Link>
              <Link href="/ai-divination" className="text-base font-medium text-white/80 hover:text-white hover:scale-105 transition-all duration-200">
                AI问卜
              </Link>
              <Link href="/staking" className="text-base font-medium text-white/80 hover:text-white hover:scale-105 transition-all duration-200">
                质押分红
              </Link>
              <Link href="/transfer" className="text-base font-medium text-white/80 hover:text-white hover:scale-105 transition-all duration-200">
                代币转账
              </Link>
              <Link href="/history" className="text-base font-medium text-white/80 hover:text-white hover:scale-105 transition-all duration-200">
                交易历史
              </Link>
              <Link href="/create-agent" className="text-base font-medium text-yellow-400/90 hover:text-yellow-300 hover:scale-105 transition-all duration-200">
                创建Agent
              </Link>
            </div>

            <div className="flex items-center gap-2">
              <div className="hidden md:flex items-center gap-2">
                <LanguageSwitcher />
                <WalletConnect />
              </div>

              {/* 手机版连接钱包按钮 */}
              <div className="md:hidden">
                <WalletConnect />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-6 relative z-10">
        {/* Hero Section */}
        <div className="text-center space-y-3 mb-0">
          {/* 星盘图片 */}
          <div className="flex justify-center">
            <div className="relative">
              <img 
                src="/dizhi.jpg" 
                alt="钦天监星盘" 
                className="w-64 h-64 md:w-80 md:h-80 lg:w-96 lg:h-96 rounded-full shadow-2xl shadow-purple-500/50"
              />
            </div>
          </div>

          {/* 余额显示 - 仅在连接钱包后显示 */}
          {isConnected && (
            <div className="flex justify-center px-4">
              <div className="grid grid-cols-2 gap-4 max-w-md w-full">
                <div className="bg-gradient-to-br from-blue-900/30 to-cyan-900/30 rounded-lg border border-white/20 p-4 backdrop-blur-sm">
                  <div className="text-white/60 text-xs mb-1">BNB余额</div>
                  <div className="text-white font-semibold text-lg">{parseFloat(bnbBalance).toFixed(4)}</div>
                </div>
                <div className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 rounded-lg border border-white/20 p-4 backdrop-blur-sm">
                  <div className="text-white/60 text-xs mb-1">钦天监余额</div>
                  <div className="text-white font-semibold text-lg">{parseFloat(qtjBalance).toFixed(2)}</div>
                </div>
              </div>
            </div>
          )}

          {/* 合约地址 */}
          <div className="flex justify-center px-4">
            <div className="inline-flex items-center gap-2 px-4 md:px-6 py-3 bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 rounded-full border-2 border-yellow-500/60 hover:border-yellow-400 transition-all max-w-full overflow-hidden backdrop-blur-sm">
              <span className="text-xs md:text-sm font-mono text-yellow-300 whitespace-nowrap overflow-hidden text-ellipsis font-semibold">CA: 0x97d48e4c13264560646159199db0da5c450f7777</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 hover:bg-yellow-500/20 rounded-full"
                onClick={() => {
                  navigator.clipboard.writeText('0x97d48e4c13264560646159199db0da5c450f7777')
                  toast.success('合约地址已复制')
                }}
              >
                <Copy className="h-4 w-4 text-yellow-300" />
              </Button>
            </div>
          </div>

          {/* 最近起卦记录 - 紧靠CA地址下方 */}
          <div id="divination-records" className="mt-3 px-4">
            <div className="flex justify-center">
              <div className="relative w-full max-w-md px-2 h-[180px] overflow-hidden">
                <div className="animate-scroll-up space-y-2">
                  {/* 原始列表 */}
                  {[
                    { address: '0x1234...5678', name: '乾为天' },
                    { address: '0xabcd...ef01', name: '坤为地' },
                    { address: '0x9876...5432', name: '坎为水' },
                    { address: '0xfedc...ba98', name: '离为火' },
                    { address: '0x2468...1357', name: '震为雷' },
                  ].map((record, index) => (
                    <div key={`original-${index}`} className="flex items-center justify-between px-5 py-3 bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-full border border-white/30 hover:border-white/50 transition-all backdrop-blur-sm">
                      <span className="text-sm text-white/90 font-mono">{record.address}</span>
                      <span className="text-sm text-yellow-300 font-semibold">{record.name}</span>
                    </div>
                  ))}
                  {/* 复制一份用于无缝循环 */}
                  {[
                    { address: '0x1234...5678', name: '乾为天' },
                    { address: '0xabcd...ef01', name: '坤为地' },
                    { address: '0x9876...5432', name: '坎为水' },
                    { address: '0xfedc...ba98', name: '离为火' },
                    { address: '0x2468...1357', name: '震为雷' },
                  ].map((record, index) => (
                    <div key={`duplicate-${index}`} className="flex items-center justify-between px-5 py-3 bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-full border border-white/30 hover:border-white/50 transition-all backdrop-blur-sm">
                      <span className="text-sm text-white/90 font-mono">{record.address}</span>
                      <span className="text-sm text-yellow-300 font-semibold">{record.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 周期信息展示 */}
          <div id="cycles" className="mt-3 px-4 mb-0">
            <div className="grid grid-cols-2 gap-3 max-w-2xl mx-auto">
              {[
                { name: '三元九运', period: '180年' },
                { name: '康波周期', period: '50-60年' },
                { name: '木星周期', period: '12年' },
                { name: '美林时钟', period: '3-5年' },
              ].map((cycle, index) => (
                <div 
                  key={index} 
                  className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 rounded-lg border border-white/20 p-4 backdrop-blur-sm hover:border-white/40 transition-all"
                >
                  <h4 className="text-white font-semibold text-sm mb-1">{cycle.name}</h4>
                  <p className="text-white/60 text-xs">周期：{cycle.period}</p>
                </div>
              ))}
            </div>
          </div>

          {/* 功能卡片 */}
          <div id="features" className="grid md:grid-cols-2 gap-3 mt-2 px-4 mb-0">
          <Card className="bg-black/50 border-white/20 hover:border-white/40 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Coins className="h-5 w-5 text-purple-500" />
                铜钱起卦
              </CardTitle>
              <CardDescription>
                消耗1000代币，生成传统易经卦象并保存记录
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/divination">
                <Button className="w-full" variant="outline">
                  开始起卦
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-black/50 border-white/20 hover:border-white/40 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-pink-500" />
                AI问卜
              </CardTitle>
              <CardDescription>
                AI解读卦象，提供深度预测分析
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/ai-divination">
                <Button className="w-full" variant="outline">
                  AI问卜
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-black/50 border-white/20 hover:border-white/40 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-500" />
                质押分红
              </CardTitle>
              <CardDescription>
                质押钦天监代币，获得20%交易税分红
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/staking">
                <Button className="w-full" variant="outline">
                  开始质押
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-black/50 border-white/20 hover:border-white/40 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Coins className="h-5 w-5 text-orange-500" />
                代币转账
              </CardTitle>
              <CardDescription>
                转账钦天监代币，支持定向捐赠
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/transfer">
                <Button className="w-full" variant="outline">
                  转账
                </Button>
              </Link>
            </CardContent>
          </Card>
          </div>
        </div>
      </main>

      {/* 手机版底部导航栏 */}
      <MobileBottomNav />

      {/* 页脚 */}
      <footer className="hidden md:block border-t border-border/40 bg-background/30 backdrop-blur-xl mt-8">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2026 钦天监 QinTianJian. 基于BSC链 | BAP-578标准</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
