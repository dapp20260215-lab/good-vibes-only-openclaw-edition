import { TokenTransfer } from '@/components/TokenTransfer'
import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useWallet } from '@/hooks/useWeb3'
import { CONTRACTS } from '@/lib/web3Config'
import { ArrowLeft, Heart } from 'lucide-react'
import { Link } from 'wouter'

export default function Transfer() {
  const { isConnected } = useWallet()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
              代币转账
            </h1>
            <p className="text-muted-foreground">
              转账钦天监代币到任意地址
            </p>
          </div>

          {!isConnected ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">请先连接钱包</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              <TokenTransfer />

              <div className="space-y-6">
                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="h-5 w-5 text-red-500" />
                      定向捐赠
                    </CardTitle>
                    <CardDescription>
                      向指定地址捐赠钦天监代币
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="bg-muted/50 p-3 rounded-lg">
                      <div className="text-xs text-muted-foreground mb-1">捐赠地址 1：CZ</div>
                      <code className="text-xs break-all">{CONTRACTS.DONATION_ADDRESS_1}</code>
                    </div>
                    <div className="bg-muted/50 p-3 rounded-lg">
                      <div className="text-xs text-muted-foreground mb-1">捐赠地址 2：Flap创始人</div>
                      <code className="text-xs break-all">{CONTRACTS.DONATION_ADDRESS_2}</code>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      您可以在上方转账组件中输入这些地址进行捐赠
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardHeader>
                    <CardTitle>合约地址</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <div className="text-sm font-medium mb-1">钦天监代币合约</div>
                      <code className="text-xs bg-muted px-2 py-1 rounded block break-all">
                        {CONTRACTS.QTJ_TOKEN}
                      </code>
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">接受地址</div>
                      <code className="text-xs bg-muted px-2 py-1 rounded block break-all">
                        {CONTRACTS.BURN_ADDRESS}
                      </code>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
