import { useState } from "react";
import { useBAP578 } from "../hooks/useBAP578";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Card } from "../components/ui/card";
import { toast } from "sonner";
import { Loader2, CheckCircle2, Sparkles } from "lucide-react";

export default function CreateAgent() {
  const { mintAgent, hash, isPending, isConfirming, isSuccess, isError, error } = useBAP578();
  const isLoading = isPending || isConfirming;
  const [logicAddress, setLogicAddress] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [mintedAgentId, setMintedAgentId] = useState<string | null>(null);
  const [txHash, setTxHash] = useState<string | null>(null);

  const handleMint = async () => {
    if (!logicAddress || !name) {
      toast.error("请填写Logic合约地址和Agent名称");
      return;
    }

    // 验证地址格式
    if (!/^0x[a-fA-F0-9]{40}$/.test(logicAddress)) {
      toast.error("Logic合约地址格式不正确");
      return;
    }

    try {
      const metadataURI = JSON.stringify({
        name,
        description,
        logicAddress,
        createdAt: new Date().toISOString(),
      });

      await mintAgent(metadataURI);
      toast.success("交易已提交，等待确认...");
    } catch (err: any) {
      console.error("Mint error:", err);
      toast.error(err?.message || "铸造失败，请重试");
    }
  };

  // 监听铸造成功
  if (isSuccess && hash && !mintedAgentId) {
    // 这里简化处理，实际应该从事件日志中获取tokenId
    setMintedAgentId("待确认");
    setTxHash(hash);
    toast.success("铸造成功！");
    
    // 清空表单
    setLogicAddress("");
    setName("");
    setDescription("");
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-purple-900 to-gray-900 text-white">
      {/* 导航栏占位 */}
      <div className="h-20"></div>

      <div className="container max-w-4xl mx-auto px-4 py-12">
        {/* 页面标题 */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-10 h-10 text-yellow-400" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-yellow-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              创建AI Agent
            </h1>
          </div>
          <p className="text-gray-300 text-lg">
            铸造您的专属AI Agent NFT，开启智能预测之旅
          </p>
        </div>

        {/* 铸造表单 */}
        <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
          <div className="space-y-6">
            {/* Logic合约地址 */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Logic合约地址 <span className="text-red-400">*</span>
              </label>
              <Input
                type="text"
                placeholder="0x..."
                value={logicAddress}
                onChange={(e) => setLogicAddress(e.target.value)}
                className="bg-gray-900/50 border-gray-700 text-white placeholder:text-gray-500"
                disabled={isLoading}
              />
              <p className="text-xs text-gray-400 mt-1">
                AI Agent的逻辑合约地址，负责处理预测和决策
              </p>
            </div>

            {/* Agent名称 */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Agent名称 <span className="text-red-400">*</span>
              </label>
              <Input
                type="text"
                placeholder="我的易经AI"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-gray-900/50 border-gray-700 text-white placeholder:text-gray-500"
                disabled={isLoading}
              />
            </div>

            {/* Agent描述 */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Agent描述（可选）
              </label>
              <Textarea
                placeholder="描述您的AI Agent的功能和特点..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-gray-900/50 border-gray-700 text-white placeholder:text-gray-500 min-h-[100px]"
                disabled={isLoading}
              />
            </div>

            {/* 铸造按钮 */}
            <Button
              onClick={handleMint}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-6 text-lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  铸造中...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  铸造Agent NFT
                </>
              )}
            </Button>

            {/* 提示信息 */}
            <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4">
              <h3 className="text-sm font-semibold text-purple-300 mb-2">
                💡 铸造说明
              </h3>
              <ul className="text-xs text-gray-400 space-y-1">
                <li>• 铸造需要支付少量gas费用（约0.001-0.005 BNB）</li>
                <li>• Logic合约地址必须是有效的智能合约地址</li>
                <li>• 铸造成功后，您将获得唯一的Agent NFT</li>
                <li>• 可以为Agent充值BNB，用于执行链上操作</li>
              </ul>
            </div>
          </div>
        </Card>

        {/* 铸造成功显示 */}
        {mintedAgentId && (
          <Card className="bg-gradient-to-r from-green-900/40 to-emerald-900/40 backdrop-blur-sm border-green-500/50 p-8 mt-8 animate-in fade-in slide-in-from-bottom-4">
            <div className="text-center">
              <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-green-300 mb-2">
                铸造成功！
              </h2>
              <p className="text-gray-300 mb-4">
                您的AI Agent已成功创建
              </p>
              
              <div className="bg-black/30 rounded-lg p-4 mb-4">
                <p className="text-sm text-gray-400 mb-1">Agent ID</p>
                <p className="text-3xl font-bold text-yellow-400">
                  #{mintedAgentId}
                </p>
              </div>

              {txHash && (
                <a
                  href={`https://bscscan.com/tx/${txHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-purple-400 hover:text-purple-300 underline"
                >
                  在BSCScan查看交易 →
                </a>
              )}

              <div className="mt-6 flex gap-4 justify-center">
                <Button
                  onClick={() => setMintedAgentId(null)}
                  variant="outline"
                  className="border-green-500/50 text-green-300 hover:bg-green-900/20"
                >
                  继续铸造
                </Button>
                <Button
                  onClick={() => window.location.href = "/my-agents"}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  查看我的Agents
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
