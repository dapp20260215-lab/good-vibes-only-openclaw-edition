import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useWallet, useTokenBalance } from '@/hooks/useWeb3'
import { CONTRACTS, FEES } from '@/lib/web3Config'
import { ArrowLeft, Coins, Loader2, TrendingUp, Zap } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'

export default function Staking() {
  const { address, isConnected } = useWallet()
  const { qtjBalance } = useTokenBalance(address)
  const [stakeAmount, setStakeAmount] = useState('')
  
  const stakeMutation = trpc.staking.stake.useMutation()
  const unstakeMutation = trpc.staking.unstake.useMutation()
  const claimMutation = trpc.staking.claim.useMutation()
  
  const { data: stakingInfo, refetch } = trpc.staking.getInfo.useQuery(
    { address: address || '' },
    { enabled: !!address }
  )
  
  const { data: globalStats } = trpc.staking.getGlobalStats.useQuery()

  const handleStake = async () => {
    if (!stakeAmount || parseFloat(stakeAmount) <= 0) {
      toast.error('请输入有效的质押数量')
      return
    }

    try {
      await stakeMutation.mutateAsync({
        amount: stakeAmount,
      })
      toast.success('质押成功！')
      setStakeAmount('')
      refetch()
    } catch (error) {
      console.error(error)
      toast.error('质押失败，请重试')
    }
  }

  const handleUnstake = async () => {
    try {
      await unstakeMutation.mutateAsync()
      toast.success('赎回成功！')
      refetch()
    } catch (error: any) {
      console.error(error)
      toast.error(error.message || '赎回失败，请重试')
    }
  }

  const handleClaim = async () => {
    try {
      await claimMutation.mutateAsync()
      toast.success('领取分红成功！')
      refetch()
    } catch (error) {
      console.error(error)
      toast.error('领取失败，请重试')
    }
  }

  const canUnstake = stakingInfo?.canUnstake || false
  const daysStaked = stakingInfo?.daysStaked || 0
  const daysRemaining = Math.max(0, 10 - daysStaked)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12 max-w-6xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
              质押分红
            </h1>
            <p className="text-muted-foreground">
              质押钦天监代币，获得20%交易税分红
            </p>
          </div>

          {!isConnected ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">请先连接钱包</p>
                <WalletConnect />
              </CardContent>
            </Card>
          ) : (
            <>
              {/* 全局统计 */}
              <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <Coins className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                      <div className="text-2xl font-bold">{globalStats?.totalStaked || '0'} 钦天监</div>
                      <div className="text-sm text-muted-foreground mt-1">质押总量</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <TrendingUp className="h-8 w-8 text-green-500 mx-auto mb-2" />
                      <div className="text-2xl font-bold">{globalStats?.totalRewards || '0'} 钦天监</div>
                      <div className="text-sm text-muted-foreground mt-1">累计分红</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <Zap className="h-8 w-8 text-red-500 mx-auto mb-2" />
                      <div className="text-2xl font-bold">{globalStats?.totalBurned || '0'} 钦天监</div>
                      <div className="text-sm text-muted-foreground mt-1">累计销毁</div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {/* 质押操作 */}
                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Coins className="h-5 w-5 text-yellow-500" />
                      质押钦天监
                    </CardTitle>
                    <CardDescription>
                      质押钦天监代币，锁定10天后可赎回
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>质押数量</Label>
                      <Input
                        type="number"
                        placeholder="0.0"
                        value={stakeAmount}
                        onChange={(e) => setStakeAmount(e.target.value)}
                      />
                      <div className="text-xs text-muted-foreground">
                        可用余额: {parseFloat(qtjBalance).toFixed(2)} 钦天监
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      onClick={handleStake}
                      disabled={stakeMutation.isPending || !stakeAmount}
                    >
                      {stakeMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      质押
                    </Button>

                    <div className="bg-muted/50 p-3 rounded-lg text-sm space-y-1">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">锁定期:</span>
                        <span className="font-medium">10天</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">分红比例:</span>
                        <span className="font-medium">20%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 我的质押 */}
                <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-500" />
                      我的质押
                    </CardTitle>
                    <CardDescription>
                      查看您的质押信息和分红
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {stakingInfo?.isStaking ? (
                      <>
                        <div className="bg-muted/50 p-3 rounded-lg space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">质押数量:</span>
                            <span className="font-medium">{stakingInfo.stakedAmount} 钦天监</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">已质押天数:</span>
                            <span className="font-medium">{daysStaked} 天</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">累计分红:</span>
                            <span className="font-medium text-green-500">{stakingInfo.totalRewards} 钦天监</span>
                          </div>
                          {!canUnstake && (
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">剩余锁定:</span>
                              <span className="font-medium text-orange-500">{daysRemaining} 天</span>
                            </div>
                          )}
                        </div>

                        <div className="space-y-2">
                          <Button
                            className="w-full"
                            variant="outline"
                            onClick={handleClaim}
                            disabled={claimMutation.isPending || parseFloat(stakingInfo.totalRewards) <= 0}
                          >
                            {claimMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            领取分红
                          </Button>

                          <Button
                            className="w-full"
                            variant="destructive"
                            onClick={handleUnstake}
                            disabled={unstakeMutation.isPending || !canUnstake}
                          >
                            {unstakeMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {canUnstake ? '赎回质押' : `锁定中 (${daysRemaining}天)`}
                          </Button>
                        </div>

                        {!canUnstake && (
                          <div className="text-xs text-muted-foreground text-center">
                            质押满10天后可赎回，赎回后分红数据清零
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <Coins className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>您还没有质押</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* 说明 */}
              <Card className="bg-card/30 backdrop-blur-sm border-border/30">
                <CardHeader>
                  <CardTitle className="text-lg">质押分红说明</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm text-muted-foreground">
                  <p>1. 质押钦天监代币后，将锁定10天，期间不可赎回</p>
                  <p>2. 分红来源于交易税钱包（{CONTRACTS.TAX_WALLET}）的20%收入</p>
                  <p>3. 分红按质押比例分配，每日结算一次</p>
                  <p>4. 可随时领取已产生的分红，不影响质押状态</p>
                  <p>5. 赎回质押后，分红数据将清零，需要重新质押才能继续获得分红</p>
                  <p>6. 系统会自动监控交易税钱包的BNB余额，并按比例分配给质押用户</p>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  )
}
