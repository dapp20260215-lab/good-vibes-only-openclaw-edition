import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useWallet } from '@/hooks/useWeb3'
import { ArrowLeft, Send, Gift, Loader2, Image as ImageIcon } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'
import { generateHexagramPreview } from '@/lib/hexagramSVG'

export default function MyNFTs() {
  const { address, isConnected } = useWallet()
  const [selectedNFT, setSelectedNFT] = useState<number | null>(null)
  const [transferAddress, setTransferAddress] = useState('')
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false)
  const [isGiftDialogOpen, setIsGiftDialogOpen] = useState(false)

  // 查询用户的NFT
  const { data: nfts = [], refetch } = trpc.nft.getUserNFTs.useQuery(
    { ownerAddress: address || '' },
    { enabled: !!address }
  )

  // 转账NFT
  const transferMutation = trpc.nft.transferNFT.useMutation({
    onSuccess: () => {
      toast.success('NFT转账成功')
      setIsTransferDialogOpen(false)
      setIsGiftDialogOpen(false)
      setTransferAddress('')
      setSelectedNFT(null)
      refetch()
    },
    onError: (error) => {
      toast.error(error.message)
    },
  })

  const handleTransfer = (isGift: boolean) => {
    if (!address || !selectedNFT) {
      toast.error('请先连接钱包并选择NFT')
      return
    }

    if (!transferAddress) {
      toast.error('请输入接收地址')
      return
    }

    // 验证地址格式
    if (!/^0x[a-fA-F0-9]{40}$/.test(transferAddress)) {
      toast.error('接收地址格式不正确')
      return
    }

    // 这里应该调用Web3进行NFT转账，获取交易哈希
    // 简化处理：假设交易成功
    const txHash = '0x' + Math.random().toString(16).slice(2)

    transferMutation.mutate({
      nftId: selectedNFT,
      fromAddress: address,
      toAddress: transferAddress,
      txHash,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
              我的NFT
            </h1>
            <p className="text-muted-foreground">查看、转账和赠送您的卦象NFT</p>
          </div>

          {!isConnected ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">请先连接钱包</p>
                <WalletConnect />
              </CardContent>
            </Card>
          ) : nfts.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <ImageIcon className="h-12 w-12 mx-auto mb-4 opacity-50 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">您还没有任何卦象NFT</p>
                <Link href="/divination">
                  <Button>开始起卦</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {nfts.map((nft) => (
                <Card
                  key={nft.id}
                  className="bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all"
                >
                  <CardHeader>
                    <CardTitle className="text-lg">{nft.hexagramName}</CardTitle>
                    <CardDescription className="text-xs">
                      Token ID: {nft.tokenId}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="aspect-square bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg flex items-center justify-center overflow-hidden">
                      <img 
                        src={generateHexagramPreview(parseInt(nft.hexagram), nft.hexagramName)} 
                        alt={nft.hexagramName}
                        className="w-full h-full object-contain"
                      />
                    </div>

                    {nft.interpretation && (
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {nft.interpretation}
                      </p>
                    )}

                    <div className="text-xs text-muted-foreground">
                      创建时间: {new Date(nft.createdAt).toLocaleDateString('zh-CN')}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <Dialog open={isTransferDialogOpen && selectedNFT === nft.id} onOpenChange={(open) => {
                        setIsTransferDialogOpen(open)
                        if (open) setSelectedNFT(nft.id)
                        else {
                          setSelectedNFT(null)
                          setTransferAddress('')
                        }
                      }}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="w-full gap-1">
                            <Send className="h-3 w-3" />
                            转账
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>转账NFT</DialogTitle>
                            <DialogDescription>
                              将 {nft.hexagramName} 转账给其他地址
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label>接收地址</Label>
                              <Input
                                placeholder="0x..."
                                value={transferAddress}
                                onChange={(e) => setTransferAddress(e.target.value)}
                              />
                            </div>
                            <Button
                              className="w-full"
                              onClick={() => handleTransfer(false)}
                              disabled={transferMutation.isPending}
                            >
                              {transferMutation.isPending && (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              )}
                              确认转账
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>

                      <Dialog open={isGiftDialogOpen && selectedNFT === nft.id} onOpenChange={(open) => {
                        setIsGiftDialogOpen(open)
                        if (open) setSelectedNFT(nft.id)
                        else {
                          setSelectedNFT(null)
                          setTransferAddress('')
                        }
                      }}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="w-full gap-1">
                            <Gift className="h-3 w-3" />
                            赠送
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>赠送NFT</DialogTitle>
                            <DialogDescription>
                              将 {nft.hexagramName} 赠送给其他地址
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label>接收地址</Label>
                              <Input
                                placeholder="0x..."
                                value={transferAddress}
                                onChange={(e) => setTransferAddress(e.target.value)}
                              />
                            </div>
                            <Button
                              className="w-full"
                              onClick={() => handleTransfer(true)}
                              disabled={transferMutation.isPending}
                            >
                              {transferMutation.isPending && (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              )}
                              确认赠送
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* 说明 */}
          <Card className="bg-card/30 backdrop-blur-sm border-border/30">
            <CardHeader>
              <CardTitle className="text-lg">NFT管理说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>1. 每个卦象NFT都是独一无二的，记录了您起卦的时刻和结果</p>
              <p>2. 转账功能可以将NFT转移给其他钱包地址</p>
              <p>3. 赠送功能与转账相同，但更强调礼物性质</p>
              <p>4. NFT可以用于创建预测市场，参与预测获取收益</p>
              <p>5. 所有转账和赠送操作都会记录在区块链上</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
