import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useWallet, useTokenBalance, getBSCScanLink, formatAddress as formatAddr } from '@/hooks/useWeb3'
import { ArrowLeft, Wallet, Coins, Image as ImageIcon, TrendingUp, Award, Copy, Check, LogOut } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'

export default function Profile() {
  const { address, isConnected, disconnect } = useWallet()
  const { bnbBalance, qtjBalance } = useTokenBalance(address)
  const [nickname, setNickname] = useState('')
  const [avatarUrl, setAvatarUrl] = useState('')
  const [isCopied, setIsCopied] = useState(false)

  // 查询用户NFT数量
  const { data: nfts = [] } = trpc.nft.getUserNFTs.useQuery(
    { ownerAddress: address || '' },
    { enabled: !!address }
  )

  // 质押信息（暂时使用模拟数据）
  const stakingInfo = {
    stakedAmount: '0',
    totalRewards: '0',
  }

  // 复制地址到剪贴板
  const copyAddress = () => {
    if (address) {
      navigator.clipboard.writeText(address)
      setIsCopied(true)
      toast.success('地址已复制')
      setTimeout(() => setIsCopied(false), 2000)
    }
  }

  // 格式化地址显示
  const formatAddress = (addr: string) => {
    return formatAddr(addr)
  }

  return (
    <div className="min-h-screen bg-black relative pb-20">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12">
        {!isConnected ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground mb-4">请先连接钱包</p>
              <WalletConnect />
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* 用户信息卡片 */}
            <Card className="bg-card/50 backdrop-blur-sm border-border/50">
              <CardHeader>
                <CardTitle className="text-2xl">个人中心</CardTitle>
                <CardDescription>管理您的账户信息和资产</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* 头像和基本信息 */}
                <div className="flex items-center gap-6">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={avatarUrl || undefined} />
                    <AvatarFallback className="text-2xl bg-gradient-to-br from-purple-500 to-pink-500">
                      {address?.slice(2, 4).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <Wallet className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">钱包地址</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <code className="text-lg font-mono bg-muted px-3 py-1 rounded">
                        {address ? formatAddress(address) : ''}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={copyAddress}
                        className="h-8 w-8"
                      >
                        {isCopied ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* 编辑信息 */}
                <div className="grid md:grid-cols-2 gap-4 pt-4 border-t border-border/50">
                  <div className="space-y-2">
                    <Label>昵称</Label>
                    <Input
                      placeholder="输入昵称"
                      value={nickname}
                      onChange={(e) => setNickname(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>头像URL</Label>
                    <Input
                      placeholder="输入头像图片URL"
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                    />
                  </div>
                </div>

                <Button className="w-full md:w-auto" disabled>
                  保存设置（即将推出）
                </Button>
              </CardContent>
            </Card>

            {/* 资产统计 */}
            <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* BNB余额 */}
              <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/5 border-blue-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2 text-white">
                    <Coins className="h-4 w-4 text-blue-400" />
                    BNB余额
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-400">
                    {parseFloat(bnbBalance).toFixed(4)}
                  </div>
                  <p className="text-xs text-white/60 mt-1">BNB Smart Chain</p>
                </CardContent>
              </Card>

              {/* 钦天监代币余额 */}
              <Card className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border-purple-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2 text-white">
                    <Coins className="h-4 w-4 text-purple-400" />
                    钦天监代币
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-400">
                    {parseFloat(qtjBalance).toFixed(2)}
                  </div>
                  <p className="text-xs text-white/60 mt-1">钦天监代币</p>
                </CardContent>
              </Card>

              {/* NFT收藏数量 */}
              <Card className="bg-gradient-to-br from-pink-500/10 to-pink-500/5 border-pink-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <ImageIcon className="h-4 w-4 text-pink-400" />
                    NFT收藏
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-pink-400">
                    {nfts.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">卦象NFT</p>
                </CardContent>
              </Card>

              {/* 质押总额 */}
              <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border-blue-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-blue-400" />
                    质押总额
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-400">
                    {stakingInfo?.stakedAmount ? Number(stakingInfo.stakedAmount).toLocaleString() : '0'}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">钦天监</p>
                </CardContent>
              </Card>

              {/* 累计分红 */}
              <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Award className="h-4 w-4 text-green-400" />
                    累计分红
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-400">
                    {stakingInfo?.totalRewards ? Number(stakingInfo.totalRewards).toFixed(4) : '0.0000'}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">BNB</p>
                </CardContent>
              </Card>
            </div>

            {/* 快捷操作 */}
            <Card className="bg-card/50 backdrop-blur-sm border-border/50">
              <CardHeader>
                <CardTitle>快捷操作</CardTitle>
                <CardDescription>快速访问常用功能</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <Link href="/divination">
                    <Button variant="outline" className="w-full h-20 flex-col gap-2">
                      <Coins className="h-6 w-6" />
                      <span>起卦</span>
                    </Button>
                  </Link>
                  <Link href="/my-nfts">
                    <Button variant="outline" className="w-full h-20 flex-col gap-2">
                      <ImageIcon className="h-6 w-6" />
                      <span>我的NFT</span>
                    </Button>
                  </Link>
                  <Link href="/staking">
                    <Button variant="outline" className="w-full h-20 flex-col gap-2">
                      <TrendingUp className="h-6 w-6" />
                      <span>质押分红</span>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* 断开连接 */}
            <Card className="bg-black/30 border-white/20">
              <CardContent className="pt-6">
                <Button
                  variant="destructive"
                  className="w-full"
                  onClick={() => {
                    disconnect()
                    toast.success('已断开钱包连接')
                  }}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  断开连接
                </Button>
              </CardContent>
            </Card>

            {/* 账户统计 */}
            <Card className="bg-card/50 backdrop-blur-sm border-border/50">
              <CardHeader>
                <CardTitle>账户统计</CardTitle>
                <CardDescription>您的活动数据概览</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b border-border/30">
                    <span className="text-muted-foreground">总起卦次数</span>
                    <span className="font-semibold">{nfts.length} 次</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-border/30">
                    <span className="text-muted-foreground">AI问卜次数</span>
                    <span className="font-semibold">0 次</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-border/30">
                    <span className="text-muted-foreground">预测参与次数</span>
                    <span className="font-semibold">0 次</span>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <span className="text-muted-foreground">账户创建时间</span>
                    <span className="font-semibold">{new Date().toLocaleDateString('zh-CN')}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
