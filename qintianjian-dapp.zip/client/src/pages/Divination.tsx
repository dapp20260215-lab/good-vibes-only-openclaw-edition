import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useWallet, useTransferQTJ, useTransactionStatus } from '@/hooks/useWeb3'
import { CONTRACTS, FEES } from '@/lib/web3Config'
import { formatEther } from 'viem'
import { generateHexagram, getHexagramInterpretation } from '@/lib/hexagrams'
import { generateHexagramPreview } from '@/lib/hexagramSVG'
import { ArrowLeft, Loader2, Sparkles } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'
import { GoldenCoin } from '@/components/GoldenCoin'

export default function Divination() {
  const { address, isConnected } = useWallet()
  const [throwCount, setThrowCount] = useState(0) // 当前投掷次数 (0-6)
  const [lines, setLines] = useState<number[]>([]) // 已生成的爻 (从下到上)
  const [isThrowingCoins, setIsThrowingCoins] = useState(false)
  const [result, setResult] = useState<ReturnType<typeof generateHexagram> | null>(null)
  const { transfer, hash: transferHash, isPending: isTransferring } = useTransferQTJ()
  const { isSuccess: isTransferSuccess } = useTransactionStatus(transferHash)
  
  // const createDivinationMutation = trpc.divination.create.useMutation() // 已删除NFT功能

  // 投掷一次铜钱
  const handleThrowOnce = async () => {
    if (!isConnected || !address) {
      toast.error('请先连接钱包')
      return
    }

    if (throwCount >= 6) {
      toast.error('已完成六次投掷')
      return
    }

    // 第一次投掷前需要支付1000代币
    if (throwCount === 0) {
      try {
        toast.info('正在支付1000钦天监代币...')
        await transfer(
          CONTRACTS.TAX_WALLET as `0x${string}`, 
          formatEther(BigInt(FEES.DIVINATION_COST))
        )
        
        // 等待一下确保交易提交
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        if (isTransferring) {
          toast.info('交易处理中，请稍候...')
          return
        }
        
        toast.success('支付成功，开始起卦')
      } catch (error) {
        console.error(error)
        toast.error('支付失败，请重试')
        return
      }
    }

    setIsThrowingCoins(true)
    
    // 模拟投掷动画
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // 生成一个爻 (6=老阴, 7=少阳, 8=少阴, 9=老阳)
    const weights = [1, 3, 5, 1] // 老阴、少阳、少阴、老阳的概率权重
    const total = weights.reduce((a, b) => a + b, 0)
    const random = Math.random() * total
    let sum = 0
    let lineValue = 6
    for (let i = 0; i < weights.length; i++) {
      sum += weights[i]
      if (random < sum) {
        lineValue = 6 + i
        break
      }
    }
    
    const newLines = [...lines, lineValue]
    setLines(newLines)
    setThrowCount(throwCount + 1)
    setIsThrowingCoins(false)
    
    // 如果完成六次投掷，生成卦象
    if (throwCount + 1 === 6) {
      const hexagramResult = generateHexagram(newLines)
      setResult(hexagramResult)
      toast.success('卦象生成完成！')
    }
  }

  // 重置起卦
  const handleReset = () => {
    setThrowCount(0)
    setLines([])
    setResult(null)
  }

  // handleMintNFT 已删除 - NFT功能已移除

  // 渲染爻的符号
  const renderLine = (lineValue: number) => {
    if (lineValue === 9 || lineValue === 7) {
      // 阳爻 (实线)
      return <div className="w-full h-2 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded"></div>
    } else {
      // 阴爻 (断线)
      return (
        <div className="w-full h-2 flex gap-2">
          <div className="flex-1 bg-gradient-to-r from-gray-400 to-gray-600 rounded"></div>
          <div className="flex-1 bg-gradient-to-r from-gray-400 to-gray-600 rounded"></div>
        </div>
      )
    }
  }

  return (
    <div className="min-h-screen bg-black">
      {/* 星空背景 */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-purple-950/20 to-black"></div>
        {[...Array(200)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* 导航栏 */}
      <nav className="border-b border-white/10 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2 text-white hover:text-white/80">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12 max-w-4xl relative z-10">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              铜钱起卦
            </h1>
            <p className="text-white/60">
              消耗1000 钦天监代币，生成传统易经卦象
            </p>
          </div>

          {!isConnected ? (
            <Card className="bg-black/80 border-white/20">
              <CardContent className="pt-6 text-center">
                <p className="text-white/60 mb-4">请先连接钱包</p>
                <WalletConnect />
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {/* 起卦区域 */}
              <Card className="bg-black/80 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    投掷铜钱
                  </CardTitle>
                  <CardDescription className="text-white/60">
                    点击按钮投掷三枚铜钱，共投掷六次 ({throwCount}/6)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* 铜钱显示区域 */}
                  <div className="aspect-square bg-gradient-to-br from-yellow-900/20 to-yellow-600/20 rounded-lg flex items-center justify-center relative overflow-hidden border border-yellow-500/30">
                    {isThrowingCoins ? (
                      <div className="text-center space-y-4">
                        <div className="flex gap-4 justify-center">
                          {[1, 2, 3].map(i => (
                            <GoldenCoin key={i} isFlipping={true} size="lg" />
                          ))}
                        </div>
                        <p className="text-yellow-400 font-medium">投掷中...</p>
                      </div>
                    ) : result ? (
                      <div className="w-full h-full flex items-center justify-center p-4">
                        <img 
                          src={generateHexagramPreview(result.hexagram.id, result.hexagram.name)} 
                          alt={result.hexagram.name}
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="text-center space-y-4">
                        <div className="flex gap-4 justify-center">
                          {[1, 2, 3].map(i => (
                            <GoldenCoin key={i} size="lg" />
                          ))}
                        </div>
                        <p className="text-white/60">准备起卦</p>
                      </div>
                    )}
                  </div>

                  {/* 六爻显示 */}
                  <div className="bg-black/50 p-4 rounded-lg border border-white/10">
                    <div className="text-sm text-white/60 mb-3">六爻 (从下到上)</div>
                    <div className="space-y-2">
                      {[...Array(6)].map((_, i) => (
                        <div key={i} className="flex items-center gap-3">
                          <span className="text-xs text-white/40 w-8">第{6-i}爻</span>
                          {lines[5-i] ? (
                            <div className="flex-1 flex items-center gap-2">
                              {renderLine(lines[5-i])}
                              <span className="text-xs text-yellow-400 w-12">
                                {lines[5-i] === 9 ? '老阳' : lines[5-i] === 7 ? '少阳' : lines[5-i] === 8 ? '少阴' : '老阴'}
                              </span>
                            </div>
                          ) : (
                            <div className="flex-1 h-2 bg-white/10 rounded"></div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold"
                      onClick={handleThrowOnce}
                      disabled={isThrowingCoins || throwCount >= 6}
                    >
                      {isThrowingCoins ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          投掷中...
                        </>
                      ) : throwCount >= 6 ? (
                        '已完成'
                      ) : (
                        `投掷第${throwCount + 1}次`
                      )}
                    </Button>
                    {throwCount > 0 && (
                      <Button
                        variant="outline"
                        className="border-white/20 text-white hover:bg-white/10"
                        onClick={handleReset}
                      >
                        重置
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* 卦象结果 */}
              <Card className="bg-black/80 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Sparkles className="h-5 w-5 text-yellow-500" />
                    卦象解读
                  </CardTitle>
                  <CardDescription className="text-white/60">
                    {result ? '您的卦象已生成' : '等待起卦'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result ? (
                    <>
                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="text-sm text-white/60 mb-2">卦名</div>
                        <div className="text-xl font-bold text-white">{result.hexagram.name}卦</div>
                      </div>

                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="text-sm text-white/60 mb-2">卦辞</div>
                        <div className="text-sm text-white/80">{result.hexagram.description}</div>
                      </div>

                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="text-sm text-white/60 mb-2">解释</div>
                        <div className="text-sm leading-relaxed text-white/80">
                          {getHexagramInterpretation(result.hexagram)}
                        </div>
                      </div>

                      <div className="text-center py-4 text-white/60">
                        <p className="text-sm">卦象已生成，可继续起卦或查看历史记录</p>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-12 text-white/40">
                      <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>投掷铜钱后查看卦象</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* 说明 */}
          <Card className="bg-black/60 backdrop-blur-sm border-white/10">
            <CardHeader>
              <CardTitle className="text-lg text-white">起卦说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-white/60">
              <p>1. 铜钱起卦法是传统易经占卜方法之一</p>
              <p>2. 每次投掷3枚铜钱，共投掷6次，从下往上形成卦象</p>
              <p>3. 生成的卦象将保存在区块链上，可随时查看历史记录</p>
              <p>4. 每次起卦需支付1000钦天监代币，代币将转入项目接受地址</p>
              <p>5. 支付成功后即可开始投掷铜钱，建议记录卦象结果</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
