import { WalletConnect } from '@/components/WalletConnect'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { useWallet, useTransferQTJ, useTransactionStatus } from '@/hooks/useWeb3'
import { CONTRACTS, FEES } from '@/lib/web3Config'
import { ArrowLeft, Loader2, Sparkles } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Link } from 'wouter'
import { trpc } from '@/lib/trpc'
import { formatEther } from 'viem'
import { Streamdown } from 'streamdown'

export default function AIDivination() {
  const { address, isConnected } = useWallet()
  const [question, setQuestion] = useState('')
  const [result, setResult] = useState<string | null>(null)
  const { transfer, hash: transferHash, isPending: isTransferring } = useTransferQTJ()
  const { isSuccess: isTransferSuccess } = useTransactionStatus(transferHash)
  
  const aiDivinationMutation = trpc.ai.divination.useMutation()

  const handleAskAI = async () => {
    if (!isConnected || !address) {
      toast.error('请先连接钱包')
      return
    }

    if (!question.trim()) {
      toast.error('请输入您的问题')
      return
    }

    try {
      // 1. 支付2000代币到接受地址
      toast.info('正在支付2000钦天监代币...')
      await transfer(
        CONTRACTS.TAX_WALLET as `0x${string}`, 
        formatEther(BigInt(FEES.AI_DIVINATION_COST))
      )
      
      // 等待一下确保交易提交
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      if (isTransferring) {
        toast.info('交易处理中，请稍候...')
        return
      }
      
      toast.success('支付成功')

      // 2. 调用AI问卜
      toast.info('AI正在解读卦象...')
      const response = await aiDivinationMutation.mutateAsync({
        question: question.trim(),
      })

      setResult(typeof response.interpretation === 'string' ? response.interpretation : JSON.stringify(response.interpretation))
      toast.success('AI解读完成！')
    } catch (error) {
      console.error(error)
      toast.error('问卜失败，请重试')
    }
  }

  const handleReset = () => {
    setQuestion('')
    setResult(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 导航栏 */}
      <nav className="border-b border-border/40 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                返回首页
              </Button>
            </Link>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
              AI问卜
            </h1>
            <p className="text-muted-foreground">
              消耗2000 钦天监代币，AI为您解读卦象，提供深度预测分析
            </p>
          </div>

          {!isConnected ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">请先连接钱包</p>
                <WalletConnect />
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {/* 问题输入区域 */}
              <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-purple-500" />
                    提问
                  </CardTitle>
                  <CardDescription>
                    请输入您想要询问的问题
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="例如：我最近的事业运势如何？"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    rows={6}
                    disabled={!!result}
                  />

                  <div className="bg-muted/50 p-3 rounded-lg text-sm text-muted-foreground">
                    <p>💡 提示：</p>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li>问题应该明确具体</li>
                      <li>避免过于宽泛的问题</li>
                      <li>一次只问一个问题</li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">
                      AI问卜需要消耗 <span className="font-bold text-foreground">2000 钦天监</span>
                    </div>
                    {!result ? (
                      <Button
                        className="w-full"
                        onClick={handleAskAI}
                        disabled={isTransferring || aiDivinationMutation.isPending || !question.trim()}
                      >
                        {(isTransferring || aiDivinationMutation.isPending) && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {isTransferring
                          ? '支付中...'
                          : aiDivinationMutation.isPending
                          ? 'AI解读中...'
                          : '开始问卜'}
                      </Button>
                    ) : (
                      <Button
                        className="w-full"
                        variant="outline"
                        onClick={handleReset}
                      >
                        重新问卜
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* AI解读结果 */}
              <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-pink-500" />
                    AI解读
                  </CardTitle>
                  <CardDescription>
                    {result ? 'AI为您解读如下' : '等待问卜'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {result ? (
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <Streamdown>{result}</Streamdown>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>输入问题后查看AI解读</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* 说明 */}
          <Card className="bg-card/30 backdrop-blur-sm border-border/30">
            <CardHeader>
              <CardTitle className="text-lg">AI问卜说明</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>1. AI问卜基于易经智慧和现代AI技术</p>
              <p>2. 每次问卜消耗２000钦天监代币，代币将转入项目接受地址</p>
              <p>3. AI会根据您的问题生成卦象并提供深度解读</p>
              <p>4. 问卜结果仅供参考，不构成任何投资或决策建议</p>
              <p>5. 所有问卜记录将保存在区块链上，可随时查看历史记录</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
