# BSCScan快速验证参考

## 🚀 BAP578合约验证

### 验证URL
```
https://bscscan.com/verifyContract?a=0x02aDF991D570512A812D109674Ba6A9B89e815b0
```

### 验证信息

| 字段 | 值 |
|------|-----|
| Contract Address | `0x02aDF991D570512A812D109674Ba6A9B89e815b0` |
| Compiler Type | `Solidity (Single file)` |
| Compiler Version | `v0.8.20+commit.a1b79de6` |
| License Type | `3) MIT License (MIT)` |
| Contract Name | `BAP578` |
| Optimization | `Yes` |
| Runs | `200` |

### 构造函数参数（ABI-encoded）

```
000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000e6a825646ab67cd3f1ad8a8d49d0ee087477dbb0000000000000000000000000000000000000000000000000000000000000001151696e5469616e4a69616e204167656e74000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000451544a4100000000000000000000000000000000000000000000000000000000
```

### 合约代码

使用扁平化的合约代码文件：`BAP578_flattened.sol`

---

## 🚀 Registry合约验证

### 验证URL
```
https://bscscan.com/verifyContract?a=0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0
```

### 验证信息

| 字段 | 值 |
|------|-----|
| Contract Address | `0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0` |
| Compiler Type | `Solidity (Single file)` |
| Compiler Version | `v0.8.20+commit.a1b79de6` |
| License Type | `3) MIT License (MIT)` |
| Contract Name | `Registry` |
| Optimization | `Yes` |
| Runs | `200` |

### 构造函数参数

```
(留空 - Registry没有构造函数参数)
```

### 合约代码

使用扁平化的合约代码文件：`Registry_flattened.sol`

---

## 📁 文件位置

所有验证所需文件位于项目根目录：

- `BAP578_flattened.sol` - BAP578扁平化合约代码
- `Registry_flattened.sol` - Registry扁平化合约代码
- `BSCSCAN_VERIFICATION_GUIDE.md` - 详细验证指南

---

## ✅ 验证步骤总结

1. 访问验证URL
2. 选择编译器类型和版本
3. 填写合约名称
4. 启用优化（Runs: 200）
5. 粘贴扁平化合约代码
6. 填写构造函数参数（BAP578需要，Registry不需要）
7. 完成reCAPTCHA
8. 点击"Verify and Publish"

---

## 🔍 验证后检查

验证成功后，访问合约页面应该看到：

- ✅ 绿色对勾标记
- "Contract Source Code Verified (Exact Match)"
- Read Contract 和 Write Contract 标签可用
- 合约代码可见

---

## 📞 遇到问题？

如果验证失败，检查：

1. **编译器版本**：必须是 `v0.8.20+commit.a1b79de6`
2. **优化设置**：必须是 `Yes`, Runs: `200`
3. **构造函数参数**：BAP578需要填写，Registry留空
4. **SPDX标识符**：扁平化文件中只能有一个
5. **合约名称**：必须与代码中的合约名完全一致

---

**最后更新**：2026-02-15
