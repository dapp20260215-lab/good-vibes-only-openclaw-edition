# BAP-578分红机制测试指南

## 📋 分红机制说明

BAP-578合约实现了**20%自动分红机制**：
- 所有通过`receive()`函数接收的BNB，自动分配20%到分红池
- 所有通过`fundAgent()`函数充值的BNB，自动分配20%到分红池
- 分红池地址：`0x7EfF6A14354445A83E75d4288e608198b9f9878e`

---

## 🧪 测试方法

### 方法1：直接向合约转账

1. **准备测试钱包**
   - 确保钱包有足够的BNB（建议至少0.15 BNB）
   - 记录分红池初始余额

2. **向合约转账**
   ```
   发送到：0x02aDF991D570512A812D109674Ba6A9B89e815b0
   金额：0.1 BNB
   ```

3. **验证分红**
   - 查看分红池地址余额增加
   - 预期增加：0.02 BNB（0.1 * 20%）

### 方法2：使用Hardhat脚本

```bash
# 确保钱包有足够余额
cd /home/ubuntu/qintianjian-dapp
PRIVATE_KEY=your_private_key npx hardhat run scripts/test-dividend.cjs --network bscMainnet
```

### 方法3：通过BSCScan

1. 访问合约地址：https://bscscan.com/address/0x02aDF991D570512A812D109674Ba6A9B89e815b0

2. 点击"Write Contract"标签

3. 连接钱包

4. 找到`receive`函数或直接发送BNB

5. 输入金额（例如0.1 BNB）

6. 确认交易

7. 查看分红池地址余额变化

---

## 📊 验证步骤

### 1. 记录初始余额

访问BSCScan查看分红池地址：
https://bscscan.com/address/0x7EfF6A14354445A83E75d4288e608198b9f9878e

记录当前余额（例如：0.00 BNB）

### 2. 执行转账

向BAP578合约发送测试金额（例如：0.1 BNB）

### 3. 验证分红

再次查看分红池地址余额，应该增加：
- 发送0.1 BNB → 分红池增加0.02 BNB
- 发送0.5 BNB → 分红池增加0.1 BNB
- 发送1.0 BNB → 分红池增加0.2 BNB

### 4. 查看交易详情

在BSCScan上查看交易详情，可以看到：
- 主交易：向BAP578合约转账
- 内部交易：BAP578合约向分红池转账20%

---

## 🔍 常见问题

### Q: 为什么我的转账没有触发分红？

A: 确保：
1. 转账目标地址是BAP578合约地址（0x02aDF991D570512A812D109674Ba6A9B89e815b0）
2. 转账金额大于0
3. 交易成功确认（没有revert）

### Q: 如何查看内部交易？

A: 在BSCScan交易详情页面，点击"Internal Txns"标签，可以看到合约自动向分红池转账的记录。

### Q: 分红比例可以修改吗？

A: 不可以。分红比例20%是合约常量，部署后无法修改。这保证了分红机制的透明性和不可篡改性。

### Q: fundAgent()函数也会触发分红吗？

A: 是的。通过`fundAgent()`为Agent充值时，同样会自动分配20%到分红池，剩余80%进入Agent余额。

---

## 📈 测试记录模板

```
测试时间：2026-02-15
测试网络：BSC主网
测试钱包：0x...
合约地址：0x02aDF991D570512A812D109674Ba6A9B89e815b0
分红池地址：0x7EfF6A14354445A83E75d4288e608198b9f9878e

初始状态：
- 分红池余额：_____ BNB
- 测试钱包余额：_____ BNB

执行操作：
- 操作类型：直接转账 / fundAgent
- 转账金额：_____ BNB
- 交易哈希：0x...

最终状态：
- 分红池余额：_____ BNB
- 分红池增加：_____ BNB
- 预期增加：_____ BNB
- 测试结果：✅ 成功 / ❌ 失败
```

---

## 🚀 自动化测试脚本

如果您有足够的BNB余额，可以运行自动化测试脚本：

```javascript
// scripts/test-dividend.cjs
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const BAP578_ADDRESS = "0x02aDF991D570512A812D109674Ba6A9B89e815b0";
  const DIVIDEND_POOL = "0x7EfF6A14354445A83E75d4288e608198b9f9878e";
  
  // 记录初始余额
  const initialBalance = await hre.ethers.provider.getBalance(DIVIDEND_POOL);
  console.log("Initial pool balance:", hre.ethers.formatEther(initialBalance));
  
  // 发送0.1 BNB
  const tx = await deployer.sendTransaction({
    to: BAP578_ADDRESS,
    value: hre.ethers.parseEther("0.1"),
  });
  await tx.wait();
  
  // 验证分红
  const finalBalance = await hre.ethers.provider.getBalance(DIVIDEND_POOL);
  const increase = finalBalance - initialBalance;
  console.log("Pool increase:", hre.ethers.formatEther(increase));
  console.log("Expected: 0.02 BNB");
  console.log("Test:", increase === hre.ethers.parseEther("0.02") ? "✅ PASS" : "❌ FAIL");
}

main();
```

---

## ⚠️ 注意事项

1. **测试环境**：建议先在BSC测试网测试，确认无误后再在主网测试
2. **Gas费用**：每次测试需要支付gas费用（约0.0001-0.0005 BNB）
3. **最小金额**：建议测试金额不低于0.01 BNB，以便清楚观察分红效果
4. **交易确认**：等待交易确认后再查看余额变化（通常1-3秒）
5. **记录保存**：建议保存每次测试的交易哈希，方便后续审计

---

## 📞 技术支持

如有问题，请查看：
- BSCScan合约地址：https://bscscan.com/address/0x02aDF991D570512A812D109674Ba6A9B89e815b0
- 部署信息文档：DEPLOYMENT_INFO.md
- BAP-578标准：https://github.com/bnb-chain/BEPs/blob/master/BAPs/BAP-578.md
