const { ethers } = require("hardhat");

async function main() {
  console.log("=== BAP578 Constructor Arguments ===\n");
  
  const name = "QinTianJian Agent";
  const symbol = "QTJA";
  const registry = "0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0";
  
  console.log("Parameters:");
  console.log("- name:", name);
  console.log("- symbol:", symbol);
  console.log("- registry:", registry);
  console.log();
  
  // ABI encode constructor arguments
  const abiCoder = ethers.AbiCoder.defaultAbiCoder();
  const encoded = abiCoder.encode(
    ["string", "string", "address"],
    [name, symbol, registry]
  );
  
  // Remove 0x prefix for BSCScan
  const constructorArgs = encoded.slice(2);
  
  console.log("ABI-encoded Constructor Arguments:");
  console.log(constructorArgs);
  console.log();
  console.log("Copy the above hex string and paste it into BSCScan's");
  console.log("'Constructor Arguments ABI-encoded' field");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
