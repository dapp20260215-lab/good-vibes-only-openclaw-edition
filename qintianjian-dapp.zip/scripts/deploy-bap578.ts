import { ethers } from "hardhat";

async function main() {
  console.log("🚀 Starting BAP-578 deployment...\n");

  // Get deployer account
  const [deployer] = await ethers.getSigners();
  console.log("📝 Deploying contracts with account:", deployer.address);
  
  const balance = await ethers.provider.getBalance(deployer.address);
  console.log("💰 Account balance:", ethers.formatEther(balance), "BNB\n");

  // Step 1: Deploy Registry
  console.log("📦 Deploying Registry contract...");
  const Registry = await ethers.getContractFactory("Registry");
  const registry = await Registry.deploy();
  await registry.waitForDeployment();
  const registryAddress = await registry.getAddress();
  console.log("✅ Registry deployed to:", registryAddress, "\n");

  // Step 2: Deploy BAP578
  console.log("📦 Deploying BAP578 contract...");
  const BAP578 = await ethers.getContractFactory("BAP578");
  const bap578 = await BAP578.deploy(
    "QinTianJian Agent",  // name
    "QTJA",               // symbol
    registryAddress       // registry address
  );
  await bap578.waitForDeployment();
  const bap578Address = await bap578.getAddress();
  console.log("✅ BAP578 deployed to:", bap578Address, "\n");

  // Step 3: Whitelist BAP578 contract in Registry
  console.log("🔐 Whitelisting BAP578 contract in Registry...");
  const whitelistTx = await registry.whitelistContract(bap578Address);
  await whitelistTx.wait();
  console.log("✅ BAP578 contract whitelisted\n");

  // Step 4: Verify ERC-165 interface support
  console.log("🔍 Verifying ERC-165 interface support...");
  
  // Calculate BAP-578 interface ID
  const bap578InterfaceId = "0x" + (
    BigInt(ethers.id("executeAction(uint256,bytes)").slice(0, 10)) ^
    BigInt(ethers.id("setLogicAddress(uint256,address)").slice(0, 10)) ^
    BigInt(ethers.id("fundAgent(uint256)").slice(0, 10)) ^
    BigInt(ethers.id("getState(uint256)").slice(0, 10)) ^
    BigInt(ethers.id("getAgentMetadata(uint256)").slice(0, 10)) ^
    BigInt(ethers.id("updateAgentMetadata(uint256,(string,string,string,string,string,bytes32))").slice(0, 10)) ^
    BigInt(ethers.id("pause(uint256)").slice(0, 10)) ^
    BigInt(ethers.id("unpause(uint256)").slice(0, 10)) ^
    BigInt(ethers.id("terminate(uint256)").slice(0, 10))
  ).toString(16).padStart(8, '0');
  
  console.log("📋 BAP-578 Interface ID:", bap578InterfaceId);
  
  const supportsBAP578 = await bap578.supportsInterface(bap578InterfaceId);
  console.log("✅ Supports BAP-578:", supportsBAP578);
  
  const supportsERC721 = await bap578.supportsInterface("0x80ac58cd");
  console.log("✅ Supports ERC-721:", supportsERC721);
  
  const supportsERC165 = await bap578.supportsInterface("0x01ffc9a7");
  console.log("✅ Supports ERC-165:", supportsERC165, "\n");

  // Step 5: Calculate event hashes
  console.log("🔍 Verifying event hashes...");
  const eventHashes = {
    ActionExecuted: ethers.id("ActionExecuted(address,bytes)"),
    LogicUpgraded: ethers.id("LogicUpgraded(address,address,address)"),
    AgentFunded: ethers.id("AgentFunded(address,address,uint256)"),
    StatusChanged: ethers.id("StatusChanged(address,uint8)"),
    MetadataUpdated: ethers.id("MetadataUpdated(uint256,string)")
  };
  
  console.log("📋 Event Hashes:");
  Object.entries(eventHashes).forEach(([name, hash]) => {
    console.log(`  ${name}: ${hash}`);
  });
  console.log();

  // Summary
  console.log("=" .repeat(60));
  console.log("🎉 Deployment Summary");
  console.log("=" .repeat(60));
  console.log("Registry Address:     ", registryAddress);
  console.log("BAP578 Address:       ", bap578Address);
  console.log("BAP-578 Interface ID: ", bap578InterfaceId);
  console.log("Network:              ", (await ethers.provider.getNetwork()).name);
  console.log("Chain ID:             ", (await ethers.provider.getNetwork()).chainId);
  console.log("=" .repeat(60));
  console.log();

  // Save deployment info
  const deploymentInfo = {
    network: (await ethers.provider.getNetwork()).name,
    chainId: Number((await ethers.provider.getNetwork()).chainId),
    deployer: deployer.address,
    contracts: {
      Registry: registryAddress,
      BAP578: bap578Address
    },
    interfaceId: bap578InterfaceId,
    eventHashes,
    timestamp: new Date().toISOString()
  };

  console.log("📄 Deployment info:");
  console.log(JSON.stringify(deploymentInfo, null, 2));
  console.log();
  
  console.log("✅ Deployment completed successfully!");
  console.log();
  console.log("📝 Next steps:");
  console.log("1. Verify contracts on BSCScan");
  console.log("2. Mint test agents");
  console.log("3. Test agent functionality");
  console.log();

  return deploymentInfo;
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
