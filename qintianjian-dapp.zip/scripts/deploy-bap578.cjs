const hre = require("hardhat");

async function main() {
  console.log("🚀 Starting BAP-578 deployment...\n");

  // Get deployer account
  const [deployer] = await hre.ethers.getSigners();
  console.log("📝 Deploying contracts with account:", deployer.address);
  
  const balance = await hre.ethers.provider.getBalance(deployer.address);
  console.log("💰 Account balance:", hre.ethers.formatEther(balance), "BNB\n");

  // Step 1: Deploy Registry
  console.log("📦 Deploying Registry contract...");
  const Registry = await hre.ethers.getContractFactory("Registry");
  const registry = await Registry.deploy();
  await registry.waitForDeployment();
  const registryAddress = await registry.getAddress();
  console.log("✅ Registry deployed to:", registryAddress, "\n");

  // Step 2: Deploy BAP578
  console.log("📦 Deploying BAP578 contract...");
  const BAP578 = await hre.ethers.getContractFactory("BAP578");
  const bap578 = await BAP578.deploy(
    "QinTianJian Agent",
    "QTJA",
    registryAddress
  );
  await bap578.waitForDeployment();
  const bap578Address = await bap578.getAddress();
  console.log("✅ BAP578 deployed to:", bap578Address, "\n");

  // Step 3: Whitelist BAP578 contract in Registry
  console.log("🔐 Whitelisting BAP578 contract in Registry...");
  const whitelistTx = await registry.whitelistContract(bap578Address);
  await whitelistTx.wait();
  console.log("✅ BAP578 contract whitelisted\n");

  // Step 4: Verify contract addresses
  console.log("🔍 Verifying contract configuration...");
  const addresses = await bap578.getAddresses();
  console.log("📋 Token Receiver:", addresses[0]);
  console.log("📋 Dividend Pool:", addresses[1]);
  console.log("📋 Dividend Percentage:", await bap578.DIVIDEND_PERCENTAGE(), "%\n");

  // Summary
  console.log("=".repeat(60));
  console.log("🎉 Deployment Summary");
  console.log("=".repeat(60));
  console.log("Registry Address:     ", registryAddress);
  console.log("BAP578 Address:       ", bap578Address);
  console.log("Token Receiver:       ", addresses[0]);
  console.log("Dividend Pool:        ", addresses[1]);
  console.log("Network:              ", (await hre.ethers.provider.getNetwork()).name);
  console.log("Chain ID:             ", (await hre.ethers.provider.getNetwork()).chainId);
  console.log("=".repeat(60));
  console.log("\n✅ Deployment completed successfully!");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
