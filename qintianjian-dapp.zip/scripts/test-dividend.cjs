const hre = require("hardhat");

async function main() {
  console.log("🧪 Testing Dividend Mechanism...\n");

  const [deployer] = await hre.ethers.getSigners();
  console.log("Test account:", deployer.address);

  const BAP578_ADDRESS = "0x02aDF991D570512A812D109674Ba6A9B89e815b0";
  const DIVIDEND_POOL = "0x7EfF6A14354445A83E75d4288e608198b9f9878e";
  
  // Get initial balances
  const initialPoolBalance = await hre.ethers.provider.getBalance(DIVIDEND_POOL);
  console.log("Initial dividend pool balance:", hre.ethers.formatEther(initialPoolBalance), "BNB\n");

  // Send 0.1 BNB to contract
  console.log("Sending 0.1 BNB to BAP578 contract...");
  const tx = await deployer.sendTransaction({
    to: BAP578_ADDRESS,
    value: hre.ethers.parseEther("0.1"),
  });
  
  console.log("Transaction hash:", tx.hash);
  await tx.wait();
  console.log("✅ Transaction confirmed\n");

  // Check final balances
  const finalPoolBalance = await hre.ethers.provider.getBalance(DIVIDEND_POOL);
  const poolIncrease = finalPoolBalance - initialPoolBalance;
  
  console.log("Final dividend pool balance:", hre.ethers.formatEther(finalPoolBalance), "BNB");
  console.log("Pool increase:", hre.ethers.formatEther(poolIncrease), "BNB");
  console.log("Expected increase:", "0.02 BNB (20% of 0.1 BNB)");
  
  if (poolIncrease === hre.ethers.parseEther("0.02")) {
    console.log("\n✅ Dividend mechanism working correctly!");
  } else {
    console.log("\n⚠️ Dividend amount mismatch!");
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
