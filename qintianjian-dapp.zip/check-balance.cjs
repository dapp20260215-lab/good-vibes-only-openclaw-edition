const hre = require("hardhat");

async function main() {
  const address = "0x89A3fef2D522495224915Db6e765a7bEf5490aE4";
  const balance = await hre.ethers.provider.getBalance(address);
  console.log("Address:", address);
  console.log("Balance:", hre.ethers.formatEther(balance), "BNB");
  console.log("Balance (wei):", balance.toString());
}

main().then(() => process.exit(0)).catch((error) => {
  console.error(error);
  process.exit(1);
});
