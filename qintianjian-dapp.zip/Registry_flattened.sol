// Sources flattened with hardhat v2.28.6 https://hardhat.org

// SPDX-License-Identifier: MIT

// File @openzeppelin/contracts/utils/Context.sol@v5.4.0

// Original license: SPDX_License_Identifier: MIT
// OpenZeppelin Contracts (last updated v5.0.1) (utils/Context.sol)

pragma solidity ^0.8.20;

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }

    function _contextSuffixLength() internal view virtual returns (uint256) {
        return 0;
    }
}


// File @openzeppelin/contracts/access/Ownable.sol@v5.4.0

// Original license: SPDX_License_Identifier: MIT
// OpenZeppelin Contracts (last updated v5.0.0) (access/Ownable.sol)

pragma solidity ^0.8.20;

/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * The initial owner is set to the address provided by the deployer. This can
 * later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
abstract contract Ownable is Context {
    address private _owner;

    /**
     * @dev The caller account is not authorized to perform an operation.
     */
    error OwnableUnauthorizedAccount(address account);

    /**
     * @dev The owner is not a valid owner account. (eg. `address(0)`)
     */
    error OwnableInvalidOwner(address owner);

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    /**
     * @dev Initializes the contract setting the address provided by the deployer as the initial owner.
     */
    constructor(address initialOwner) {
        if (initialOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(initialOwner);
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if the sender is not the owner.
     */
    function _checkOwner() internal view virtual {
        if (owner() != _msgSender()) {
            revert OwnableUnauthorizedAccount(_msgSender());
        }
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby disabling any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        if (newOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(newOwner);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}


// File contracts/interfaces/IRegistry.sol

// Original license: SPDX_License_Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title IRegistry
 * @dev Interface for BAP-578 Agent Registry
 * @notice Registry contract for managing agent registration and activation on BNB Chain
 */
interface IRegistry {
    
    /// @dev Agent registration information
    struct AgentInfo {
        address tokenContract;    // BAP-578 token contract address
        uint256 tokenId;          // Token ID within the contract
        address logicAddress;     // Logic contract address
        bool isActive;            // Whether agent is active
        uint256 registrationTime; // Timestamp of registration
    }
    
    // ============ Events ============
    
    /**
     * @dev Emitted when an agent is registered
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @param logicAddress Logic contract address
     */
    event AgentRegistered(
        address indexed tokenContract,
        uint256 indexed tokenId,
        address logicAddress
    );
    
    /**
     * @dev Emitted when an agent is activated
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     */
    event AgentActivated(
        address indexed tokenContract,
        uint256 indexed tokenId
    );
    
    /**
     * @dev Emitted when an agent is deactivated
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     */
    event AgentDeactivated(
        address indexed tokenContract,
        uint256 indexed tokenId
    );
    
    // ============ Functions ============
    
    /**
     * @dev Register a new agent in the registry
     * @param tokenId Token ID of the agent
     * @param logicAddress Logic contract address for the agent
     * @notice Only callable by registered BAP-578 token contracts
     * @notice Emits AgentRegistered event
     */
    function registerAgent(uint256 tokenId, address logicAddress) external;
    
    /**
     * @dev Activate a registered agent
     * @param tokenId Token ID of the agent
     * @notice Only callable by the token contract owner
     * @notice Agent must be registered first
     * @notice Emits AgentActivated event
     */
    function activateAgent(uint256 tokenId) external;
    
    /**
     * @dev Deactivate an active agent
     * @param tokenId Token ID of the agent
     * @notice Only callable by the token contract owner
     * @notice Agent must be active
     * @notice Emits AgentDeactivated event
     */
    function deactivateAgent(uint256 tokenId) external;
    
    /**
     * @dev Get agent information from registry
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @return AgentInfo struct containing agent information
     */
    function getAgentInfo(address tokenContract, uint256 tokenId) 
        external 
        view 
        returns (AgentInfo memory);
    
    /**
     * @dev Check if an agent is registered
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @return bool True if agent is registered
     */
    function isRegistered(address tokenContract, uint256 tokenId) 
        external 
        view 
        returns (bool);
    
    /**
     * @dev Check if an agent is active
     * @param tokenContract Address of the BAP-578 token contract
     * @param tokenId Token ID of the agent
     * @return bool True if agent is active
     */
    function isActive(address tokenContract, uint256 tokenId) 
        external 
        view 
        returns (bool);
}


// File contracts/Registry.sol

// Original license: SPDX_License_Identifier: MIT
pragma solidity ^0.8.20;


/**
 * @title Registry
 * @dev Implementation of BAP-578 Agent Registry
 * @notice Central registry for managing agent registration and activation on BNB Chain
 */
contract Registry is IRegistry, Ownable {
    
    // ============ State Variables ============
    
    /// @dev Mapping from (tokenContract, tokenId) to AgentInfo
    mapping(address => mapping(uint256 => AgentInfo)) private _agents;
    
    /// @dev Mapping of whitelisted BAP-578 token contracts
    mapping(address => bool) public whitelistedContracts;
    
    /// @dev Total number of registered agents
    uint256 public totalRegistered;
    
    /// @dev Total number of active agents
    uint256 public totalActive;
    
    // ============ Constructor ============
    
    constructor() Ownable(msg.sender) {}
    
    // ============ Modifiers ============
    
    /**
     * @dev Modifier to check if contract is whitelisted
     */
    modifier onlyWhitelisted() {
        require(
            whitelistedContracts[msg.sender],
            "Registry: caller is not whitelisted"
        );
        _;
    }
    
    // ============ Admin Functions ============
    
    /**
     * @dev Whitelist a BAP-578 token contract
     * @param tokenContract Address of the token contract to whitelist
     * @notice Only callable by registry owner
     */
    function whitelistContract(address tokenContract) external onlyOwner {
        require(tokenContract != address(0), "Registry: invalid contract address");
        require(!whitelistedContracts[tokenContract], "Registry: already whitelisted");
        
        whitelistedContracts[tokenContract] = true;
    }
    
    /**
     * @dev Remove a contract from whitelist
     * @param tokenContract Address of the token contract to remove
     * @notice Only callable by registry owner
     */
    function removeWhitelist(address tokenContract) external onlyOwner {
        require(whitelistedContracts[tokenContract], "Registry: not whitelisted");
        
        whitelistedContracts[tokenContract] = false;
    }
    
    // ============ Core Functions ============
    
    /**
     * @inheritdoc IRegistry
     */
    function registerAgent(uint256 tokenId, address logicAddress) 
        external 
        override 
        onlyWhitelisted 
    {
        require(logicAddress != address(0), "Registry: invalid logic address");
        require(
            _agents[msg.sender][tokenId].tokenContract == address(0),
            "Registry: agent already registered"
        );
        
        _agents[msg.sender][tokenId] = AgentInfo({
            tokenContract: msg.sender,
            tokenId: tokenId,
            logicAddress: logicAddress,
            isActive: false,
            registrationTime: block.timestamp
        });
        
        totalRegistered++;
        
        emit AgentRegistered(msg.sender, tokenId, logicAddress);
    }
    
    /**
     * @inheritdoc IRegistry
     */
    function activateAgent(uint256 tokenId) 
        external 
        override 
        onlyWhitelisted 
    {
        AgentInfo storage agent = _agents[msg.sender][tokenId];
        
        require(
            agent.tokenContract != address(0),
            "Registry: agent not registered"
        );
        require(!agent.isActive, "Registry: agent already active");
        
        agent.isActive = true;
        totalActive++;
        
        emit AgentActivated(msg.sender, tokenId);
    }
    
    /**
     * @inheritdoc IRegistry
     */
    function deactivateAgent(uint256 tokenId) 
        external 
        override 
        onlyWhitelisted 
    {
        AgentInfo storage agent = _agents[msg.sender][tokenId];
        
        require(
            agent.tokenContract != address(0),
            "Registry: agent not registered"
        );
        require(agent.isActive, "Registry: agent not active");
        
        agent.isActive = false;
        totalActive--;
        
        emit AgentDeactivated(msg.sender, tokenId);
    }
    
    // ============ View Functions ============
    
    /**
     * @inheritdoc IRegistry
     */
    function getAgentInfo(address tokenContract, uint256 tokenId) 
        external 
        view 
        override 
        returns (AgentInfo memory) 
    {
        return _agents[tokenContract][tokenId];
    }
    
    /**
     * @inheritdoc IRegistry
     */
    function isRegistered(address tokenContract, uint256 tokenId) 
        external 
        view 
        override 
        returns (bool) 
    {
        return _agents[tokenContract][tokenId].tokenContract != address(0);
    }
    
    /**
     * @inheritdoc IRegistry
     */
    function isActive(address tokenContract, uint256 tokenId) 
        external 
        view 
        override 
        returns (bool) 
    {
        return _agents[tokenContract][tokenId].isActive;
    }
    
    /**
     * @dev Get registry statistics
     * @return registered Total number of registered agents
     * @return active Total number of active agents
     */
    function getStats() external view returns (uint256 registered, uint256 active) {
        return (totalRegistered, totalActive);
    }
}
