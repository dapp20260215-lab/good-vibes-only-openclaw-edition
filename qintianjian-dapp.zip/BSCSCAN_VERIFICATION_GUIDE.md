# BSCScan合约源代码验证指南

## 📋 准备工作

在开始验证之前，请确保您有以下信息：

### BAP578主合约
- **合约地址**：`0x02aDF991D570512A812D109674Ba6A9B89e815b0`
- **合约名称**：`BAP578`
- **编译器版本**：`v0.8.20+commit.a1b79de6`
- **优化**：启用，运行次数 200

### Registry合约
- **合约地址**：`0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0`
- **合约名称**：`Registry`
- **编译器版本**：`v0.8.20+commit.a1b79de6`
- **优化**：启用，运行次数 200

---

## 🔍 验证步骤

### 步骤1：访问BSCScan验证页面

1. 打开浏览器，访问BAP578合约验证页面：
   ```
   https://bscscan.com/verifyContract?a=0x02aDF991D570512A812D109674Ba6A9B89e815b0
   ```

2. 或者手动导航：
   - 访问 https://bscscan.com/address/0x02aDF991D570512A812D109674Ba6A9B89e815b0
   - 点击 "Contract" 标签
   - 点击 "Verify and Publish" 按钮

### 步骤2：选择验证方法

在验证页面，选择以下选项：

1. **Compiler Type（编译器类型）**
   - 选择：`Solidity (Single file)`

2. **Compiler Version（编译器版本）**
   - 选择：`v0.8.20+commit.a1b79de6`

3. **Open Source License Type（开源许可证类型）**
   - 选择：`3) MIT License (MIT)`

点击 "Continue" 继续

### 步骤3：填写合约详情

在下一页填写以下信息：

1. **Contract Address（合约地址）**
   - 自动填充：`0x02aDF991D570512A812D109674Ba6A9B89e815b0`

2. **Contract Name（合约名称）**
   - 输入：`BAP578`

3. **Compiler（编译器版本）**
   - 选择：`v0.8.20+commit.a1b79de6`

4. **Optimization（优化）**
   - 选择：`Yes`
   - Runs：`200`

5. **Enter the Solidity Contract Code below（输入合约代码）**
   - 复制粘贴合约代码（见下方"合约代码"部分）

6. **Constructor Arguments ABI-encoded（构造函数参数）**
   - 输入：
   ```
   00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000e6a825646ab67cd3f1ad8a8d49d0ee087477dbb00000000000000000000000000000000000000000000000000000000000000012516e5469616e4a69616e204167656e740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000045154004a00000000000000000000000000000000000000000000000000000000
   ```

### 步骤4：提交验证

1. 完成reCAPTCHA验证
2. 点击 "Verify and Publish" 按钮
3. 等待验证完成（通常1-2分钟）

---

## 📝 合约代码（扁平化版本）

由于BSCScan需要单文件验证，我已经为您准备好了扁平化的合约代码。

### 获取扁平化代码

运行以下命令生成扁平化代码：

```bash
cd /home/ubuntu/qintianjian-dapp
npx hardhat flatten contracts/BAP578.sol > BAP578_flattened.sol
```

然后复制 `BAP578_flattened.sol` 的全部内容粘贴到BSCScan验证页面。

**注意**：扁平化后的代码可能包含重复的 `// SPDX-License-Identifier` 注释，需要手动删除重复的，只保留第一个。

---

## 🔧 构造函数参数详解

BAP578合约的构造函数接受3个参数：

```solidity
constructor(
    string memory name_,      // "QinTianJian Agent"
    string memory symbol_,    // "QTJA"
    address registry_         // 0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0
)
```

### 如何获取构造函数参数

方法1：使用Hardhat

```bash
cd /home/ubuntu/qintianjian-dapp
npx hardhat verify --network bscMainnet --show-stack-traces 0x02aDF991D570512A812D109674Ba6A9B89e815b0 "QinTianJian Agent" "QTJA" "0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0"
```

这会输出ABI编码的构造函数参数。

方法2：手动编码

访问 https://abi.hashex.org/ 并输入：
- 参数类型：`string,string,address`
- 参数值：`"QinTianJian Agent","QTJA","0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0"`

---

## 🎯 验证Registry合约

验证完BAP578主合约后，使用相同步骤验证Registry合约：

1. 访问：https://bscscan.com/verifyContract?a=0xE6A825646aB67cD3F1aD8a8d49D0Ee087477DBb0

2. 填写信息：
   - Contract Name: `Registry`
   - Compiler: `v0.8.20+commit.a1b79de6`
   - Optimization: `Yes`, Runs: `200`
   - Constructor Arguments: （Registry没有构造函数参数，留空）

3. 粘贴扁平化的Registry合约代码

---

## ✅ 验证成功标志

验证成功后，您会看到：

1. ✅ 绿色对勾标记
2. "Contract Source Code Verified" 消息
3. 合约代码在 "Contract" 标签下可见
4. "Read Contract" 和 "Write Contract" 功能可用

---

## ❌ 常见错误及解决方案

### 错误1：Compiler version mismatch

**原因**：编译器版本不匹配

**解决**：确保选择 `v0.8.20+commit.a1b79de6`

### 错误2：Constructor arguments mismatch

**原因**：构造函数参数错误

**解决**：
1. 检查参数顺序和类型
2. 使用Hardhat生成正确的ABI编码
3. 确保地址使用checksum格式

### 错误3：Bytecode mismatch

**原因**：合约代码与链上字节码不匹配

**解决**：
1. 确保使用完全相同的Solidity代码
2. 检查优化设置（Runs: 200）
3. 确保包含所有依赖合约

### 错误4：SPDX license identifier

**原因**：多个SPDX许可证标识符

**解决**：删除扁平化代码中重复的 `// SPDX-License-Identifier`，只保留第一个

---

## 📞 需要帮助？

如果验证过程中遇到问题：

1. **检查扁平化代码**
   ```bash
   cd /home/ubuntu/qintianjian-dapp
   npx hardhat flatten contracts/BAP578.sol > BAP578_flattened.sol
   cat BAP578_flattened.sol | grep "SPDX-License-Identifier" | wc -l
   ```
   如果输出大于1，需要手动删除重复的SPDX标识符

2. **验证编译设置**
   检查 `hardhat.config.cjs` 中的编译器设置：
   ```javascript
   solidity: {
     version: "0.8.20",
     settings: {
       optimizer: {
         enabled: true,
         runs: 200,
       },
     },
   }
   ```

3. **获取构造函数参数**
   ```bash
   cd /home/ubuntu/qintianjian-dapp
   node scripts/get-constructor-args.js
   ```

---

## 🚀 验证后的好处

合约验证后，您将获得：

1. **透明度**：用户可以查看和审计合约代码
2. **信任度**：提升项目可信度
3. **交互性**：BSCScan提供Read/Write Contract界面
4. **扫描器识别**：BAP-578扫描器可以识别您的合约
5. **去中心化**：符合Web3透明化原则

---

## 📚 相关链接

- BSCScan验证文档：https://docs.bscscan.com/tutorials/verifying-contracts
- Hardhat验证插件：https://hardhat.org/hardhat-runner/plugins/nomicfoundation-hardhat-verify
- ABI编码工具：https://abi.hashex.org/
- Solidity文档：https://docs.soliditylang.org/

---

**最后更新**：2026-02-15  
**合约版本**：BAP-578 v1.0  
**部署网络**：BSC Mainnet (Chain ID: 56)
